-- All In One WP Security & Firewall 4.3.9.4
-- MySQL dump
-- 2019-07-15 12:21:23

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wpst_aiowps_events`;

CREATE TABLE `wpst_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wpst_aiowps_failed_logins`;

CREATE TABLE `wpst_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wpst_aiowps_failed_logins` VALUES("1","0","james-daniel","2019-07-15 11:37:46","142.93.168.203");
INSERT INTO `wpst_aiowps_failed_logins` VALUES("2","0","james-daniel","2019-07-15 11:38:19","103.48.51.231");
INSERT INTO `wpst_aiowps_failed_logins` VALUES("3","0","james-daniel","2019-07-15 11:40:53","91.211.247.201");
INSERT INTO `wpst_aiowps_failed_logins` VALUES("4","0","james-daniel","2019-07-15 11:58:26","3.216.226.81");
INSERT INTO `wpst_aiowps_failed_logins` VALUES("5","0","james-daniel","2019-07-15 12:04:07","211.159.218.63");
INSERT INTO `wpst_aiowps_failed_logins` VALUES("6","0","james-daniel","2019-07-15 12:07:36","199.116.76.96");


DROP TABLE IF EXISTS `wpst_aiowps_global_meta`;

CREATE TABLE `wpst_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wpst_aiowps_login_activity`;

CREATE TABLE `wpst_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wpst_aiowps_login_lockdown`;

CREATE TABLE `wpst_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wpst_aiowps_login_lockdown` VALUES("1","0","james-daniel","2019-07-15 11:37:46","2019-07-15 13:37:46","142.93.168.203","login_fail","");
INSERT INTO `wpst_aiowps_login_lockdown` VALUES("2","0","james-daniel","2019-07-15 11:38:19","2019-07-15 13:38:19","103.48.51.231","login_fail","");
INSERT INTO `wpst_aiowps_login_lockdown` VALUES("3","0","james-daniel","2019-07-15 11:40:53","2019-07-15 13:40:53","91.211.247.201","login_fail","");
INSERT INTO `wpst_aiowps_login_lockdown` VALUES("4","0","james-daniel","2019-07-15 11:58:26","2019-07-15 13:58:26","3.216.226.81","login_fail","");
INSERT INTO `wpst_aiowps_login_lockdown` VALUES("5","0","james-daniel","2019-07-15 12:04:07","2019-07-15 14:04:07","211.159.218.63","login_fail","");
INSERT INTO `wpst_aiowps_login_lockdown` VALUES("6","0","james-daniel","2019-07-15 12:07:36","2019-07-15 14:07:36","199.116.76.96","login_fail","");


DROP TABLE IF EXISTS `wpst_aiowps_permanent_block`;

CREATE TABLE `wpst_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wpst_commentmeta`;

CREATE TABLE `wpst_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wpst_comments`;

CREATE TABLE `wpst_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wpst_links`;

CREATE TABLE `wpst_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wpst_options`;

CREATE TABLE `wpst_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10053 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_options` VALUES("1","siteurl","https://www.aim-expo.com","yes");
INSERT INTO `wpst_options` VALUES("2","home","https://www.aim-expo.com","yes");
INSERT INTO `wpst_options` VALUES("3","blogname","AIMExpo","yes");
INSERT INTO `wpst_options` VALUES("4","blogdescription","Technology Is At Our Fingertips!","yes");
INSERT INTO `wpst_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wpst_options` VALUES("6","admin_email","admin@aim-expo.com","yes");
INSERT INTO `wpst_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wpst_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wpst_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wpst_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wpst_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wpst_options` VALUES("12","posts_per_rss","1","yes");
INSERT INTO `wpst_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wpst_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wpst_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wpst_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wpst_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wpst_options` VALUES("18","default_category","1","yes");
INSERT INTO `wpst_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wpst_options` VALUES("20","default_ping_status","closed","yes");
INSERT INTO `wpst_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wpst_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wpst_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `wpst_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `wpst_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wpst_options` VALUES("26","comment_moderation","","yes");
INSERT INTO `wpst_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wpst_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `wpst_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wpst_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wpst_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wpst_options` VALUES("33","active_plugins","a:10:{i:0;s:25:\"add-to-any/add-to-any.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:67:\"contact-form-7-simple-recaptcha/contact-form-7-simple-recaptcha.php\";i:4;s:36:\"contact-form-7/wp-contact-form-7.php\";i:5;s:39:\"custom-permalinks/custom-permalinks.php\";i:6;s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";i:7;s:43:\"remove-category-url/remove-category-url.php\";i:8;s:24:\"wordpress-seo/wp-seo.php\";i:9;s:41:\"xml-sitemaps-for-videos/video-sitemap.php\";}","yes");
INSERT INTO `wpst_options` VALUES("34","category_base","","yes");
INSERT INTO `wpst_options` VALUES("35","ping_sites","http://rpc.pingomatic.com
http://rpc.twingly.com
http://api.feedster.com/ping
http://api.moreover.com/RPC2
http://api.moreover.com/ping
http://www.blogdigger.com/RPC2
http://www.blogshares.com/rpc.php
http://www.blogsnow.com/ping
http://www.blogstreet.com/xrbin/xmlrpc.cgi
http://bulkfeeds.net/rpc
http://www.newsisfree.com/xmlrpctest.php
http://ping.blo.gs/
http://ping.feedburner.com
http://ping.syndic8.com/xmlrpc.php
http://ping.weblogalot.com/rpc.php
http://rpc.blogrolling.com/pinger/
http://rpc.technorati.com/rpc/ping
http://rpc.weblogs.com/RPC2
http://www.feedsubmitter.com
http://blo.gs/ping.php
http://www.pingerati.net
http://www.pingmyblog.com
http://geourl.org/ping
http://ipings.com
http://www.weblogalot.com/ping","yes");
INSERT INTO `wpst_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wpst_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wpst_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wpst_options` VALUES("39","recently_edited","a:4:{i:0;s:77:\"/home/spencerb/public_html/aim-expo.com/wp-content/themes/blogberg/header.php\";i:1;s:76:\"/home/spencerb/public_html/aim-expo.com/wp-content/themes/blogberg/style.css\";i:2;s:77:\"/home/spencerb/public_html/aim-expo.com/wp-content/themes/blogberg/footer.php\";i:3;s:0:\"\";}","no");
INSERT INTO `wpst_options` VALUES("40","template","blogberg","yes");
INSERT INTO `wpst_options` VALUES("41","stylesheet","blogberg","yes");
INSERT INTO `wpst_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wpst_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wpst_options` VALUES("44","comment_registration","1","yes");
INSERT INTO `wpst_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wpst_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wpst_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wpst_options` VALUES("48","db_version","44719","yes");
INSERT INTO `wpst_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wpst_options` VALUES("50","upload_path","","yes");
INSERT INTO `wpst_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wpst_options` VALUES("52","default_link_category","0","yes");
INSERT INTO `wpst_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wpst_options` VALUES("54","tag_base","","yes");
INSERT INTO `wpst_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wpst_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wpst_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wpst_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wpst_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wpst_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wpst_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wpst_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wpst_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wpst_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wpst_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wpst_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wpst_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wpst_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wpst_options` VALUES("69","close_comments_for_old_posts","","yes");
INSERT INTO `wpst_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wpst_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wpst_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wpst_options` VALUES("73","page_comments","","yes");
INSERT INTO `wpst_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wpst_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wpst_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wpst_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("79","widget_text","a:4:{i:1;a:0:{}i:2;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:200:\"<a href=\"https://www.zebra.com/\" target=\"_blank\" rel=\"nofollow noopener\"><img class=\"aligncenter \" src=\"http://aim-expo.com/wp-content/uploads/2018/10/zebra.png\" alt=\"\" width=\"300\" height=\"500\" /></a>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:189:\"<a href=\"https://www.tsys.com/\" target=\"_blank\" rel=\"nofollow\"><img class=\"aligncenter \" src=\"http://aim-expo.com/wp-content/uploads/2018/10/tsys.jpg\" alt=\"\" width=\"300\" height=\"500\" /></a>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wpst_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wpst_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wpst_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wpst_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wpst_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wpst_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wpst_options` VALUES("88","site_icon","106","yes");
INSERT INTO `wpst_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wpst_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wpst_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wpst_options` VALUES("92","show_comments_cookies_opt_in","","yes");
INSERT INTO `wpst_options` VALUES("93","initial_db_version","38590","yes");
INSERT INTO `wpst_options` VALUES("94","wpst_user_roles","a:8:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:64:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:23:\"cp_view_post_permalinks\";b:1;s:27:\"cp_view_category_permalinks\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:25:\"custom_permalinks_manager\";a:2:{s:4:\"name\";s:25:\"Custom Permalinks Manager\";s:12:\"capabilities\";a:2:{s:23:\"cp_view_post_permalinks\";b:1;s:27:\"cp_view_category_permalinks\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes");
INSERT INTO `wpst_options` VALUES("95","fresh_site","0","yes");
INSERT INTO `wpst_options` VALUES("96","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("97","widget_recent-posts","a:2:{i:2;a:3:{s:5:\"title\";s:16:\"Popular Articles\";s:6:\"number\";i:5;s:9:\"show_date\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("98","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("99","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("100","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("101","sidebars_widgets","a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:13:\"right-sidebar\";a:3:{i:0;s:6:\"text-2\";i:1;s:14:\"recent-posts-2\";i:2;s:6:\"text-3\";}s:25:\"blogberg-footer-sidebar-1\";a:1:{i:0;s:10:\"archives-2\";}s:25:\"blogberg-footer-sidebar-2\";a:1:{i:0;s:12:\"categories-2\";}s:25:\"blogberg-footer-sidebar-3\";a:1:{i:0;s:11:\"tag_cloud-2\";}s:25:\"blogberg-footer-sidebar-4\";a:1:{i:0;s:7:\"pages-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wpst_options` VALUES("102","widget_pages","a:2:{i:2;a:3:{s:5:\"title\";s:11:\"Quick Links\";s:6:\"sortby\";s:10:\"post_title\";s:7:\"exclude\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("103","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("104","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("105","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("106","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("107","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("108","widget_tag_cloud","a:2:{i:2;a:3:{s:5:\"title\";s:4:\"Tags\";s:5:\"count\";i:0;s:8:\"taxonomy\";s:8:\"post_tag\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("109","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("110","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("111","cron","a:10:{i:1563194015;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1563196839;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1563212015;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1563258265;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1563271480;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1563271481;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1563272606;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1563273375;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1563276039;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wpst_options` VALUES("112","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:0:{}}","yes");
INSERT INTO `wpst_options` VALUES("9577","category_children","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("9999","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1563232574","no");
INSERT INTO `wpst_options` VALUES("10010","rewrite_rules","a:95:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:39:\"index.php?yoast-sitemap-xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:44:\"(blog)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:27:\"(blog)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:9:\"(blog)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:51:\"(events-expo)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:34:\"(events-expo)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:16:\"(events-expo)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:55:\"(mobility-trends)/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:38:\"(mobility-trends)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:20:\"(mobility-trends)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:14:\"category/(.*)$\";s:39:\"index.php?category_redirect=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `wpst_options` VALUES("1206","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1207","widget_mla-text-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1208","widget_sow-button","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1209","widget_sow-google-map","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1210","widget_sow-image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1211","widget_sow-slider","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1212","widget_sow-post-carousel","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1213","widget_sow-editor","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1214","mla_custom_field_mapping","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("1215","mla_iptc_exif_mapping","a:3:{s:8:\"standard\";a:6:{s:10:\"post_title\";a:5:{s:4:\"name\";s:5:\"Title\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:1;}s:9:\"post_name\";a:5:{s:4:\"name\";s:9:\"Name/Slug\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:1;}s:9:\"image_alt\";a:5:{s:4:\"name\";s:8:\"ALT Text\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:1;}s:12:\"post_excerpt\";a:5:{s:4:\"name\";s:7:\"Caption\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:1;}s:12:\"post_content\";a:5:{s:4:\"name\";s:11:\"Description\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:1;}s:9:\"post_date\";a:5:{s:4:\"name\";s:11:\"Uploaded on\";s:10:\"iptc_value\";s:4:\"none\";s:10:\"exif_value\";s:0:\"\";s:10:\"iptc_first\";b:1;s:13:\"keep_existing\";b:0;}}s:8:\"taxonomy\";a:0:{}s:6:\"custom\";a:0:{}}","yes");
INSERT INTO `wpst_options` VALUES("1196","widget_a2a_share_save_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1216","mla_upload_mimes","a:4:{s:6:\"custom\";a:0:{}s:8:\"disabled\";a:52:{s:3:\"ac3\";b:1;s:2:\"ai\";b:1;s:3:\"aif\";b:1;s:4:\"aifc\";b:1;s:4:\"aiff\";b:1;s:2:\"au\";b:1;s:3:\"bin\";b:1;s:3:\"cat\";b:1;s:3:\"cdf\";b:1;s:3:\"cgm\";b:1;s:3:\"clp\";b:1;s:3:\"crd\";b:1;s:3:\"dat\";b:1;s:3:\"dll\";b:1;s:3:\"dot\";b:1;s:3:\"dtd\";b:1;s:3:\"eps\";b:1;s:4:\"gtar\";b:1;s:3:\"ief\";b:1;s:3:\"ifb\";b:1;s:3:\"m13\";b:1;s:3:\"m14\";b:1;s:3:\"mml\";b:1;s:3:\"mny\";b:1;s:5:\"movie\";b:1;s:3:\"mp2\";b:1;s:3:\"mpa\";b:1;s:3:\"msg\";b:1;s:3:\"mvb\";b:1;s:3:\"otf\";b:1;s:3:\"pic\";b:1;s:4:\"pict\";b:1;s:2:\"ps\";b:1;s:3:\"pub\";b:1;s:3:\"rgb\";b:1;s:3:\"scd\";b:1;s:3:\"snd\";b:1;s:3:\"sql\";b:1;s:3:\"sst\";b:1;s:3:\"stl\";b:1;s:3:\"svg\";b:1;s:3:\"trm\";b:1;s:3:\"ttf\";b:1;s:3:\"w6w\";b:1;s:3:\"wmf\";b:1;s:4:\"woff\";b:1;s:4:\"word\";b:1;s:3:\"xlc\";b:1;s:3:\"xlm\";b:1;s:3:\"xml\";b:1;s:3:\"xsl\";b:1;s:4:\"xslt\";b:1;}s:11:\"description\";a:0:{}s:9:\"icon_type\";a:82:{s:2:\"ai\";s:10:\"postscript\";s:4:\"aifc\";s:5:\"audio\";s:3:\"asx\";s:5:\"video\";s:2:\"au\";s:5:\"audio\";s:3:\"bin\";s:6:\"binary\";s:1:\"c\";s:8:\"source_c\";s:2:\"cc\";s:10:\"source_cpp\";s:3:\"cgm\";s:5:\"image\";s:5:\"class\";s:11:\"source_java\";s:3:\"clp\";s:6:\"knotes\";s:3:\"crd\";s:6:\"knotes\";s:3:\"css\";s:10:\"stylesheet\";s:3:\"dat\";s:6:\"binary\";s:3:\"dll\";s:8:\"exe_wine\";s:3:\"dot\";s:8:\"document\";s:4:\"dotx\";s:8:\"document\";s:3:\"dtd\";s:4:\"code\";s:3:\"eps\";s:10:\"postscript\";s:3:\"exe\";s:8:\"exe_wine\";s:4:\"gtar\";s:7:\"archive\";s:4:\"gzip\";s:7:\"archive\";s:1:\"h\";s:8:\"source_h\";s:3:\"ics\";s:8:\"calendar\";s:3:\"ief\";s:5:\"image\";s:3:\"ifb\";s:8:\"calendar\";s:2:\"js\";s:11:\"source_java\";s:3:\"mdb\";s:8:\"database\";s:3:\"mid\";s:5:\"audio\";s:4:\"midi\";s:5:\"audio\";s:3:\"mml\";s:8:\"kformula\";s:5:\"movie\";s:5:\"video\";s:3:\"mpa\";s:5:\"audio\";s:3:\"mpe\";s:5:\"video\";s:3:\"msg\";s:7:\"message\";s:3:\"odb\";s:8:\"database\";s:3:\"odc\";s:3:\"log\";s:3:\"odf\";s:8:\"kformula\";s:3:\"odg\";s:2:\"3d\";s:6:\"onepkg\";s:6:\"knotes\";s:6:\"onetmp\";s:6:\"knotes\";s:6:\"onetoc\";s:6:\"knotes\";s:7:\"onetoc2\";s:6:\"knotes\";s:3:\"otf\";s:4:\"font\";s:3:\"pdf\";s:3:\"pdf\";s:3:\"pic\";s:5:\"image\";s:4:\"pict\";s:5:\"image\";s:3:\"pot\";s:11:\"interactive\";s:4:\"potm\";s:11:\"interactive\";s:4:\"potx\";s:11:\"interactive\";s:4:\"ppam\";s:11:\"interactive\";s:2:\"ps\";s:10:\"postscript\";s:3:\"psd\";s:5:\"image\";s:3:\"pub\";s:8:\"document\";s:2:\"qt\";s:9:\"quicktime\";s:2:\"ra\";s:5:\"audio\";s:3:\"rgb\";s:5:\"image\";s:3:\"rtx\";s:4:\"text\";s:3:\"snd\";s:5:\"audio\";s:3:\"sql\";s:8:\"database\";s:3:\"svg\";s:9:\"vectorgfx\";s:3:\"trm\";s:11:\"interactive\";s:3:\"ttf\";s:13:\"font_truetype\";s:3:\"w6w\";s:8:\"document\";s:3:\"wax\";s:5:\"audio\";s:4:\"webm\";s:5:\"video\";s:2:\"wm\";s:5:\"video\";s:3:\"wmf\";s:9:\"vectorgfx\";s:3:\"wmx\";s:5:\"video\";s:4:\"woff\";s:4:\"font\";s:4:\"word\";s:8:\"document\";s:3:\"wri\";s:8:\"document\";s:3:\"xla\";s:11:\"spreadsheet\";s:4:\"xlam\";s:11:\"spreadsheet\";s:3:\"xlc\";s:11:\"spreadsheet\";s:3:\"xlm\";s:11:\"spreadsheet\";s:3:\"xlt\";s:11:\"spreadsheet\";s:4:\"xltm\";s:11:\"spreadsheet\";s:4:\"xltx\";s:11:\"spreadsheet\";s:3:\"xlw\";s:11:\"spreadsheet\";s:3:\"xml\";s:4:\"code\";s:3:\"xsl\";s:5:\"style\";s:4:\"xslt\";s:4:\"code\";}}","yes");
INSERT INTO `wpst_options` VALUES("1197","widget_a2a_follow_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1193","wpcf7","a:2:{s:7:\"version\";s:5:\"5.1.3\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1540981269;s:7:\"version\";s:5:\"5.0.5\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `wpst_options` VALUES("1253","current_theme","Blogberg","yes");
INSERT INTO `wpst_options` VALUES("1254","theme_mods_mega-magazine","a:17:{i:0;b:0;s:18:\"custom_css_post_id\";i:60;s:13:\"primary_color\";s:7:\"#f77a52\";s:18:\"nav_menu_locations\";a:2:{s:12:\"primary-menu\";i:4;s:8:\"top-menu\";i:5;}s:8:\"top_menu\";b:1;s:12:\"social_icons\";b:1;s:11:\"show_search\";b:1;s:17:\"breaking_news_cat\";i:1;s:13:\"social_link_1\";s:26:\"https://www.facebook.com/#\";s:13:\"social_link_2\";s:21:\"https://twitter.com/#\";s:13:\"social_link_3\";s:25:\"https://plus.google.com/#\";s:13:\"social_link_4\";s:26:\"https://www.linkedin.com/#\";s:13:\"social_link_5\";s:27:\"https://www.pinterest.com/#\";s:14:\"copyright_text\";s:38:\"© 2018 AIMExpo | All Rights Reserved.\";s:11:\"custom_logo\";i:67;s:9:\"logo_type\";s:9:\"logo-only\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1562560632;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:7:{i:0;s:28:\"mega-magazine-recent-posts-3\";i:1;s:22:\"mega-magazine-social-2\";i:2;s:6:\"text-2\";i:3;s:29:\"mega-magazine-popular-posts-3\";i:4;s:6:\"text-3\";i:5;s:10:\"archives-2\";i:6;s:12:\"categories-2\";}s:22:\"front-page-widget-area\";a:5:{i:0;s:22:\"mega-magazine-slider-2\";i:1;s:26:\"mega-magazine-split-news-2\";i:2;s:27:\"mega-magazine-double-news-2\";i:3;s:27:\"mega-magazine-triple-news-2\";i:4;s:25:\"mega-magazine-full-news-2\";}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:15:\"advertisement-1\";a:0:{}}}}","yes");
INSERT INTO `wpst_options` VALUES("1255","theme_switched","","yes");
INSERT INTO `wpst_options` VALUES("9991","_transient_timeout_wpseo-statistics-totals","1563275771","no");
INSERT INTO `wpst_options` VALUES("9992","_transient_wpseo-statistics-totals","a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:48:\"Posts <strong>without</strong> a focus keyphrase\";s:5:\"count\";i:5;s:4:\"link\";s:101:\"https://www.aim-expo.com/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}","no");
INSERT INTO `wpst_options` VALUES("9786","db_upgraded","","yes");
INSERT INTO `wpst_options` VALUES("1175","recently_activated","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("9790","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1563189633;s:15:\"version_checked\";s:5:\"5.2.2\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wpst_options` VALUES("9788","recovery_keys","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("9791","_site_transient_timeout_php_check_a5907c2ea4d6fbd7e531b3aa7734f0e4","1563359876","no");
INSERT INTO `wpst_options` VALUES("9792","_site_transient_php_check_a5907c2ea4d6fbd7e531b3aa7734f0e4","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:0;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wpst_options` VALUES("9997","_transient_timeout_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1563232573","no");
INSERT INTO `wpst_options` VALUES("9998","_transient_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1563189373","no");
INSERT INTO `wpst_options` VALUES("10000","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1563232574","no");
INSERT INTO `wpst_options` VALUES("10001","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1563189374","no");
INSERT INTO `wpst_options` VALUES("10002","_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b","1563232574","no");
INSERT INTO `wpst_options` VALUES("10003","_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2019/07/people-of-wordpress-ugyen-dorji/\'>People of WordPress: Ugyen Dorji</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/in-case-you-missed-it-issue-28\'>WPTavern: In Case You Missed It – Issue 28</a></li><li><a class=\'rsswidget\' href=\'https://heropress.com/syndication/#utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=syndication\'>HeroPress: Syndication!</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/experimental-block-areas-plugin-allows-for-editing-content-sitewide-with-gutenberg\'>WPTavern: Experimental Block Areas Plugin Allows for Editing Content Sitewide with Gutenberg</a></li></ul></div>","no");
INSERT INTO `wpst_options` VALUES("2594","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:18:\"admin@aim-expo.com\";s:7:\"version\";s:6:\"4.9.10\";s:9:\"timestamp\";i:1552455286;}","no");
INSERT INTO `wpst_options` VALUES("9594","widget_web_app_termsr_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9595","widget_web_app_top_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9981","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1563189634;s:7:\"checked\";a:2:{s:8:\"blogberg\";s:5:\"1.0.1\";s:13:\"twentyfifteen\";s:3:\"2.0\";}s:8:\"response\";a:1:{s:13:\"twentyfifteen\";a:6:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.5\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.5.zip\";s:8:\"requires\";s:3:\"4.1\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wpst_options` VALUES("9629","theme_mods_blogberg","a:17:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:4;}s:18:\"custom_css_post_id\";i:94;s:15:\"slider_category\";i:2;s:12:\"header_image\";s:82:\"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\";s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:86;s:3:\"url\";s:82:\"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\";s:13:\"thumbnail_url\";s:82:\"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\";s:6:\"height\";i:379;s:5:\"width\";i:1920;}s:16:\"background_image\";s:59:\"https://www.aim-expo.com/wp-content/uploads/2019/07/767.png\";s:17:\"background_preset\";s:3:\"fit\";s:15:\"background_size\";s:7:\"contain\";s:17:\"background_repeat\";s:9:\"no-repeat\";s:21:\"background_attachment\";s:5:\"fixed\";s:11:\"custom_logo\";i:67;s:16:\"header_textcolor\";s:5:\"blank\";s:11:\"footer_text\";s:50:\"Copyright © 2019. All Rights Reserved by AIMExpo.\";s:19:\"disable_search_icon\";b:0;s:27:\"disable_hamburger_menu_icon\";b:1;s:20:\"disable_fixed_header\";b:0;}","yes");
INSERT INTO `wpst_options` VALUES("9617","theme_mods_eximious-magazine","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:12:\"primary-menu\";i:4;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1562561106;s:4:\"data\";a:12:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:8:\"header-1\";a:0:{}s:26:\"above-homepage-widget-area\";a:0:{}s:21:\"home-page-widget-area\";a:0:{}s:17:\"home-page-sidebar\";a:0:{}s:26:\"below-homepage-widget-area\";a:0:{}s:24:\"before-footer-widgetarea\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}}}}","yes");
INSERT INTO `wpst_options` VALUES("9605","theme_mods_vivacious-magazine","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:14:\"em-primary-nav\";i:4;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1562561083;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:24:\"express-off-canvas-panel\";a:0:{}s:20:\"home-content-widgets\";a:0:{}s:20:\"home-sidebar-widgets\";a:0:{}s:28:\"footer-first-widgets-section\";a:0:{}s:29:\"footer-second-widgets-section\";a:0:{}s:28:\"footer-third-widgets-section\";a:0:{}}}}","yes");
INSERT INTO `wpst_options` VALUES("9618","widget_eximious_magazine_post_ids_special_grid","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9619","widget_eximious_magazine_single_column_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9620","widget_eximious_magazine_double_column_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9621","widget_eximious_magazine_posts_slider","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9622","widget_eximious_magazine_posts_carousel","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9623","widget_eximious_magazine_recent_posts_with_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("8993","rlrsssl_options","a:15:{s:12:\"site_has_ssl\";b:1;s:4:\"hsts\";b:0;s:22:\"htaccess_warning_shown\";b:0;s:19:\"review_notice_shown\";b:0;s:25:\"ssl_success_message_shown\";b:0;s:26:\"autoreplace_insecure_links\";b:1;s:17:\"plugin_db_version\";s:5:\"3.2.3\";s:5:\"debug\";b:0;s:20:\"do_not_edit_htaccess\";b:0;s:17:\"htaccess_redirect\";b:0;s:11:\"ssl_enabled\";b:1;s:19:\"javascript_redirect\";b:1;s:11:\"wp_redirect\";b:1;s:31:\"switch_mixed_content_fixer_hook\";b:0;s:19:\"dismiss_all_notices\";b:0;}","yes");
INSERT INTO `wpst_options` VALUES("9001","rsssl_activation_timestamp","1561111716","yes");
INSERT INTO `wpst_options` VALUES("9002","rsssl_flush_rewrite_rules","1561111716","yes");
INSERT INTO `wpst_options` VALUES("9630","widget_blogberg_author_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9593","theme_mods_web-app","a:8:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:6:\"menu-1\";i:4;}s:18:\"custom_css_post_id\";i:-1;s:17:\"web_app_weblayout\";s:10:\"box-layout\";s:21:\"web_app_slider_option\";s:3:\"yes\";s:26:\"web_app_slider_section_cat\";s:15:\"mobility-trends\";s:21:\"web_app_page_bg_image\";s:74:\"https://www.aim-expo.com/wp-content/uploads/2018/01/mobility-solutions.jpg\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1562561038;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:21:\"web-app-sidebar-right\";a:4:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:20:\"web-app-sidebar-left\";a:0:{}s:18:\"web-app-top-footer\";a:0:{}s:14:\"web-app-footer\";a:0:{}}}}","yes");
INSERT INTO `wpst_options` VALUES("9590","theme_mods_ts-mobile-app","a:8:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:4;}s:18:\"custom_css_post_id\";i:-1;s:35:\"bb_mobile_application_theme_options\";s:13:\"Right Sidebar\";s:47:\"bb_mobile_application_blogcategory_left_setting\";s:4:\"blog\";s:42:\"bb_mobile_application_middle_image_setting\";s:59:\"Leading Automatic Identification and Data Capture Suppliers\";s:48:\"bb_mobile_application_blogcategory_right_setting\";s:15:\"mobility-trends\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1562560757;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:2;s:6:\"text-2\";i:4;s:6:\"text-3\";i:5;s:10:\"archives-2\";i:6;s:12:\"categories-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}}}}","yes");
INSERT INTO `wpst_options` VALUES("9624","widget_eximious_magazine_tab_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9625","widget_eximious_magazine_express_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9626","widget_eximious_magazine_social_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1259","widget_mega-magazine-double-news","a:2:{i:2;a:5:{s:5:\"title\";s:0:\"\";s:15:\"double_category\";i:2;s:11:\"enable_link\";i:1;s:14:\"excerpt_length\";i:25;s:11:\"post_number\";i:4;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1217","mla_current_version","2.79","yes");
INSERT INTO `wpst_options` VALUES("1218","siteorigin_widget_bundle_version","1.15.7","yes");
INSERT INTO `wpst_options` VALUES("1219","siteorigin_widgets_old_widgets","/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/accordion/accordion.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/button/button.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/cta/cta.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/contact/contact.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/editor/editor.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/features/features.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/google-map/google-map.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/headline/headline.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/hero/hero.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/icon/icon.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/image/image.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/image-grid/image-grid.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/slider/slider.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/layout-slider/layout-slider.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/post-carousel/post-carousel.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/price-table/price-table.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/simple-masonry/simple-masonry.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/social-media-buttons/social-media-buttons.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/tabs/tabs.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/taxonomy/taxonomy.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/testimonial/testimonial.php,/home/spencerb/public_html/aim-expo.com/wp-content/plugins/so-widgets-bundle/widgets/video/video.php","yes");
INSERT INTO `wpst_options` VALUES("1220","WPLANG","","yes");
INSERT INTO `wpst_options` VALUES("1221","new_admin_email","admin@aim-expo.com","yes");
INSERT INTO `wpst_options` VALUES("1263","widget_mega-magazine-recent-posts","a:2:{i:3;a:2:{s:5:\"title\";s:0:\"\";s:11:\"post_number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9676","_transient_timeout_wpseo_link_table_inaccessible","1594103065","no");
INSERT INTO `wpst_options` VALUES("9677","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wpst_options` VALUES("9678","_transient_timeout_wpseo_meta_table_inaccessible","1594103065","no");
INSERT INTO `wpst_options` VALUES("9679","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wpst_options` VALUES("10011","_transient_timeout_rsssl_mixed_content_fixer_detected","1563190175","no");
INSERT INTO `wpst_options` VALUES("10012","_transient_rsssl_mixed_content_fixer_detected","found","no");
INSERT INTO `wpst_options` VALUES("10013","_transient_rsssl_plusone_count","1","yes");
INSERT INTO `wpst_options` VALUES("10014","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1563200377","no");
INSERT INTO `wpst_options` VALUES("10015","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4598;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3527;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2630;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2497;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1926;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1742;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1737;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1470;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1445;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1441;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1435;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1371;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1333;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1295;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1147;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1123;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1100;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1070;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1023;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:942;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:855;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:845;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:840;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:803;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:745;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:736;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:731;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:722;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:713;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:700;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:699;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:685;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:676;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:663;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:660;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:653;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:633;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:624;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:623;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:619;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:592;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:589;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:572;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:568;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:560;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:556;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:548;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:544;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:535;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:526;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:526;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:516;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:514;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:511;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:506;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:496;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:492;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:478;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:477;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:476;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:472;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:470;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:458;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:453;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:442;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:431;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:428;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:423;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:416;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:416;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:412;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:405;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:400;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:399;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:393;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:390;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:385;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:384;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:380;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:376;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:367;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:364;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:362;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:362;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:356;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:355;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:353;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:350;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:346;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:346;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:340;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:331;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:325;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:323;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:321;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:321;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:317;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:315;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:310;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:310;}}","no");
INSERT INTO `wpst_options` VALUES("9669","custom_permalinks_plugin_version","1.5.1","yes");
INSERT INTO `wpst_options` VALUES("1236","akismet_spam_count","0","yes");
INSERT INTO `wpst_options` VALUES("1238","mla_post_mime_types","a:0:{}","yes");
INSERT INTO `wpst_options` VALUES("1262","widget_mega-magazine-popular-posts","a:2:{i:3;a:2:{s:5:\"title\";s:13:\"Popular Posts\";s:11:\"post_number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1261","widget_mega-magazine-full-news","a:2:{i:2;a:5:{s:5:\"title\";s:0:\"\";s:13:\"full_category\";i:2;s:11:\"enable_link\";i:1;s:14:\"excerpt_length\";i:25;s:11:\"post_number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1260","widget_mega-magazine-triple-news","a:2:{i:2;a:5:{s:5:\"title\";s:0:\"\";s:15:\"triple_category\";i:2;s:11:\"enable_link\";i:1;s:11:\"post_number\";i:6;s:15:\"enable_carousel\";i:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1256","widget_mega-magazine-slider","a:2:{i:2;a:10:{s:15:\"slider_category\";i:2;s:15:\"number_of_posts\";i:5;s:18:\"transition_effects\";s:10:\"scrollHorz\";s:16:\"transition_delay\";i:3;s:10:\"show_arrow\";i:1;s:12:\"show_overlay\";i:1;s:15:\"enable_autoplay\";i:1;s:15:\"show_categories\";i:1;s:9:\"show_date\";i:1;s:14:\"show_thumbnail\";i:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1257","widget_mega-magazine-social","a:2:{i:2;a:1:{s:5:\"title\";s:15:\"Get In Touch!!!\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1258","widget_mega-magazine-split-news","a:2:{i:2;a:5:{s:5:\"title\";s:0:\"\";s:14:\"split_category\";i:2;s:11:\"enable_link\";i:1;s:14:\"excerpt_length\";i:25;s:11:\"post_number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("1232","akismet_strictness","1","yes");
INSERT INTO `wpst_options` VALUES("1233","akismet_show_user_comments_approved","0","yes");
INSERT INTO `wpst_options` VALUES("1234","akismet_comment_form_privacy_notice","hide","yes");
INSERT INTO `wpst_options` VALUES("1235","wordpress_api_key","2da0a64fa0dd","yes");
INSERT INTO `wpst_options` VALUES("1282","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wpst_options` VALUES("1283","addtoany_options","a:59:{s:17:\"floating_vertical\";s:4:\"none\";s:19:\"floating_horizontal\";s:4:\"none\";s:28:\"floating_horizontal_position\";s:1:\"0\";s:26:\"floating_horizontal_offset\";s:1:\"0\";s:30:\"floating_horizontal_responsive\";s:1:\"1\";s:40:\"floating_horizontal_responsive_min_width\";s:3:\"981\";s:30:\"floating_horizontal_scroll_top\";s:2:\"-1\";s:37:\"floating_horizontal_scroll_top_pixels\";s:3:\"100\";s:33:\"floating_horizontal_scroll_bottom\";s:2:\"-1\";s:40:\"floating_horizontal_scroll_bottom_pixels\";s:3:\"100\";s:29:\"floating_horizontal_icon_size\";s:2:\"32\";s:22:\"floating_horizontal_bg\";s:11:\"transparent\";s:28:\"floating_horizontal_bg_color\";s:7:\"#ffffff\";s:26:\"floating_vertical_position\";s:3:\"100\";s:29:\"floating_vertical_attached_to\";s:47:\"main, [role=\\\"main\\\"], article, .status-publish\";s:24:\"floating_vertical_offset\";s:1:\"0\";s:28:\"floating_vertical_responsive\";s:1:\"1\";s:38:\"floating_vertical_responsive_max_width\";s:3:\"980\";s:28:\"floating_vertical_scroll_top\";s:2:\"-1\";s:35:\"floating_vertical_scroll_top_pixels\";s:3:\"100\";s:31:\"floating_vertical_scroll_bottom\";s:2:\"-1\";s:38:\"floating_vertical_scroll_bottom_pixels\";s:3:\"100\";s:27:\"floating_vertical_icon_size\";s:2:\"32\";s:20:\"floating_vertical_bg\";s:11:\"transparent\";s:26:\"floating_vertical_bg_color\";s:7:\"#ffffff\";s:8:\"position\";s:6:\"bottom\";s:30:\"display_in_posts_on_front_page\";s:1:\"1\";s:33:\"display_in_posts_on_archive_pages\";s:1:\"1\";s:19:\"display_in_excerpts\";s:1:\"1\";s:16:\"display_in_posts\";s:1:\"1\";s:16:\"display_in_pages\";s:2:\"-1\";s:22:\"display_in_attachments\";s:2:\"-1\";s:15:\"display_in_feed\";s:1:\"1\";s:7:\"onclick\";s:2:\"-1\";s:9:\"icon_size\";s:2:\"32\";s:7:\"icon_bg\";s:8:\"original\";s:13:\"icon_bg_color\";s:7:\"#2a2a2a\";s:7:\"icon_fg\";s:8:\"original\";s:13:\"icon_fg_color\";s:7:\"#ffffff\";s:6:\"button\";s:10:\"A2A_SVG_32\";s:13:\"button_custom\";s:0:\"\";s:17:\"button_show_count\";s:2:\"-1\";s:6:\"header\";s:0:\"\";s:23:\"additional_js_variables\";s:0:\"\";s:14:\"additional_css\";s:0:\"\";s:12:\"custom_icons\";s:2:\"-1\";s:16:\"custom_icons_url\";s:1:\"/\";s:17:\"custom_icons_type\";s:3:\"png\";s:18:\"custom_icons_width\";s:0:\"\";s:19:\"custom_icons_height\";s:0:\"\";s:5:\"cache\";s:2:\"-1\";s:11:\"button_text\";s:5:\"Share\";s:24:\"special_facebook_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:15:\"active_services\";a:3:{i:0;s:8:\"facebook\";i:1;s:7:\"twitter\";i:2;s:11:\"google_plus\";}s:29:\"special_facebook_like_options\";a:2:{s:10:\"show_count\";s:2:\"-1\";s:4:\"verb\";s:4:\"like\";}s:29:\"special_twitter_tweet_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:30:\"special_google_plusone_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:33:\"special_google_plus_share_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:29:\"special_pinterest_pin_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}}","yes");
INSERT INTO `wpst_options` VALUES("10022","_transient_timeout_users_online","1563191671","no");
INSERT INTO `wpst_options` VALUES("10023","_transient_users_online","a:0:{}","no");
INSERT INTO `wpst_options` VALUES("10025","_transient_timeout_aiowps_logout_payload","1563191671","no");
INSERT INTO `wpst_options` VALUES("10026","_transient_aiowps_logout_payload","a:2:{s:11:\"redirect_to\";s:61:\"https://www.aim-expo.com:443/wp-admin/admin.php?page=aiowpsec\";s:3:\"msg\";s:35:\"aiowps_login_msg_id=session_expired\";}","no");
INSERT INTO `wpst_options` VALUES("10027","_transient_timeout_aiowps_captcha_string_info_npcz6leffv","1563191672","no");
INSERT INTO `wpst_options` VALUES("10028","_transient_aiowps_captcha_string_info_npcz6leffv","MTU2MzE4OTg3Mm5pd2Rwc2lndzMyNnZ6ZnluMjB4NA==","no");
INSERT INTO `wpst_options` VALUES("10030","_transient_timeout_aiowps_captcha_string_info_svdtfjad6h","1563192466","no");
INSERT INTO `wpst_options` VALUES("10031","_transient_aiowps_captcha_string_info_svdtfjad6h","MTU2MzE5MDY2Nm5pd2Rwc2lndzMyNnZ6ZnluMjB4MjI=","no");
INSERT INTO `wpst_options` VALUES("10032","_transient_timeout_aiowps_captcha_string_info_9p0krgpc4c","1563192494","no");
INSERT INTO `wpst_options` VALUES("10033","_transient_aiowps_captcha_string_info_9p0krgpc4c","MTU2MzE5MDY5NG5pd2Rwc2lndzMyNnZ6ZnluMjB4Nw==","no");
INSERT INTO `wpst_options` VALUES("10034","_transient_timeout_aiowps_captcha_string_info_pexop2xxtz","1563192499","no");
INSERT INTO `wpst_options` VALUES("10035","_transient_aiowps_captcha_string_info_pexop2xxtz","MTU2MzE5MDY5OW5pd2Rwc2lndzMyNnZ6ZnluMjB4NQ==","no");
INSERT INTO `wpst_options` VALUES("10036","_transient_timeout_aiowps_captcha_string_info_2vfc4rh5ab","1563192653","no");
INSERT INTO `wpst_options` VALUES("10037","_transient_aiowps_captcha_string_info_2vfc4rh5ab","MTU2MzE5MDg1M25pd2Rwc2lndzMyNnZ6ZnluMjB4MTI=","no");
INSERT INTO `wpst_options` VALUES("10038","_transient_timeout_aiowps_captcha_string_info_sdo4vk6evj","1563192653","no");
INSERT INTO `wpst_options` VALUES("10039","_transient_aiowps_captcha_string_info_sdo4vk6evj","MTU2MzE5MDg1M25pd2Rwc2lndzMyNnZ6ZnluMjB4MQ==","no");
INSERT INTO `wpst_options` VALUES("10040","_transient_timeout_aiowps_captcha_string_info_xl6t7maqqj","1563193705","no");
INSERT INTO `wpst_options` VALUES("10041","_transient_aiowps_captcha_string_info_xl6t7maqqj","MTU2MzE5MTkwNW5pd2Rwc2lndzMyNnZ6ZnluMjB4Mjk=","no");
INSERT INTO `wpst_options` VALUES("10042","_transient_timeout_aiowps_captcha_string_info_vvwal67llk","1563193707","no");
INSERT INTO `wpst_options` VALUES("10043","_transient_aiowps_captcha_string_info_vvwal67llk","MTU2MzE5MTkwN25pd2Rwc2lndzMyNnZ6ZnluMjB4MzA=","no");
INSERT INTO `wpst_options` VALUES("10044","_transient_timeout_aiowps_captcha_string_info_5jjbaxd1wl","1563194046","no");
INSERT INTO `wpst_options` VALUES("10045","_transient_aiowps_captcha_string_info_5jjbaxd1wl","MTU2MzE5MjI0Nm5pd2Rwc2lndzMyNnZ6ZnluMjB4MA==","no");
INSERT INTO `wpst_options` VALUES("10046","_transient_timeout_aiowps_captcha_string_info_q5cgy68y9j","1563194047","no");
INSERT INTO `wpst_options` VALUES("10047","_transient_aiowps_captcha_string_info_q5cgy68y9j","MTU2MzE5MjI0N25pd2Rwc2lndzMyNnZ6ZnluMjB4MTU=","no");
INSERT INTO `wpst_options` VALUES("10048","_transient_timeout_aiowps_captcha_string_info_dgwbh5uf6i","1563194255","no");
INSERT INTO `wpst_options` VALUES("10049","_transient_aiowps_captcha_string_info_dgwbh5uf6i","MTU2MzE5MjQ1NW5pd2Rwc2lndzMyNnZ6ZnluMjB4Ng==","no");
INSERT INTO `wpst_options` VALUES("10050","_transient_timeout_aiowps_captcha_string_info_ak3zjad36e","1563194256","no");
INSERT INTO `wpst_options` VALUES("10051","_transient_aiowps_captcha_string_info_ak3zjad36e","MTU2MzE5MjQ1Nm5pd2Rwc2lndzMyNnZ6ZnluMjB4NA==","no");
INSERT INTO `wpst_options` VALUES("10052","_transient_doing_cron","1563193283.4888439178466796875000","yes");
INSERT INTO `wpst_options` VALUES("9606","widget_elegant_magazine_posts_slider","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9607","widget_elegant_magazine_posts_carousel","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9608","widget_elegant_magazine_single_col_categorised_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9609","widget_elegant_magazine_double_col_categorised_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9610","widget_elegant_magazine_double_col_double_categorised_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9611","widget_elegant_magazine_express_col_categorised_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9612","widget_elegant_magazine_tabbed_posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9613","widget_elegant_magazine_social_contacts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("9614","widget_elegant_magazine_author_info","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wpst_options` VALUES("10020","aiowpsec_db_version","1.9","yes");
INSERT INTO `wpst_options` VALUES("10021","aio_wp_security_configs","a:93:{s:19:\"aiowps_enable_debug\";s:1:\"1\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:1:\"1\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:120;s:28:\"aiowps_set_generic_login_msg\";s:1:\"1\";s:26:\"aiowps_enable_email_notify\";s:1:\"1\";s:20:\"aiowps_email_address\";s:21:\"dsbpsalerts@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:1:\"1\";s:25:\"aiowps_logout_time_period\";i:30;s:39:\"aiowps_enable_invalid_username_lockdown\";s:1:\"1\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:3:{i:0;s:5:\"admin\";i:1;s:13:\"administrator\";i:2;s:8:\"aim-expo\";}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"0rk9zy0eaj8nmu1kohjl\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"niwdpsigw326vzfyn20x\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:4;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:1:\"1\";s:27:\"aiowps_backup_email_address\";s:21:\"dsbpsalerts@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:1:\"1\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:1:\"1\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:1:\"1\";s:33:\"aiowps_spam_ip_min_comments_block\";i:2;s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:1:\"1\";s:25:\"aiowps_fcd_scan_frequency\";i:2;s:24:\"aiowps_fcd_scan_interval\";s:1:\"0\";s:28:\"aiowps_fcd_exclude_filetypes\";s:29:\"jpg
png
bmp
jpeg
svg
gif\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:1:\"1\";s:29:\"aiowps_fcd_scan_email_address\";s:21:\"dsbpsalerts@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:1:\"1\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-05-10 12:29:50\";s:35:\"aiowps_enable_lost_password_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";}","yes");
INSERT INTO `wpst_options` VALUES("10007","_site_transient_timeout_theme_roots","1563191288","no");
INSERT INTO `wpst_options` VALUES("10008","_site_transient_theme_roots","a:2:{s:8:\"blogberg\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";}","no");
INSERT INTO `wpst_options` VALUES("9672","wpseo","a:20:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:4:\"11.6\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1562567064;s:13:\"myyoast-oauth\";b:0;}","yes");
INSERT INTO `wpst_options` VALUES("9673","wpseo_titles","a:74:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:1;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:2:\"»\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";s:1:\"0\";s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";s:1:\"0\";s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:1;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:26:\"taxonomy-category-ptparent\";s:1:\"0\";s:26:\"taxonomy-post_tag-ptparent\";s:1:\"0\";s:29:\"taxonomy-post_format-ptparent\";s:1:\"0\";}","yes");
INSERT INTO `wpst_options` VALUES("9674","wpseo_social","a:19:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wpst_options` VALUES("9675","wpseo_flush_rewrite","1","yes");
INSERT INTO `wpst_options` VALUES("9682","cf7sr_key","6LfXhKwUAAAAABslxsSMf6_ZHujPeXTvhJsVTDXC","yes");
INSERT INTO `wpst_options` VALUES("9683","cf7sr_secret","6LfXhKwUAAAAAHwDl1nnzVQ_FAv1TLn0G6a1fnPO","yes");
INSERT INTO `wpst_options` VALUES("9684","cf7sr_message","","yes");
INSERT INTO `wpst_options` VALUES("9989","_site_transient_timeout_browser_8708a0d4b093d13de2f3df6138e4f82c","1563794162","no");
INSERT INTO `wpst_options` VALUES("9990","_site_transient_browser_8708a0d4b093d13de2f3df6138e4f82c","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"75.0.3770.100\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wpst_options` VALUES("10004","_transient_timeout_plugin_slugs","1563276114","no");
INSERT INTO `wpst_options` VALUES("10005","_transient_plugin_slugs","a:10:{i:0;s:25:\"add-to-any/add-to-any.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:36:\"contact-form-7/wp-contact-form-7.php\";i:4;s:67:\"contact-form-7-simple-recaptcha/contact-form-7-simple-recaptcha.php\";i:5;s:39:\"custom-permalinks/custom-permalinks.php\";i:6;s:41:\"xml-sitemaps-for-videos/video-sitemap.php\";i:7;s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";i:8;s:43:\"remove-category-url/remove-category-url.php\";i:9;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `wpst_options` VALUES("10016","_transient_timeout_wpseo_site_information","1563276023","no");
INSERT INTO `wpst_options` VALUES("10017","_transient_wpseo_site_information","O:8:\"stdClass\":2:{s:3:\"url\";s:24:\"https://www.aim-expo.com\";s:13:\"subscriptions\";a:0:{}}","no");
INSERT INTO `wpst_options` VALUES("10019","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1563189639;s:7:\"checked\";a:10:{s:25:\"add-to-any/add-to-any.php\";s:6:\"1.7.36\";s:19:\"akismet/akismet.php\";s:5:\"4.1.2\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:7:\"4.3.9.4\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.3\";s:67:\"contact-form-7-simple-recaptcha/contact-form-7-simple-recaptcha.php\";s:5:\"0.0.3\";s:39:\"custom-permalinks/custom-permalinks.php\";s:5:\"1.5.1\";s:41:\"xml-sitemaps-for-videos/video-sitemap.php\";s:5:\"2.6.1\";s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";s:5:\"3.2.3\";s:43:\"remove-category-url/remove-category-url.php\";s:5:\"1.1.4\";s:24:\"wordpress-seo/wp-seo.php\";s:4:\"11.6\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:10:{s:25:\"add-to-any/add-to-any.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/add-to-any\";s:4:\"slug\";s:10:\"add-to-any\";s:6:\"plugin\";s:25:\"add-to-any/add-to-any.php\";s:11:\"new_version\";s:6:\"1.7.36\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/add-to-any/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/add-to-any.1.7.36.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/add-to-any/assets/icon-256x256.png?rev=972738\";s:2:\"1x\";s:54:\"https://ps.w.org/add-to-any/assets/icon.svg?rev=972738\";s:3:\"svg\";s:54:\"https://ps.w.org/add-to-any/assets/icon.svg?rev=972738\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/add-to-any/assets/banner-1544x500.png?rev=2037442\";s:2:\"1x\";s:65:\"https://ps.w.org/add-to-any/assets/banner-772x250.png?rev=2037440\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:7:\"4.3.9.4\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"contact-form-7-simple-recaptcha/contact-form-7-simple-recaptcha.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/contact-form-7-simple-recaptcha\";s:4:\"slug\";s:31:\"contact-form-7-simple-recaptcha\";s:6:\"plugin\";s:67:\"contact-form-7-simple-recaptcha/contact-form-7-simple-recaptcha.php\";s:11:\"new_version\";s:5:\"0.0.3\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/contact-form-7-simple-recaptcha/\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/plugin/contact-form-7-simple-recaptcha.0.0.3.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:75:\"https://s.w.org/plugins/geopattern-icon/contact-form-7-simple-recaptcha.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:39:\"custom-permalinks/custom-permalinks.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/custom-permalinks\";s:4:\"slug\";s:17:\"custom-permalinks\";s:6:\"plugin\";s:39:\"custom-permalinks/custom-permalinks.php\";s:11:\"new_version\";s:5:\"1.5.1\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/custom-permalinks/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/custom-permalinks.1.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:62:\"https://ps.w.org/custom-permalinks/assets/icon.svg?rev=1785367\";s:3:\"svg\";s:62:\"https://ps.w.org/custom-permalinks/assets/icon.svg?rev=1785367\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/custom-permalinks/assets/banner-1544x500.png?rev=1796224\";s:2:\"1x\";s:72:\"https://ps.w.org/custom-permalinks/assets/banner-772x250.png?rev=1796224\";}s:11:\"banners_rtl\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/custom-permalinks/assets/banner-772x250-rtl.png?rev=1796224\";}}s:41:\"xml-sitemaps-for-videos/video-sitemap.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/xml-sitemaps-for-videos\";s:4:\"slug\";s:23:\"xml-sitemaps-for-videos\";s:6:\"plugin\";s:41:\"xml-sitemaps-for-videos/video-sitemap.php\";s:11:\"new_version\";s:5:\"2.6.1\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/xml-sitemaps-for-videos/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/xml-sitemaps-for-videos.2.6.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:67:\"https://s.w.org/plugins/geopattern-icon/xml-sitemaps-for-videos.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/really-simple-ssl\";s:4:\"slug\";s:17:\"really-simple-ssl\";s:6:\"plugin\";s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";s:11:\"new_version\";s:5:\"3.2.3\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/really-simple-ssl/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/really-simple-ssl.3.2.3.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/really-simple-ssl/assets/icon-128x128.png?rev=1782452\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/really-simple-ssl/assets/banner-772x250.jpg?rev=1881345\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"remove-category-url/remove-category-url.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/remove-category-url\";s:4:\"slug\";s:19:\"remove-category-url\";s:6:\"plugin\";s:43:\"remove-category-url/remove-category-url.php\";s:11:\"new_version\";s:5:\"1.1.4\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/remove-category-url/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/remove-category-url.1.1.4.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:72:\"https://ps.w.org/remove-category-url/assets/icon-256x256.png?rev=1032792\";s:2:\"1x\";s:64:\"https://ps.w.org/remove-category-url/assets/icon.svg?rev=1032792\";s:3:\"svg\";s:64:\"https://ps.w.org/remove-category-url/assets/icon.svg?rev=1032792\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/remove-category-url/assets/banner-1544x500.png?rev=1032792\";s:2:\"1x\";s:74:\"https://ps.w.org/remove-category-url/assets/banner-772x250.png?rev=1032792\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:4:\"11.6\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wordpress-seo.11.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `wpst_options` VALUES("9934","_site_transient_timeout_browser_bcf1814caa6afe84eeebef28ff236a7f","1563694074","no");
INSERT INTO `wpst_options` VALUES("9935","_site_transient_browser_bcf1814caa6afe84eeebef28ff236a7f","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"75.0.3770.100\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wpst_options` VALUES("9993","_site_transient_timeout_community-events-be55b2d8038d4a0acd02644cf480d845","1563232572","no");
INSERT INTO `wpst_options` VALUES("9994","_site_transient_community-events-be55b2d8038d4a0acd02644cf480d845","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:11:\"202.83.59.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `wpst_options` VALUES("9995","_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3","1563232573","no");
INSERT INTO `wpst_options` VALUES("9996","_transient_feed_9bbd59226dc36b9b26cd43f15694c5c3","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jul 2019 20:20:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.3-alpha-45640\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"People of WordPress: Ugyen Dorji\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/07/people-of-wordpress-ugyen-dorji/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jul 2019 17:20:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:10:\"Interviews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7013\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:386:\"You&#8217;ve probably heard that WordPress is open source software, and may know that it&#8217;s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people&#8217;s lives for the better. This monthly series shares some of those lesser-known, amazing stories. Meet Ugyen Dorji from Bhutan Ugyen lives in Bhutan, a landlocked country [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Aditya Kane\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7264:\"
<p><em>You&#8217;ve probably heard that WordPress is open source software, and may know that it&#8217;s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people&#8217;s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Ugyen Dorji from Bhutan</strong></h2>



<p>Ugyen lives in <a href=\"https://en.wikipedia.org/wiki/Bhutan\">Bhutan</a>, a landlocked country situated between two giant neighbors, India to the south and China to the north. He works for ServMask Inc and is responsible for the Quality Assurance process for All-in-One WP Migration plugin. <br><br>He believes in the Buddhist teaching that “the most valuable service is one rendered to our fellow humans,” and his contributions demonstrates this through his WordPress translation work and multi-lingual support projects for WordPress.</p>



<figure class=\"wp-block-image\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-7023\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?w=1728&amp;ssl=1 1728w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=300%2C225&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=768%2C576&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=1024%2C768&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" /><figcaption>Bhutanese contributors to the Dzongkha locale on WordPress Translation Day</figcaption></figure>



<h2><strong>How Ugyen started his career with WordPress</strong></h2>



<p>Back in 2016, Ugyen was looking for a new job after his former cloud company ran into financial difficulties.</p>



<p>During one interview he was asked many questions about WordPress and, although he had a basic understanding of WordPress, he struggled to give detailed answers. After that interview he resolved to develop his skills and learn as much about WordPress as he could.&nbsp;</p>



<p>A few months passed and he received a call from ServMask Inc, who had developed a plugin called All-in-One WP Migration. They offered him a position, fulfilling his wish to work with WordPress full-time. And because of that, Ugyen is now an active contributor to the WordPress community.</p>



<h3><strong>WordCamp Bangkok 2018</strong></h3>



<p>WordCamp Bangkok 2018 was a turning point event for Ugyen. WordCamps are a great opportunity to meet WordPress community members you don’t otherwise get to know, and he was able to attend his first WordCamp through the sponsorship of his company.</p>



<p>The first day of WordCamp Bangkok was a Contributor Day, where people volunteer to work together to contribute to the development of WordPress. Ugyen joined the Community team to have conversations with WordPress users from all over the world. He was able to share his ideas for supporting new speakers, events and organizers to help build the WordPress community in places where it is not yet booming.</p>



<p>During the main day of the event, Ugyen managed a photo booth for speakers, organizers, and attendees to capture their memories of WordCamp.&nbsp;He also got to take some time out to attend several presentations during the conference. What particularly stuck in Ugyen’s mind was learning that having a website content plan has been shown to lead to 100% growth in business development.</p>



<h3>Co-Organizing<strong> Thimphu</strong>&#8216;s <strong>WordPress Meetup</strong></h3>



<p>After attending WordCamp Bangkok 2018 as well as a local Meetup event, Ugyen decided to&nbsp;introduce WordPress to his home country and cities.&nbsp;</p>



<p>As one of the WordPress Translation Day organizers, he realized that his local language, Dzongkha, was not as fully translated as other languages in the WordPress Core Translation. That is when Ugyen knew that he wanted to help build his local community. He organized Thimphu’s first WordPress Meetup to coincide with WordPress Translation Day 4, and it was a huge success!</p>



<p>Like all WordPress Meetups, the Thimpu WordPress Meetup is an easygoing, volunteer-organized, non-profit meetup which covers everything related to WordPress. But it also keeps in mind the <a href=\"https://en.wikipedia.org/wiki/Gross_National_Happiness\">Bhutanese Gross National Happiness</a> four pillars by aiming to preserve and promote their unique culture and national language.&nbsp;</p>



<h2><strong>Big dreams get accomplished one step at a time</strong></h2>



<p>Ugyen has taken an active role in preserving his national language by encouraging his community to use WordPress, including Dzongkha bloggers, online Dzongkha news outlets, and government websites.</p>



<p>And while Ugyen has only been actively involved in the community for a short period, he has contributed much to the WordPress community, including:</p>



<ul><li>becoming a Translation Contributor for WordPress Core Translation for Dzongkha;</li><li>participating in the <a href=\"https://wptranslationday.org/\">Global WordPress Translation Day 4</a> Livestream and organizing team;</li><li>inviting WordPress Meetup Thimphu members and WordPress experts from other countries to join the <a href=\"https://wpbhutan.slack.com/\">local Slack instance</a>;</li><li>encouraging ServMask Inc. to become an event sponsor;</li><li>providing the Dzongkha Development Commission the opportunity to involve their language experts.</li></ul>



<p>When it comes to WordPress, Ugyen particularly focuses on encouraging local and international language WordPress bloggers;&nbsp;helping startups succeed with WordPress;&nbsp;and sharing what he has learned from WordPress with his Bhutanese WordPress community.</p>



<p>As a contributor, Ugyen hopes to accomplish even more for the Bhutan and Asian WordPress Communities. His dreams for his local community are big, including teaching more people about open source, hosting a local WordCamp, and helping to organize WordCamp Asia in 2020 &#8212; all while raising awareness of his community.</p>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo-1.jpg?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-7026\" width=\"110\" height=\"83\" /></figure></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7013\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: June 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2019/07/the-month-in-wordpress-june-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 10:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7009\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"June has certainly been a busy month in the WordPress community — aside from holding the largest WordPress event ever, the project has hit a number of significant milestones and published some big announcements this past month. A Wrap for WordCamp Europe 2019 WordCamp Europe 2019 took place on June 20-22. It was the largest [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8174:\"
<p>June has certainly been a busy month in the WordPress community — aside from holding the largest WordPress event ever, the project has hit a number of significant milestones and published some big announcements this past month.</p>



<hr class=\"wp-block-separator\" />



<h2>A Wrap for WordCamp Europe 2019</h2>



<p>WordCamp Europe 2019 took place on June 20-22. It was the largest WordPress event ever, with 3,260 tickets sold and 2,734 attendees. The attendees came from 97 different countries and 1,722 of them had never attended WordCamp Europe before.</p>



<p>The event featured 60 speakers who delivered talks and workshops on a variety of topics over two conference days, most notably <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a>’s keynote that included an update on the current status of WordPress Core development, along with a lively Q&amp;A session. The full session from the live stream is <a href=\"https://youtu.be/UE18IsncB7s?t=13033\">available to watch online</a>.</p>



<p>For its eighth year, <a href=\"https://2019.europe.wordcamp.org/2019/06/25/wordcamp-europe-2020/\">WordCamp Europe will take place in Porto, Portugal</a>. The 2020 edition of the event will be held on June 4-6. If you would like to get involved with WordCamp Europe next year, fill out <a href=\"https://2020.europe.wordcamp.org/2019/06/22/call-for-organisers/\">the organizer application form</a>.&nbsp;</p>



<h2>Proposal for XML Sitemaps in WordPress Core</h2>



<p><a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">A proposal this month</a> suggested bringing XML sitemap generation into WordPress Core. This is a feature that has traditionally been handled by plugins, which has resulted in many different implementations across different sites. It also means that many sites do not have XML sitemaps, which can be a problem because they are hugely important to having your site correctly indexed by search engines.</p>



<p>The proposal details how core sitemaps would be structured and how the team would build them, as well as what aspects of WordPress would not be considered appropriate information to be included.</p>



<p>Want to get involved in building this feature? Comment on <a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">the proposal</a>, follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Translation Milestone for the Spanish Community</h2>



<p><a href=\"https://twitter.com/wp_es/status/1138015568563441665\">The WordPress community of Spain has worked hard</a> to make <a href=\"https://translate.wordpress.org/locale/es/\">the es_ES locale</a> the first in the world to fully localize all of WordPress Core along with all Meta projects, apps, and the top 200 plugins. This is made possible by having the largest translation team out of any locale, consisting of 2,951 individual contributors.</p>



<p>Want to get involved in translating WordPress into our locale? Find your locale on <a href=\"https://translate.wordpress.org/\">the translation platform</a>, follow <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team blog</a>, and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>WordPress 5.2.2 Maintenance Release</h2>



<p>On June 18, <a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">v5.2.2 of WordPress was released</a> as a maintenance release, fixing 13 bugs and improving the Site Health feature that was first published in v5.2. If your site has not already been automatically updated to this version, you can <a href=\"https://wordpress.org/download/\">download the update</a> or manually check for updates in your WordPress dashboard. Thanks to <a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> for co-leading this release, as well as the 30 other individuals who contributed to it.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Full End to End Tests for WordPress Core</h2>



<p>On June 27, <a href=\"https://make.wordpress.org/core/2019/06/27/introducing-the-wordpress-e2e-tests/\">e2e (end to end) testing was introduced</a> to WordPress and included in the continuous integration pipeline. E2e testing, which has been successfully used by Gutenberg, is used to simulate real user scenarios and validate process flows. Currently, the setup requires <a href=\"https://docs.docker.com/install/\">Docker</a> to run, and a number of e2e test utilities are already available in the&nbsp; <a href=\"https://github.com/WordPress/gutenberg/tree/master/packages/e2e-test-utils/src\">@wordpress/e2e-test-utils</a> package, in the Gutenberg repository.&nbsp;</p>



<p>Want to use this feature? The more tests that are added, the more stable future releases will be! Follow the <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core-js channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Feature Packages from the Theme Review Team</h2>



<p>Following a <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">proposal for theme feature repositories</a>, an <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">update to the features package was announced</a>. Two new packages have been created that require code review and testing. The first is an Autoload Package, a foundational package for theme developers who are not currently using Composer (although <a href=\"https://getcomposer.org/\">Composer</a> is recommended instead of this package). The second is a Customizer Section Button Package that allows theme authors to create a link/button to any URL.</p>



<p>There are other proposed ideas for packages that require feedback and additional discussion. Want to add your suggestions and thoughts? Join the conversation on the <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">Theme Review team blog</a> and join the #themereview channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>Development continues on the Gutenberg project, with <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\">the latest release</a> including layouts for the Columns block, Snackbar notices, markup improvements, and accessibility upgrades.</li><li>The Community team <a href=\"https://make.wordpress.org/community/2019/06/26/wordcamp-europe-2019-recap-of-community-team-activities-at-contributor-day-plans-for-the-future/\">published the results of their work</a> at the WordCamp Europe contributor day.</li><li>The Polyglots team <a href=\"https://make.wordpress.org/polyglots/2019/06/26/proposal-for-handling-pte-requests/\">has put together a proposal</a> for a new way to handle PTE requests.</li><li>This year’s recipient of the Kim Parsell Memorial Scholarship for WordCamp US <a href=\"https://wordpressfoundation.org/2019/2019-kim-parsell-memorial-scholarship-recipient-carol-gann/\">is Carol Gann</a>.</li><li>The Amurrio WordPress community <a href=\"http://wpamurrio.es/wordpress-amurrio-mega-meetup-i-edition/\">hosted their first “mega meetup”</a> &#8211; this is a great event format that bridges the gap between regular meetup event and WordCamp.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7009\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 5.2.2 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Jun 2019 18:14:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6993\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:348:\"WordPress 5.2.2 is now available! This maintenance release fixes 13 bugs and adds a little bit of polish to the Site Health feature&#160;that made its debut in 5.2. For more info, browse the&#160;full list of changes on Trac or check out the Version 5.2.2 documentation page. WordPress 5.2.2 is a short-cycle maintenance release. The next [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"marybaum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3961:\"
<p>WordPress 5.2.2 is now available! This maintenance release fixes 13 bugs and adds a little bit of polish to the Site Health feature&nbsp;<a href=\"https://wordpress.org/news/2019/05/jaco/\">that made its debut in 5.2</a>. </p>



<p>For more info, browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.2&amp;order=priority\">full list of changes on Trac</a> or check out <a href=\"https://wordpress.org/support/wordpress-version/version-5-2-2/\">the Version 5.2.2 documentation page.</a></p>



<p>WordPress 5.2.2 is a short-cycle maintenance release. The next major release will be version 5.3; check <a href=\"https://make.wordpress.org/core/\">make.wordpress.org/core</a> for details as they happen.  </p>



<p>You can&nbsp;download&nbsp;<a href=\"https://wordpress.org/download/\">WordPress 5.2.2</a>&nbsp;or visit&nbsp;<strong>Dashboard → Updates</strong>&nbsp;and click&nbsp;<strong>Update Now</strong>. Sites that support automatic background updates have already started to update automatically.</p>



<p><a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a> and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> co-led this release, with invaluable guidance from our Executive Director, Josepha Haden Chomphosy, and contributions from 30 other contributors. Thank you to everyone who made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">vaishalipanchal</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>, and <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6993\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"The Month in WordPress: May 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/06/the-month-in-wordpress-may-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Jun 2019 10:21:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6987\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:319:\"This month saw the 16th anniversary since the launch of the first release of WordPress. A significant milestone to be sure and one that speaks to the strength and stability of the project as a whole. In this anniversary month, we saw a new major release of WordPress, some exciting new development work, and a [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6602:\"
<p>This month saw the 16th anniversary since <a href=\"https://wordpress.org/news/2003/05/wordpress-now-available/\">the launch of the first release of WordPress</a>. A significant milestone to be sure and one that speaks to the strength and stability of the project as a whole. In this anniversary month, we saw a new major release of WordPress, some exciting new development work, and a significant global event.</p>



<hr class=\"wp-block-separator\" />



<h2>Release of WordPress 5.2</h2>



<p>WordPress 5.2 “Jaco” <a href=\"https://wordpress.org/news/2019/05/jaco/\">was released on May 7</a> shipping some useful site management tools, such as the Site Health Check and PHP Error Protection, as well as a number of accessibility, privacy, and developer updates. You can read <a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">the field guide for this release</a> for more detailed information about what was included and how it all works.<br></p>



<p>327 individual volunteers contributed to the release. If you would like to be a part of that number for future releases, follow <a href=\"https://make.wordpress.org/core\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>A Successful WordPress Translation Day 4</h2>



<p>WordPress Translation Day is a 24-hour event organised by <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team</a> where community members from all over the world come together to translate WordPress into their local languages. For the fourth edition held on 11 May, 183 brand new contributors joined the Polyglots team from 77 communities across 35 countries in Africa, Asia, Europe, North America, South America, and Oceania.<br></p>



<p>While the WP Translation Day is a great time for focussed contributions to localizing WordPress, but these contributions can happen at any time of the year, so if you would like to help make WordPress available in your local language, follow <a href=\"https://make.wordpress.org/polyglots\">the Polyglots team blog</a> and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Updated Plugin Guidelines Proposal</h2>



<p>The Plugins team <a href=\"https://make.wordpress.org/plugins/2019/05/14/proposal-to-modify-plugin-guidelines/\">has proposed some updates</a> to the guidelines for developers on the Plugin Directory. The majority of the proposed changes are intended to address significant issues faced by developers who do not speak English as a first language, making the Plugin DIrectory a more accessible and beneficial place for everyone.<br></p>



<p>The proposal will be open for comments until late June, so the community is encouraged to get involved with commenting on them and the direction they will take the Plugin Directory. If you would like to be involved in this discussion, comment on <a href=\"https://make.wordpress.org/plugins/2019/05/14/proposal-to-modify-plugin-guidelines/\">the proposal</a> and join the #plugin review team in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Continued Gutenberg Development</h2>



<p>Since the block editor was first released as part of WordPress Core in v5.0, development has continued in leaps and bounds with a new release every two weeks. <a href=\"https://make.wordpress.org/core/2019/05/29/whats-new-in-gutenberg-29th-may/\">The latest update</a> includes some great incremental improvements that will be merged into the 5.2.2 release of WordPress along with the other recent enhancements.<br></p>



<p>In addition to the editor enhancements, work has been ongoing in the Gutenberg project to bring the block editing experience to the rest of the WordPress dashboard. This second phase of the project has been going well and <a href=\"https://make.wordpress.org/design/2019/05/31/gutenberg-phase-2-friday-design-update-20/\">the latest update</a> shows how much work has been done so far.<br></p>



<p>In addition to that, the Block Library project that aims to bring a searchable library of available blocks right into the editor is deep in the planning phase with <a href=\"https://make.wordpress.org/design/2019/05/28/block-library-initial-explorations/\">a recent update</a> showing what direction the team is taking things.<br></p>



<p>If you would like to get involved in planning and development of Gutenberg and the block editor, follow the <a href=\"https://make.wordpress.org/core/\">Core</a> and <a href=\"https://make.wordpress.org/design/\">Design</a> team blogs and join the #core, #design, and #core-editor channels in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The 5.2.2 release of WordPress <a href=\"https://make.wordpress.org/core/2019/05/28/5-2-2-release-agenda/\">is currently in development</a> with a planned release date of 13 June.</li><li>Version 2.1.1 of the WordPress Coding Standards <a href=\"https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/releases/tag/2.1.1\">has been released</a> containing seven small, but relevant fixes.</li><li>The Theme Review Team <a href=\"https://make.wordpress.org/themes/2019/05/07/trusted-authors-changes/\">have updated the details</a> of how the Trusted Authors Program works.</li><li><a href=\"https://make.wordpress.org/community/2019/05/29/who-wants-to-test-the-new-wordcamp-blocks/\">WordCamp-specific blocks have been launched for WordCamp sites</a> with organizers needing to sign up in order to test them out.</li><li>Continuing the growing trend of other platforms adopting the Gutenberg editor, it has now <a href=\"https://octobercms.com/plugin/reazzon-gutenberg\">been ported to a plugin for OctoberCMS</a>.</li><li>Version 3.0 of the popular WordPress development environment, Varying Vagrant Vagrants (VVV), <a href=\"https://varyingvagrantvagrants.org/blog/2019/05/15/vvv-3-0-0.html\">was released this month</a>.</li><li>The Community Team <a href=\"https://make.wordpress.org/community/2019/05/31/the-4-gets-in-wordpress-community-organizing/\">published some info</a> clarifying what organizers get (and don’t get) from being involved with their local communities. </li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em><br></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6987\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 5.2.1 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/05/wordpress-5-2-1-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 May 2019 19:04:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:5:\"5.2.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6976\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:405:\"WordPress 5.2.1 is now available! This maintenance release fixes 33 bugs, including improvements to the block editor, accessibility, internationalization, and the Site Health feature introduced in 5.2. You can browse the&#160;full list of changes on Trac. WordPress 5.2.1 is a short-cycle maintenance release. Version 5.2.2 is expected to follow in approximately two weeks. You can&#160;download [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Jonathan Desrosiers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4923:\"
<p>WordPress 5.2.1 is now available! This maintenance release fixes 33 bugs, including improvements to the block editor, accessibility, internationalization, and the Site Health feature <a href=\"https://wordpress.org/news/2019/05/jaco/\">introduced in 5.2</a>.</p>



<p>You can browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.1&amp;order=priority\">full list of changes on Trac</a>.</p>



<p>WordPress 5.2.1 is a short-cycle maintenance release. <a href=\"https://core.trac.wordpress.org/query?milestone=5.2.2\">Version 5.2.2</a> is expected to follow in approximately two weeks.</p>



<p>You can&nbsp;download <a href=\"https://wordpress.org/download/\">WordPress 5.2.1</a>&nbsp;or visit <strong>Dashboard → Updates</strong> and click&nbsp;<strong>Update Now</strong>. Sites that support automatic background updates have already started to update automatically.</p>



<p>Jonathan Desrosiers and William Earnhardt co-led this release, with contributions from 52 other contributors. Thank you to everyone that made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/xavortm/\">Alex Dimitrov</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/anischarolia/\">anischarolia</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chesio/\">chesio</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/daxelrod/\">daxelrod</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/odminstudios/\">Dima</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/edocev/\">Emil Dotsev</a>, <a href=\"https://profiles.wordpress.org/sachyya-sachet/\">ghoul</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Grzegorz (Greg) Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/gwwar/\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/imath/\">imath</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>, <a href=\"https://profiles.wordpress.org/jrf/\">jrf</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">kjellr</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mikengarrett/\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/onlanka/\">onlanka</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">paragoninitiativeenterprises</a>, <a href=\"https://profiles.wordpress.org/parkcityj/\">parkcityj</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/sebastienserre/\">Sébastien SERRE</a>, <a href=\"https://profiles.wordpress.org/tfrommen/\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph/\">timph</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tonybogdanov/\">tonybogdanov</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, and <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6976\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"Tomorrow is WordPress Translation Day 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/news/2019/05/tomorrow-is-wordpress-translation-day-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 May 2019 09:17:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:13:\"Documentation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6961\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:342:\"The fourth edition of WordPress translation day is coming up on Saturday 11 May 2019: tomorrow! Get ready for a 24-hour, global marathon dedicated to localizing the WordPress platform and ecosystem. This event takes place both online and in physical locations across the world, so you can join no matter where you are! The WordPress [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3747:\"
<p><em>The fourth edition of WordPress translation day is coming up on Saturday 11 May 2019: tomorrow! Get ready for a 24-hour, global marathon dedicated to localizing the WordPress platform and ecosystem.</em> <em>This event takes place both online and in physical locations across the world, so you can join no matter where you are! </em></p>



<p>The <a href=\"https://make.wordpress.org/polyglots/\">WordPress Polyglots Team</a> has a mission to translate and make available the software’s features into as many languages as possible. As WordPress powers more than 33% of websites, people from across the world use it in their daily life. That means there is a lot that needs translating, and into many different languages. </p>



<p>On 11 May 2019, from 00:00 UTC until 23:59 UTC, <a href=\"https://wptranslationday.org/\">WordPress Translation Day</a> aims to celebrate the thousands of volunteers who contribute to translation and internalization. The event is also an opportunity for encouraging more people to get involved and help increase the availability of themes and plugins in different languages.</p>



<figure class=\"wp-block-pullquote\"><blockquote><p>&#8220;At the time of the last event in 2017, WordPress was being translated into 178 languages, we have now reached the 200 mark!&#8221;</p><cite>WPtranslationday.org</cite></blockquote></figure>



<h2>What happens on WordPress Translation Day?</h2>



<p>There are a number of <a href=\"https://wptranslationday.org/the-local-events/\">local meetings all over the world</a>, as well as online talks by people from the WordPress community. More than 700 people from around the world took part in past WordPress Translation Days, and everyone welcome to join in this time around!</p>



<p>Everyone is welcome to join the event to help translate and localize WordPress, no matter their level of experience. A lot is happening on the day, so join in and you will learn how to through online sessions!</p>



<h3>What can you expect?</h3>



<ul><li><strong>Live online training</strong>: Tutorials in different languages focused on translation and <em>localization</em>, or l10n, of WordPress. These are streamed in multiple languages</li><li><strong>Localization sessions</strong>: General instruction and specifics for particular areas and languages. These sessions are streamed in multiple languages.</li><li><strong>Internalization sessions</strong>: Tutorials about optimizing the code to ease localization processes, also called <em>internationalization</em> or i18n. These sessions are streamed in English.</li><li><strong>Local events</strong>: Polyglot contributors will gather around the world for socializing, discussing, and translating together.</li><li><strong>Remote events</strong>: Translation teams that cannot gather physically, will connect remotely. They will be available for training, mentoring, and supporting new contributors. They will also engage in &#8220;translating marathons&#8221;, in which existing teams translate as many strings as they can!</li></ul>



<p>A number of experienced WordPress translators and internationalization experts are part of the line-up for the livestream, joined by some first time contributors. </p>



<p>Whether you have or haven&#8217;t contributed to the Polyglots before, you can join in for WordPress Translation Day. Learn more about both local and online events and stay updated through the website and social media. </p>



<ul><li><a href=\"https://wptranslationday.org/\">WordPress Translation Day website</a></li><li><a href=\"https://twitter.com/translatewp\">WordPress Translation Day Twitter</a></li><li><a href=\"https://www.facebook.com/WPTranslationDay/\">WordPress Translation Day Facebook</a></li></ul>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6961\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"WordPress 5.2 “Jaco”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/news/2019/05/jaco/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 May 2019 21:03:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6925\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:426:\"Version 5.2 of WordPress is available for download or update in your WordPress dashboard. New features in this update make it easier than ever to fix your site if something goes wrong. There are even more robust tools for identifying and fixing configuration issues and fatal errors. Whether you are a developer helping clients or you manage your site solo, these tools can help get you the right information when you need it.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:32081:\"
<h2 style=\"text-align:center\">Keeping Sites Safer</h2>



<figure class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?fit=632%2C500&amp;ssl=1\" alt=\"\" class=\"wp-image-6926\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?w=1206&amp;ssl=1 1206w, https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?resize=300%2C237&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?resize=768%2C608&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?resize=1024%2C810&amp;ssl=1 1024w\" sizes=\"(max-width: 632px) 100vw, 632px\" /></figure>



<p>Version 5.2 of WordPress, named “Jaco” in honor of renowned and revolutionary jazz bassist Jaco Pastorius, is available for download or update in your WordPress dashboard. New features in this update make it easier than ever to fix your site if something goes wrong.</p>



<p>There are even more robust tools for identifying and fixing configuration issues and fatal errors. Whether you are a developer helping clients or you manage your site solo, these tools can help get you the right information when you need it.</p>



<hr class=\"wp-block-separator\" />



<h3>Site Health Check</h3>



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/05/about_site-health.png?resize=205%2C143&#038;ssl=1\" alt=\"\" class=\"wp-image-6927\" width=\"205\" height=\"143\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2019/05/about_site-health.png?w=609&amp;ssl=1 609w, https://i2.wp.com/wordpress.org/news/files/2019/05/about_site-health.png?resize=300%2C210&amp;ssl=1 300w\" sizes=\"(max-width: 205px) 100vw, 205px\" data-recalc-dims=\"1\" /></figure></div>



<p>Building on the <a href=\"https://wordpress.org/news/2019/02/betty/\">Site Health</a> features introduced in 5.1, this release adds two new pages to help debug common configuration issues. It also adds space where developers can include debugging information for site maintainers.</p>



<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h3>PHP Error Protection</h3>



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_error-protection.png?resize=202%2C228&#038;ssl=1\" alt=\"\" class=\"wp-image-6930\" width=\"202\" height=\"228\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_error-protection.png?w=487&amp;ssl=1 487w, https://i1.wp.com/wordpress.org/news/files/2019/05/about_error-protection.png?resize=267%2C300&amp;ssl=1 267w\" sizes=\"(max-width: 202px) 100vw, 202px\" data-recalc-dims=\"1\" /></figure></div>



<p>This administrator-focused update will let you safely fix or manage fatal errors without requiring developer time. It features better handling of the so-called “white screen of death,” and a way to enter recovery mode, &nbsp;which pauses error-causing plugins or themes.</p>



<div style=\"height:79px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<hr class=\"wp-block-separator\" />



<h2 style=\"text-align:center\">Improvements for Everyone</h2>



<h3>Accessibility Updates</h3>



<p>A number of changes work together to improve contextual awareness and keyboard navigation flow for those using screen readers and other assistive technologies.</p>



<h3>New Dashboard Icons</h3>



<p>Thirteen new icons including Instagram, a suite of icons for BuddyPress, and rotated Earth icons for global inclusion. Find them in the Dashboard and have some fun!</p>



<h3>Plugin Compatibility Checks</h3>



<p>WordPress will now automatically determine if your site’s version of PHP is compatible with installed plugins. If the plugin requires a higher version of PHP than your site currently uses, WordPress will not allow you to activate it, preventing potential compatibility errors.</p>



<hr class=\"wp-block-separator\" />



<h2 style=\"text-align:center\">Developer Happiness</h2>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<p><a href=\"https://make.wordpress.org/core/2019/03/26/coding-standards-updates-for-php-5-6/\"><strong>PHP Version Bump</strong></a><strong> </strong></p>



<p>The minimum supported PHP version is now 5.6.20. As of WordPress 5.2*, themes and plugins can safely take advantage of namespaces, anonymous functions, and more!</p>
</div>



<div class=\"wp-block-column\">
<p><a href=\"https://make.wordpress.org/core/2019/04/24/developer-focused-privacy-updates-in-5-2/\"><strong>Privacy Updates</strong></a><strong> </strong></p>



<p>A new theme page template, a conditional function, and two CSS classes make designing and customizing the Privacy Policy page easier.</p>
</div>
</div>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<p><strong><a href=\"https://make.wordpress.org/core/2019/04/24/miscellaneous-developer-updates-in-5-2/\">New Body Hook</a> </strong></p>



<p>5.2 introduces a wp_body_open hook, which lets themes support injecting code right at the beginning of the &lt;body&gt; element.</p>
</div>



<div class=\"wp-block-column\">
<p><a href=\"https://make.wordpress.org/core/2019/03/25/building-javascript/\"><strong>Building JavaScript</strong></a></p>



<p>With the addition of webpack and Babel configurations in the wordpress/scripts package, developers won&#8217;t have to worry about setting up complex build tools to write modern JavaScript.</p>
</div>
</div>



<p><em>*If you are running an old version of PHP (less than 5.6.20), <a href=\"https://wordpress.org/support/update-php/\">update your PHP</a> before installing 5.2.</em></p>



<hr class=\"wp-block-separator\" />



<h2>The Squad</h2>



<p>This release was led by&nbsp;<a href=\"http://ma.tt/\">Matt Mullenweg</a>, <a href=\"https://josepha.blog/\">Josepha Haden Chomphosy</a>, and&nbsp;<a href=\"https://pento.net/\">Gary Pendergast</a>. They were graciously supported by 327 generous volunteer contributors. Load a Jaco Pastorius playlist on your favorite music service and check out some of their profiles:</p>


<a href=\"https://profiles.wordpress.org/aaroncampbell/\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/adamsoucie/\">Adam Soucie</a>, <a href=\"https://profiles.wordpress.org/oztaser/\">Adil &#214;ztaşer</a>, <a href=\"https://profiles.wordpress.org/ajitbohra/\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/aldavigdis/\">Alda Vigd&#237;s</a>, <a href=\"https://profiles.wordpress.org/alexdenning/\">Alex Denning</a>, <a href=\"https://profiles.wordpress.org/xavortm/\">Alex Dimitrov</a>, <a href=\"https://profiles.wordpress.org/akirk/\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/viper007bond/\">Alex Mills</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/lexiqueen/\">Alexis</a>, <a href=\"https://profiles.wordpress.org/alexislloyd/\">Alexis Lloyd</a>, <a href=\"https://profiles.wordpress.org/allancole/\">allancole</a>, <a href=\"https://profiles.wordpress.org/allendav/\">Allen Snook</a>, <a href=\"https://profiles.wordpress.org/arena/\">Andr?</a>, <a href=\"https://profiles.wordpress.org/andraganescu/\">andraganescu</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton/\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/euthelup/\">Andrei Lupu</a>, <a href=\"https://profiles.wordpress.org/aandrewdixon/\">Andrew Dixon</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/nacin/\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey \"Rarst\" Savchenko</a>, <a href=\"https://profiles.wordpress.org/nosolosw/\">Andrés Maneiro</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/andizer/\">Andy Meerwaldt</a>, <a href=\"https://profiles.wordpress.org/aniketpatel/\">Aniket Patel</a>, <a href=\"https://profiles.wordpress.org/anischarolia/\">anischarolia</a>, <a href=\"https://profiles.wordpress.org/atimmer/\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/vanyukov/\">Anton Vanyukov</a>, <a href=\"https://profiles.wordpress.org/avillegasn/\">Antonio Villegas</a>, <a href=\"https://profiles.wordpress.org/antonypuckey/\">antonypuckey</a>, <a href=\"https://profiles.wordpress.org/aristath/\">Ari Stathopoulos</a>, <a href=\"https://profiles.wordpress.org/wpboss/\">Aslam Shekh</a>, <a href=\"https://profiles.wordpress.org/axaak/\">axaak</a>, <a href=\"https://profiles.wordpress.org/pixolin/\">Bego Mario Garde</a>, <a href=\"https://profiles.wordpress.org/empireoflight/\">Ben Dunkle</a>, <a href=\"https://profiles.wordpress.org/britner/\">Ben Ritner - Kadence Themes</a>, <a href=\"https://profiles.wordpress.org/bfintal/\">Benjamin Intal</a>, <a href=\"https://profiles.wordpress.org/billerickson/\">Bill Erickson</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson</a>, <a href=\"https://profiles.wordpress.org/bodohugobarwich/\">Bodo (Hugo) Barwich</a>, <a href=\"https://profiles.wordpress.org/gitlost/\">bonger</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bradleyt/\">Bradley Taylor</a>, <a href=\"https://profiles.wordpress.org/kraftbj/\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/brentswisher/\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/burhandodhy/\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cathibosco1/\">Cathi Bosco</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chiaralovelaces/\">Chiara Magnani</a>, <a href=\"https://profiles.wordpress.org/chouby/\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten/\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/dswebsme/\">D.S. Webster</a>, <a href=\"https://profiles.wordpress.org/colorful-tones/\">Damon Cook</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber/\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/danieltj/\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/mte90/\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/nerrad/\">Darren Ethier</a>, <a href=\"https://profiles.wordpress.org/drw158/\">Dave Whitley</a>, <a href=\"https://profiles.wordpress.org/davefx/\">DaveFX</a>, <a href=\"https://profiles.wordpress.org/davetgreen/\">davetgreen</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/david.binda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dgroddick/\">David Roddick</a>, <a href=\"https://profiles.wordpress.org/get_dave/\">David Smith</a>, <a href=\"https://profiles.wordpress.org/folletto/\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/daxelrod/\">daxelrod</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/dekervit/\">dekervit</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy/\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/dmsnell/\">Dennis Snell</a>, <a href=\"https://profiles.wordpress.org/valendesigns/\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/pcfreak30/\">Derrick Hammer</a>, <a href=\"https://profiles.wordpress.org/designsimply/\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dhanukanuwan/\">Dhanukanuwan</a>, <a href=\"https://profiles.wordpress.org/dharm1025/\">Dharmesh Patel</a>, <a href=\"https://profiles.wordpress.org/dianeco/\">Diane</a>, <a href=\"https://profiles.wordpress.org/diegoreymendez/\">diegoreymendez</a>, <a href=\"https://profiles.wordpress.org/dilipbheda/\">Dilip Bheda</a>, <a href=\"https://profiles.wordpress.org/odminstudios/\">Dima</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dency/\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/iamdmitrymayorov/\">Dmitry Mayorov</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/drewapicture/\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dsifford/\">dsifford</a>, <a href=\"https://profiles.wordpress.org/seedsca/\">EcoTechie</a>, <a href=\"https://profiles.wordpress.org/etoledom/\">Eduardo Toledo</a>, <a href=\"https://profiles.wordpress.org/iseulde/\">Ella Van Durpe</a>, <a href=\"https://profiles.wordpress.org/edocev/\">Emil Dotsev</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy/\">fabiankaegy</a>, <a href=\"https://profiles.wordpress.org/faisal03/\">Faisal Alvi</a>, <a href=\"https://profiles.wordpress.org/parsmizban/\">Farhad Sakhaei</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/peaceablewhale/\">Franklin Tse</a>, <a href=\"https://profiles.wordpress.org/fuegas/\">Fuegas</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj/\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/sachyya-sachet/\">ghoul</a>, <a href=\"https://profiles.wordpress.org/girishpanchal/\">Girish Panchal</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Grzegorz Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/wido/\">Guido Scialfa</a>, <a href=\"https://profiles.wordpress.org/gutendev/\">GutenDev <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/270d.png\" alt=\"✍\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/3299.png\" alt=\"㊙\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></a>, <a href=\"https://profiles.wordpress.org/gwwar/\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hannahmalcolm/\">Hannah Malcolm</a>, <a href=\"https://profiles.wordpress.org/hardik-amipara/\">Hardik Amipara</a>, <a href=\"https://profiles.wordpress.org/thakkarhardik/\">Hardik Thakkar</a>, <a href=\"https://profiles.wordpress.org/luehrsen/\">Hendrik Luehrsen</a>, <a href=\"https://profiles.wordpress.org/henrywright-1/\">Henry</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/ryanshoover/\">Hoover</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ice9js/\">ice9js</a>, <a href=\"https://profiles.wordpress.org/zinigor/\">Igor Zinovyev</a>, <a href=\"https://profiles.wordpress.org/imath/\">imath</a>, <a href=\"https://profiles.wordpress.org/ixium/\">Ixium</a>, <a href=\"https://profiles.wordpress.org/jdgrimes/\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jakeparis/\">jakeparis</a>, <a href=\"https://profiles.wordpress.org/cc0a/\">James</a>, <a href=\"https://profiles.wordpress.org/janak007/\">janak Kaneriya</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/jarred-kennedy/\">Jarred Kennedy</a>, <a href=\"https://profiles.wordpress.org/vengisss/\">Javier Villanueva</a>, <a href=\"https://profiles.wordpress.org/jayupadhyay01/\">Jay Upadhyay</a>, <a href=\"https://profiles.wordpress.org/jaydeep-rami/\">Jaydip Rami</a>, <a href=\"https://profiles.wordpress.org/parkcityj/\">Jaye Simons</a>, <a href=\"https://profiles.wordpress.org/jaymanpandya/\">Jayman Pandya</a>, <a href=\"https://profiles.wordpress.org/jdeeburke/\">jdeeburke</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jean-Baptiste Audras</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/cheffheid/\">Jeffrey de Wit</a>, <a href=\"https://profiles.wordpress.org/miss_jwo/\">Jenny Wong</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/endocreative/\">Jeremy Green</a>, <a href=\"https://profiles.wordpress.org/jeherve/\">Jeremy Herve</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/joedolson/\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/j-falk/\">Johan Falk</a>, <a href=\"https://profiles.wordpress.org/johannadevos/\">Johanna de Vos</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jonathandejong/\">Jonathandejong</a>, <a href=\"https://profiles.wordpress.org/joneiseman/\">joneiseman</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonnybojangles/\">jonnybojangles</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jordesign/\">jordesign</a>, <a href=\"https://profiles.wordpress.org/koke/\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/keraweb/\">Jory Hogeveen</a>, <a href=\"https://profiles.wordpress.org/jcastaneda/\">Jose Castaneda</a>, <a href=\"https://profiles.wordpress.org/josephwa/\">josephwa</a>, <a href=\"https://profiles.wordpress.org/builtbynorthby/\">Josh Feck</a>, <a href=\"https://profiles.wordpress.org/joshuawold/\">JoshuaWold</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/jplojohn/\">jplo</a>, <a href=\"https://profiles.wordpress.org/jrtashjian/\">JR Tashjian</a>, <a href=\"https://profiles.wordpress.org/jrf/\">jrf</a>, <a href=\"https://profiles.wordpress.org/juiiee8487/\">Juhi Patel</a>, <a href=\"https://profiles.wordpress.org/juliarrr/\">juliarrr</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/kadamwhite/\">K. Adam White</a>, <a href=\"https://profiles.wordpress.org/kamataryo/\">KamataRyo</a>, <a href=\"https://profiles.wordpress.org/karinedo/\">Karine Do</a>, <a href=\"https://profiles.wordpress.org/katyatina/\">Katyatina</a>, <a href=\"https://profiles.wordpress.org/kelin1003/\">Kelin Chauhan</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/itzmekhokan/\">Khokan Sardar</a>, <a href=\"https://profiles.wordpress.org/killua99/\">killua99</a>, <a href=\"https://profiles.wordpress.org/ixkaito/\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/knutsp/\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/olein/\">Koji Kuno</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon/\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/codemascot/\">Kʜᴀɴ (ಠ_ಠ)</a>, <a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/lkraav/\">lkraav</a>, <a href=\"https://profiles.wordpress.org/lovingboth/\">lovingboth</a>, <a href=\"https://profiles.wordpress.org/lukecarbis/\">Luke Carbis</a>, <a href=\"https://profiles.wordpress.org/lgedeon/\">Luke Gedeon</a>, <a href=\"https://profiles.wordpress.org/lukepettway/\">Luke Pettway</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">Maciej Palmowski</a>, <a href=\"https://profiles.wordpress.org/maedahbatool/\">Maedah Batool</a>, <a href=\"https://profiles.wordpress.org/travel_girl/\">Maja Benke</a>, <a href=\"https://profiles.wordpress.org/malae/\">Malae</a>, <a href=\"https://profiles.wordpress.org/manzoorwanijk/\">Manzoor Wani</a>, <a href=\"https://profiles.wordpress.org/robobot3000/\">Marcin</a>, <a href=\"https://profiles.wordpress.org/iworks/\">Marcin Pietrzak</a>, <a href=\"https://profiles.wordpress.org/marcofernandes/\">Marco Fernandes</a>, <a href=\"https://profiles.wordpress.org/marco-peralta/\">Marco Peralta</a>, <a href=\"https://profiles.wordpress.org/mkaz/\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/marekhrabe/\">marekhrabe</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/mbelchev/\">Mariyan Belchev</a>, <a href=\"https://profiles.wordpress.org/mapk/\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/markcallen/\">markcallen</a>, <a href=\"https://profiles.wordpress.org/mechter/\">Markus Echterhoff</a>, <a href=\"https://profiles.wordpress.org/m-e-h/\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">marybaum</a>, <a href=\"https://profiles.wordpress.org/mattnyeus/\">mattnyeus</a>, <a href=\"https://profiles.wordpress.org/mdwolinski/\">mdwolinski</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mheikkila/\">mheikkila</a>, <a href=\"https://profiles.wordpress.org/wpscholar/\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/michelleweber/\">michelleweber</a>, <a href=\"https://profiles.wordpress.org/mcsf/\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/mmtr86/\">Miguel Torres</a>, <a href=\"https://profiles.wordpress.org/simison/\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mauteri/\">Mike Auteri</a>, <a href=\"https://profiles.wordpress.org/mikeschinkel/\">Mike Schinkel [WPLib Box project lead]</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeselander/\">Mike Selander</a>, <a href=\"https://profiles.wordpress.org/mikengarrett/\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/0mirka00/\">mirka</a>, <a href=\"https://profiles.wordpress.org/lord_viper/\">Mobin Ghasempoor</a>, <a href=\"https://profiles.wordpress.org/mohadeseghasemi/\">Mohadese Ghasemi</a>, <a href=\"https://profiles.wordpress.org/saimonh/\">Mohammed Saimon</a>, <a href=\"https://profiles.wordpress.org/mor10/\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/man4toman/\">Morteza Geransayeh</a>, <a href=\"https://profiles.wordpress.org/mmuhsin/\">Muhammad Muhsin</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/m_uysl/\">Mustafa Uysal</a>, <a href=\"https://profiles.wordpress.org/mzorz/\">mzorz</a>, <a href=\"https://profiles.wordpress.org/nfmohit/\">Nahid Ferdous Mohit</a>, <a href=\"https://profiles.wordpress.org/naoki0h/\">Naoki Ohashi</a>, <a href=\"https://profiles.wordpress.org/nateallen/\">Nate Allen</a>, <a href=\"https://profiles.wordpress.org/greatislander/\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/neobabis/\">Neokazis Charalampos</a>, <a href=\"https://profiles.wordpress.org/modernnerd/\">Nick Cernis</a>, <a href=\"https://profiles.wordpress.org/ndiego/\">Nick Diego</a>, <a href=\"https://profiles.wordpress.org/celloexpressions/\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/jainnidhi/\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/nielslange/\">Niels</a>, <a href=\"https://profiles.wordpress.org/nielsdeblaauw/\">Niels de Blaauw</a>, <a href=\"https://profiles.wordpress.org/nnikolov/\">Nikolay Nikolov</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/ninio/\">ninio</a>, <a href=\"https://profiles.wordpress.org/notnownikki/\">notnownikki</a>, <a href=\"https://profiles.wordpress.org/bulletdigital/\">Oliver Sadler</a>, <a href=\"https://profiles.wordpress.org/onlanka/\">onlanka</a>, <a href=\"https://profiles.wordpress.org/pandelisz/\">pandelisz</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pbearne/\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendon&#231;a</a>, <a href=\"https://profiles.wordpress.org/peterbooker/\">Peter Booker</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/pfiled/\">pfiled</a>, <a href=\"https://profiles.wordpress.org/pilou69/\">pilou69</a>, <a href=\"https://profiles.wordpress.org/pranalipatel/\">Pranali Patel</a>, <a href=\"https://profiles.wordpress.org/pratikthink/\">Pratik</a>, <a href=\"https://profiles.wordpress.org/pratikkry/\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/psealock/\">psealock</a>, <a href=\"https://profiles.wordpress.org/punit5658/\">Punit Patel</a>, <a href=\"https://profiles.wordpress.org/bamadesigner/\">Rachel Cherry</a>, <a href=\"https://profiles.wordpress.org/rahmon/\">Rahmon</a>, <a href=\"https://profiles.wordpress.org/superpoincare/\">Ramanan</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/ramizmanked/\">Ramiz Manked</a>, <a href=\"https://profiles.wordpress.org/ramonopoly/\">ramonopoly</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rinatkhaziev/\">Rinat Khaziev</a>, <a href=\"https://profiles.wordpress.org/noisysocks/\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/rsusanto/\">Rudy Susanto</a>, <a href=\"https://profiles.wordpress.org/ryan/\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/welcher/\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/sebastienserre/\">S&#233;bastien SERRE</a>, <a href=\"https://profiles.wordpress.org/saeedfard/\">Saeed Fard</a>, <a href=\"https://profiles.wordpress.org/salcode/\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/salar6990/\">Salar Gholizadeh</a>, <a href=\"https://profiles.wordpress.org/samanehmirrajabi/\">Samaneh Mirrajabi</a>, <a href=\"https://profiles.wordpress.org/samikeijonen/\">Sami Keijonen</a>, <a href=\"https://profiles.wordpress.org/elhardoum/\">Samuel Elh</a>, <a href=\"https://profiles.wordpress.org/sgarza/\">Santiago Garza</a>, <a href=\"https://profiles.wordpress.org/saracope/\">Sara Cope</a>, <a href=\"https://profiles.wordpress.org/saracup/\">saracup</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">Scott Arciszewski</a>, <a href=\"https://profiles.wordpress.org/coffee2code/\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/sebastianpisula/\">Sebastian Pisula</a>, <a href=\"https://profiles.wordpress.org/ebrahimzadeh/\">Sekineh Ebrahimzadeh</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sergioestevao/\">SergioEstevao</a>, <a href=\"https://profiles.wordpress.org/sgastard/\">sgastard</a>, <a href=\"https://profiles.wordpress.org/sharifkiberu/\">sharifkiberu</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/shazdeh/\">shazdeh</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/sky_76/\">sky_76</a>, <a href=\"https://profiles.wordpress.org/soean/\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevenkword/\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/sudar/\">Sudar Muthu</a>, <a href=\"https://profiles.wordpress.org/sudhiryadav/\">Sudhir Yadav</a>, <a href=\"https://profiles.wordpress.org/szepeviktor/\">szepe.viktor</a>, <a href=\"https://profiles.wordpress.org/miyauchi/\">Takayuki Miyauchi</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/themonic/\">Themonic</a>, <a href=\"https://profiles.wordpress.org/thomstark/\">thomstark</a>, <a href=\"https://profiles.wordpress.org/tfrommen/\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith/\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hedgefield</a>, <a href=\"https://profiles.wordpress.org/timwright12/\">Tim Wright</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph/\">timph</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/ohiosierra/\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tmdesigned/\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tz-media/\">Tobias Zimpel</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tomharrigan/\">TomHarrigan</a>, <a href=\"https://profiles.wordpress.org/tonybogdanov/\">tonybogdanov</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/toro_unit/\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/torres126/\">torres126</a>, <a href=\"https://profiles.wordpress.org/zodiac1978/\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/itowhid06/\">Towhidul Islam</a>, <a href=\"https://profiles.wordpress.org/liljimmi/\">Tracy Levesque</a>, <a href=\"https://profiles.wordpress.org/umang7/\">Umang Bhanvadia</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>, <a href=\"https://profiles.wordpress.org/webfactory/\">WebFactory</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/wfmattr/\">WFMattR</a>, <a href=\"https://profiles.wordpress.org/bahia0019/\">William \'Bahia\' Bay</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton/\">williampatton</a>, <a href=\"https://profiles.wordpress.org/willscrlt/\">Willscrlt</a>, <a href=\"https://profiles.wordpress.org/wolly/\">Wolly aka Paolo Valenti</a>, <a href=\"https://profiles.wordpress.org/wrwrwr0/\">wrwrwr0</a>, <a href=\"https://profiles.wordpress.org/yoavf/\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/zebulan/\">Zebulan Stanphill</a>, and <a href=\"https://profiles.wordpress.org/chesio/\">Česlav Przywara</a>.



<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<p>Also, many thanks to all of the community volunteers who contribute in the <a href=\"https://wordpress.org/support/\">support forums</a>. They answer questions from people across the world, whether they are using WordPress for the first time or since the first release. These releases are more successful for their efforts!</p>



<p>If you want learn more about volunteering with WordPress, check out&nbsp;<a href=\"https://make.wordpress.org/\">Make WordPress</a>&nbsp;or the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>



<p>Thanks for choosing WordPress!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6925\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordPress 5.2 RC2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/2019/05/wordpress-5-2-rc2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 May 2019 16:17:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6914\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:326:\"The second release candidate for WordPress 5.2 is now available! WordPress 5.2 will be released on Tuesday, May 7, but we need your help to get there—if you haven’t tried 5.2 yet, now is the time! There are two ways to test the WordPress 5.2 release candidate: try the WordPress Beta Tester plugin (you’ll want [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2472:\"
<p>The second release candidate for WordPress 5.2 is now available!</p>



<p>WordPress 5.2 will be released on <strong><a href=\"https://make.wordpress.org/core/5-2/\">Tuesday, May 7</a></strong>, but we need <em>your</em> help to get there—if you haven’t tried 5.2 yet, now is the time!</p>



<p>There are two ways to test the WordPress 5.2 release candidate: try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want to select the “bleeding edge nightlies” option), or you can <a href=\"https://wordpress.org/wordpress-5.2-RC2.zip\">download the release candidate here</a> (zip).</p>



<p>For details about what to expect in WordPress 5.2, please see the <a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-release-candidate/\">first release candidate post</a>.</p>



<p>This release includes the final About page design. It also contains fixes for:</p>



<ul><li>Proper translation of the recovery mode notification emails (#47093).</li><li>Improvements to the way Site Health works with multisite installs (#47084).</li></ul>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.2 and update the <em>Tested up to</em> version in the readme to 5.2. If you find compatibility problems, please be sure to post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a> so we can figure those out before the final release.</p>



<p>The&nbsp;<a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">WordPress 5.2 Field Guide</a>&nbsp;has also been published, which details the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a></p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>



<hr class=\"wp-block-separator\" />



<p><em>It&#8217;s the start of May<br>and the release is coming.<br>We all give a cheer!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6914\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"The Month in WordPress: April 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2019/05/the-month-in-wordpress-april-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 May 2019 09:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6918\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"This past month has been filled with anticipation as the community builds up towards a big new release, plans some important events, and builds new tools to grow the future of the project. WordPress 5.2 Almost Due for Release WordPress 5.2 is due for release on May 7 with many new features included for developers [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8386:\"
<p>This past month has been filled with anticipation as the community builds up towards a big new release, plans some important events, and builds new tools to grow the future of the project.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.2 Almost Due for Release</h2>



<p>WordPress 5.2 is due for release on May 7 with many new features included for developers and end-users alike. <a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">The Field Guide for the release</a> provides a lot of information about what is in it and what you can expect, including a few key elements:</p>



<h3>Site Health Check</h3>



<p>One of the most highly anticipated features for v5.2 is <a href=\"https://make.wordpress.org/core/2019/04/25/site-health-check-in-5-2/\">the Site Health Check</a>. This feature adds two new pages in the admin interface to help end users maintain a healthy site through common configuration issues and other elements that go along with having a robust online presence. It also provides a standardized location for developers to add debugging information.</p>



<h3>Fatal Error Recovery Mode</h3>



<p><a href=\"https://make.wordpress.org/core/2019/04/16/fatal-error-recovery-mode-in-5-2/\">The Fatal Error Recovery Mode feature</a> was originally planned for the 5.1 release but was delayed to patch up some last-minute issues that arose. This feature will help site-owners recover more quickly from fatal errors that break the display or functionality of their site that would ordinarily require code or database edits to fix.</p>



<h3>Privacy and Accessibility Updates</h3>



<p>Along with the headlining features mentioned above, there are some important enhancements to the privacy and accessibility features included in Core. These include <a href=\"https://make.wordpress.org/core/2019/04/24/developer-focused-privacy-updates-in-5-2/\">some important developer-focused changes</a> to how privacy policy pages are displayed and user data is exported, as well as <a href=\"https://make.wordpress.org/core/2019/04/02/admin-tabs-semantic-improvements-in-5-2/\">moving to more semantic markup for admin tabs</a> and <a href=\"https://make.wordpress.org/core/2019/04/24/notable-accessibility-changes-in-5-2/\">other improvements</a> such as switching post format icons to drop-down menus on post list tables, improved admin toolbar markup, and contextual improvements to archive widget drop-down menu.</p>



<h3>New Dashicons</h3>



<p>The <a href=\"https://developer.wordpress.org/resource/dashicons/\">Dashicons</a> library was last updated was over 3 years ago. Now, in the upcoming release, <a href=\"https://make.wordpress.org/core/2019/04/11/dashicons-in-wordpress-5-2/\">a set of 13 new icons will be added to the library</a> along with improvements to the build process and file format of the icons.</p>



<h3>Block Editor Upgrades</h3>



<p>The Block Editor has seen <a href=\"https://make.wordpress.org/core/2019/04/17/whats-new-in-gutenberg-17th-april/\">numerous improvements</a> lately that will all be included in the v5.2 release. Along with the interface upgrades, the underlying Javascript module <a href=\"https://make.wordpress.org/core/2019/04/09/the-block-editor-javascript-module-in-5-2/\">has been reorganized</a>, improvements have been made to <a href=\"https://make.wordpress.org/core/2019/04/17/block-editor-detection-improvements-in-5-2/\">how the block editor is detected</a> on the post edit screen, and <a href=\"https://make.wordpress.org/core/2019/03/25/building-javascript/\">the Javascript build process has been enhanced</a>.</p>



<p><a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-release-candidate/\">WordPress 5.2 is now in the Release Candidate phase</a> and you can test it by installing <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">the Beta Tester plugin</a> on any WordPress site.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>WordPress Translation Day 4 is Almost Here</h2>



<p>On 11 May 2019, <a href=\"https://make.wordpress.org/polyglots/2019/03/01/global-wordpress-translation-day-4-is-coming/\">the fourth WordPress Translation Day</a> will take place. This is a 24-hour global event dedicated to the translation of all things WordPress, from Core to themes, plugins to marketing.</p>



<p>Over the course of 24 hours, WordPress communities will meet to translate WordPress into their local languages and watch talks and sessions broadcast on <a href=\"https://wptranslationday.org/\">wptranslationday.org</a>. During the previous WordPress Translation Day, 71 local events took place in 29 countries, and even more communities are expected to take part this time.</p>



<p>Want to get involved in WordPress Translation Day 4? Find out <a href=\"https://make.wordpress.org/community/2019/03/22/global-wordpress-translation-day-4-info-for-event-organizers/\">how to organize a local event</a>, follow the updates on <a href=\"https://make.wordpress.org/polyglots/tag/gwtd4/\">the Polyglots team blog</a>, and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Block Library Project Gets Started</h2>



<p>Since <a href=\"https://make.wordpress.org/meta/2019/03/08/the-block-directory-and-a-new-type-of-plugin/\">the initial proposal</a> for a Block Library that would be made available from inside the block editor, work has been done to put together <a href=\"https://make.wordpress.org/design/2019/04/02/call-for-design-installing-blocks-from-within-gutenberg/\">some designs</a> for how this would look. Since then the project has received a more direct focus with <a href=\"https://make.wordpress.org/design/2019/04/26/block-library-installing-blocks-from-within-gutenberg/\">a planned out scope and timeline</a>.</p>



<p>The project is being managed <a href=\"https://github.com/WordPress/block-directory/projects/1\">on GitHub</a> and people interested in contributing are encouraged to get involved there. You can also keep up to date by following <a href=\"https://make.wordpress.org/design/\">the Design team blog</a> and joining the #design channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The results from the 5.0 release retrospective survey <a href=\"https://make.wordpress.org/updates/2019/04/26/5-0-release-retrospective-wrap-up/\">have been published</a> &#8211; this is the first time this kind of open retrospective has been done for a WordPress release and the results provide valuable insight into the project and its contributors.</li><li>The team behind the WordPress Coding Standards <a href=\"https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/releases/tag/2.1.0\">has released version 2.1</a>, including some very useful new sniffs.</li><li>The community <a href=\"https://make.wordpress.org/community/2019/04/18/the-get-involved-table-at-wceu-2019/\">is looking for volunteers for the Get Involved table</a> at WordCamp Europe on 20-22 June.</li><li>Gutenberg has been ported <a href=\"https://github.com/VanOns/laraberg/\">for use within the Laravel framework</a> in a project dubbed Laraberg.</li><li>The 2019 WordCamp for Publishers event <a href=\"https://2019-columbus.publishers.wordcamp.org/2019/04/12/call-for-speakers/\">has opened its call for speakers</a>.</li><li>The Gutenberg team <a href=\"https://github.com/WordPress/gutenberg/blob/add/blocks-in-widget-areas-rfc/docs/rfcs/blocks-in-widget-areas.md\">has published an RFC</a> regarding blocks being used in widgets.</li><li>WordCamp Europe, taking place on 20-22 June, has published <a href=\"https://2019.europe.wordcamp.org/schedule/\">the schedule for the event</a>.</li><li>The Community Team <a href=\"https://make.wordpress.org/community/2019/04/18/2018-meetup-survey/\">has published the results</a> of the 2018 meetup group survey.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6918\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 5.2 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/04/wordpress-5-2-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Apr 2019 01:28:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6909\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:364:\"The first release candidate for WordPress 5.2 is now available! This is an important milestone as we progress toward the WordPress 5.2 release date. “Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.2 is scheduled to [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3117:\"
<p>The first release candidate for WordPress 5.2 is now available!</p>



<p>This is an important milestone as we progress toward the WordPress 5.2 release date. “Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.2 is scheduled to be released on <strong>Tuesday, May 7</strong>, but we need <em>your</em> help to get there—if you haven’t tried 5.2 yet, now is the time!</p>



<p>There are two ways to test the WordPress 5.2 release candidate: try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want to select the “bleeding edge nightlies” option), or you can <a href=\"https://wordpress.org/wordpress-5.2-RC1.zip\">download the release candidate here</a> (zip).</p>



<h2>What&#8217;s in WordPress 5.2?</h2>



<p>Continuing with the theme from the last release, WordPress 5.2 gives you even more robust tools for identifying and fixing configuration issues and fatal errors. Whether you are a developer helping clients or you manage your site solo, these tools can help get you the right information when you need it.</p>



<p>The Site Health Check and PHP Error Protection tools have brand new features, giving you peace of mind if you discover any issues with plugins or themes on your site. There are also updates to the icons available in your dashboard, fresh accessibility considerations for anyone using assistive technologies and more.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.2 and update the <em>Tested up to</em> version in the readme to 5.2. If you find compatibility problems, please be sure to post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a> so we can figure those out before the final release.</p>



<p>The <a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">WordPress 5.2 Field Guide</a> has also been published, which goes into the details of the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a> This release also marks the <a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a> point of the 5.2 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Howdy, RC 1!<br>With tools this interesting,<br>I can hardly wait.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6909\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Mon, 15 Jul 2019 11:16:11 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 12 Jul 2019 20:20:46 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911063210\";}","no");
INSERT INTO `wpst_options` VALUES("9795","can_compress_scripts","1","no");


DROP TABLE IF EXISTS `wpst_postmeta`;

CREATE TABLE `wpst_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=370 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_postmeta` VALUES("14","8","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:25:\"Aim-Expo \"[your-subject]\"\";s:6:\"sender\";s:32:\"[your-name] <admin@aim-expo.com>\";s:9:\"recipient\";s:25:\"arunprasath12ap@gmail.com\";s:4:\"body\";s:165:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on My Blog (http://aim-expo.com)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wpst_postmeta` VALUES("13","8","_form","<label> Your Name (required)
    [text* your-name] </label>

<label> Your Email (required)
    [email* your-email] </label>

<label> Subject
    [text your-subject] </label>

<label> Your Message
    [textarea your-message] </label>

[cf7sr-simple-recaptcha]

[submit \"Send\"]");
INSERT INTO `wpst_postmeta` VALUES("15","8","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:24:\"My Blog \"[your-subject]\"\";s:6:\"sender\";s:28:\"My Blog <admin@aim-expo.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:107:\"Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on My Blog (http://aim-expo.com)\";s:18:\"additional_headers\";s:28:\"Reply-To: admin@aim-expo.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wpst_postmeta` VALUES("16","8","_messages","a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO `wpst_postmeta` VALUES("17","8","_additional_settings","");
INSERT INTO `wpst_postmeta` VALUES("18","8","_locale","en_US");
INSERT INTO `wpst_postmeta` VALUES("19","11","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("20","11","_edit_lock","1562567514:1");
INSERT INTO `wpst_postmeta` VALUES("21","9","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("22","9","_edit_lock","1562567520:1");
INSERT INTO `wpst_postmeta` VALUES("23","10","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("24","10","_edit_lock","1562567528:1");
INSERT INTO `wpst_postmeta` VALUES("25","15","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("26","15","_edit_lock","1562567535:1");
INSERT INTO `wpst_postmeta` VALUES("27","17","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("28","17","_edit_lock","1562563138:1");
INSERT INTO `wpst_postmeta` VALUES("33","19","_edit_lock","1562563149:1");
INSERT INTO `wpst_postmeta` VALUES("32","19","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("31","17","_wp_old_date","2018-10-31");
INSERT INTO `wpst_postmeta` VALUES("38","21","_edit_lock","1562563155:1");
INSERT INTO `wpst_postmeta` VALUES("37","21","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("36","19","_wp_old_date","2018-10-31");
INSERT INTO `wpst_postmeta` VALUES("43","23","_edit_lock","1562563161:1");
INSERT INTO `wpst_postmeta` VALUES("42","23","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("41","21","_wp_old_date","2018-10-31");
INSERT INTO `wpst_postmeta` VALUES("46","23","_wp_old_date","2018-10-31");
INSERT INTO `wpst_postmeta` VALUES("362","109","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("291","80","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("290","79","_wp_trash_meta_time","1562560722");
INSERT INTO `wpst_postmeta` VALUES("52","28","_wp_attached_file","2018/08/Automatic-Identification.jpg");
INSERT INTO `wpst_postmeta` VALUES("53","28","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:36:\"2018/08/Automatic-Identification.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-790x440.jpg\";s:5:\"width\";i:790;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:35:\"Automatic-Identification-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-380x250.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:36:\"Automatic-Identification-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("54","17","_thumbnail_id","28");
INSERT INTO `wpst_postmeta` VALUES("57","29","_wp_attached_file","2018/03/Leading-Automatic-Identification.jpg");
INSERT INTO `wpst_postmeta` VALUES("58","29","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:44:\"2018/03/Leading-Automatic-Identification.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-790x440.jpg\";s:5:\"width\";i:790;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:43:\"Leading-Automatic-Identification-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-380x250.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:44:\"Leading-Automatic-Identification-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("59","19","_thumbnail_id","29");
INSERT INTO `wpst_postmeta` VALUES("82","35","_wp_attached_file","2017/11/MaaS.jpg");
INSERT INTO `wpst_postmeta` VALUES("83","35","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:16:\"2017/11/MaaS.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"MaaS-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"MaaS-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"MaaS-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:16:\"MaaS-790x440.jpg\";s:5:\"width\";i:790;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:15:\"MaaS-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:16:\"MaaS-380x250.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:16:\"MaaS-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"1.4\";s:6:\"credit\";s:30:\"Mikko Lemola - stock.adobe.com\";s:6:\"camera\";s:12:\"Canon EOS 5D\";s:7:\"caption\";s:65:\"Maas, Mobility as a Service startup business concept illustration\";s:17:\"created_timestamp\";s:10:\"1374112961\";s:9:\"copyright\";s:32:\"©Mikko Lemola - stock.adobe.com\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:18:\"0.0055555555555556\";s:5:\"title\";s:42:\"Mobility as a Service concept illustration\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:100:{i:0;s:4:\"maas\";i:1;s:7:\"service\";i:2;s:8:\"mobility\";i:3;s:14:\"transportation\";i:4;s:6:\"mobile\";i:5;s:3:\"map\";i:6;s:10:\"navigation\";i:7;s:9:\"navigator\";i:8;s:10:\"technology\";i:9;s:5:\"phone\";i:10;s:3:\"gps\";i:11;s:8:\"location\";i:12;s:7:\"display\";i:13;s:9:\"direction\";i:14;s:6:\"modern\";i:15;s:6:\"search\";i:16;s:6:\"travel\";i:17;s:5:\"smart\";i:18;s:11:\"application\";i:19;s:3:\"app\";i:20;s:6:\"screen\";i:21;s:4:\"road\";i:22;s:6:\"device\";i:23;s:8:\"internet\";i:24;s:10:\"connection\";i:25;s:13:\"communication\";i:26;s:10:\"innovation\";i:27;s:12:\"illustration\";i:28;s:8:\"software\";i:29;s:5:\"route\";i:30;s:8:\"business\";i:31;s:6:\"street\";i:32;s:3:\"way\";i:33;s:11:\"destination\";i:34;s:7:\"virtual\";i:35;s:6:\"future\";i:36;s:3:\"bus\";i:37;s:3:\"car\";i:38;s:5:\"train\";i:39;s:5:\"metro\";i:40;s:6:\"subway\";i:41;s:4:\"taxi\";i:42;s:7:\"network\";i:43;s:6:\"secure\";i:44;s:6:\"online\";i:45;s:7:\"payment\";i:46;s:7:\"startup\";i:47;s:9:\"selecting\";i:48;s:8:\"consumer\";i:49;s:11:\"businessman\";i:50;s:4:\"maas\";i:51;s:7:\"service\";i:52;s:8:\"mobility\";i:53;s:14:\"transportation\";i:54;s:6:\"mobile\";i:55;s:3:\"map\";i:56;s:10:\"navigation\";i:57;s:9:\"navigator\";i:58;s:10:\"technology\";i:59;s:5:\"phone\";i:60;s:3:\"gps\";i:61;s:8:\"location\";i:62;s:7:\"display\";i:63;s:9:\"direction\";i:64;s:6:\"modern\";i:65;s:6:\"search\";i:66;s:6:\"travel\";i:67;s:5:\"smart\";i:68;s:11:\"application\";i:69;s:3:\"app\";i:70;s:6:\"screen\";i:71;s:4:\"road\";i:72;s:6:\"device\";i:73;s:8:\"internet\";i:74;s:10:\"connection\";i:75;s:13:\"communication\";i:76;s:10:\"innovation\";i:77;s:12:\"illustration\";i:78;s:8:\"software\";i:79;s:5:\"route\";i:80;s:8:\"business\";i:81;s:6:\"street\";i:82;s:3:\"way\";i:83;s:11:\"destination\";i:84;s:7:\"virtual\";i:85;s:6:\"future\";i:86;s:3:\"bus\";i:87;s:3:\"car\";i:88;s:5:\"train\";i:89;s:5:\"metro\";i:90;s:6:\"subway\";i:91;s:4:\"taxi\";i:92;s:7:\"network\";i:93;s:6:\"secure\";i:94;s:6:\"online\";i:95;s:7:\"payment\";i:96;s:7:\"startup\";i:97;s:9:\"selecting\";i:98;s:8:\"consumer\";i:99;s:11:\"businessman\";}}}");
INSERT INTO `wpst_postmeta` VALUES("97","39","_wp_attached_file","2017/10/Automatic-identification1.jpg");
INSERT INTO `wpst_postmeta` VALUES("96","37","_wp_old_date","2018-10-31");
INSERT INTO `wpst_postmeta` VALUES("98","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:37:\"2017/10/Automatic-identification1.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-790x440.jpg\";s:5:\"width\";i:790;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:36:\"Automatic-identification1-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-380x250.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:37:\"Automatic-identification1-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("99","37","_thumbnail_id","39");
INSERT INTO `wpst_postmeta` VALUES("102","41","_wp_attached_file","2018/10/vpsforextrader.jpg");
INSERT INTO `wpst_postmeta` VALUES("92","37","_edit_last","1");
INSERT INTO `wpst_postmeta` VALUES("93","37","_edit_lock","1562563189:1");
INSERT INTO `wpst_postmeta` VALUES("84","23","_thumbnail_id","35");
INSERT INTO `wpst_postmeta` VALUES("87","36","_wp_attached_file","2018/01/mobility-solutions.jpg");
INSERT INTO `wpst_postmeta` VALUES("88","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:30:\"2018/01/mobility-solutions.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-790x440.jpg\";s:5:\"width\";i:790;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:29:\"mobility-solutions-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-380x250.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:30:\"mobility-solutions-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("89","21","_thumbnail_id","36");
INSERT INTO `wpst_postmeta` VALUES("103","41","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:600;s:4:\"file\";s:26:\"2018/10/vpsforextrader.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"vpsforextrader-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"vpsforextrader-150x300.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:26:\"vpsforextrader-300x440.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:25:\"vpsforextrader-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:26:\"vpsforextrader-300x250.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:26:\"vpsforextrader-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("104","42","_wp_attached_file","2018/10/zebra.png");
INSERT INTO `wpst_postmeta` VALUES("105","42","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:500;s:4:\"file\";s:17:\"2018/10/zebra.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"zebra-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"zebra-180x300.png\";s:5:\"width\";i:180;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:17:\"zebra-300x440.png\";s:5:\"width\";i:300;s:6:\"height\";i:440;s:9:\"mime-type\";s:9:\"image/png\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:16:\"zebra-115x80.png\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:17:\"zebra-300x250.png\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:17:\"zebra-272x182.png\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("106","43","_wp_attached_file","2018/10/tsys.jpg");
INSERT INTO `wpst_postmeta` VALUES("107","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:500;s:4:\"file\";s:16:\"2018/10/tsys.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"tsys-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"tsys-180x300.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"mega-magazine-slider\";a:4:{s:4:\"file\";s:16:\"tsys-300x440.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:440;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:15:\"tsys-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"mega-magazine-mid\";a:4:{s:4:\"file\";s:16:\"tsys-300x250.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:16:\"tsys-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("257","67","_wp_attachment_metadata","a:5:{s:5:\"width\";i:377;s:6:\"height\";i:76;s:4:\"file\";s:19:\"2018/11/AIMExpo.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AIMExpo-150x76.png\";s:5:\"width\";i:150;s:6:\"height\";i:76;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AIMExpo-300x60.png\";s:5:\"width\";i:300;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:18:\"AIMExpo-115x76.png\";s:5:\"width\";i:115;s:6:\"height\";i:76;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:18:\"AIMExpo-272x76.png\";s:5:\"width\";i:272;s:6:\"height\";i:76;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("361","109","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("360","109","_menu_item_object","custom");
INSERT INTO `wpst_postmeta` VALUES("359","109","_menu_item_object_id","109");
INSERT INTO `wpst_postmeta` VALUES("358","109","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("357","109","_menu_item_type","custom");
INSERT INTO `wpst_postmeta` VALUES("119","45","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("120","45","_menu_item_menu_item_parent","48");
INSERT INTO `wpst_postmeta` VALUES("121","45","_menu_item_object_id","15");
INSERT INTO `wpst_postmeta` VALUES("122","45","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("123","45","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("124","45","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("125","45","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("126","45","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("128","46","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("129","46","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("130","46","_menu_item_object_id","9");
INSERT INTO `wpst_postmeta` VALUES("131","46","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("132","46","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("133","46","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("134","46","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("135","46","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("137","47","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("138","47","_menu_item_menu_item_parent","46");
INSERT INTO `wpst_postmeta` VALUES("139","47","_menu_item_object_id","10");
INSERT INTO `wpst_postmeta` VALUES("140","47","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("141","47","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("142","47","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("143","47","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("144","47","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("146","48","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("147","48","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("148","48","_menu_item_object_id","11");
INSERT INTO `wpst_postmeta` VALUES("149","48","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("150","48","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("151","48","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("152","48","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("153","48","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("368","111","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("155","49","_menu_item_type","taxonomy");
INSERT INTO `wpst_postmeta` VALUES("156","49","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("157","49","_menu_item_object_id","1");
INSERT INTO `wpst_postmeta` VALUES("158","49","_menu_item_object","category");
INSERT INTO `wpst_postmeta` VALUES("159","49","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("160","49","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("161","49","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("162","49","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("369","111","_wp_trash_meta_time","1562756154");
INSERT INTO `wpst_postmeta` VALUES("164","50","_menu_item_type","taxonomy");
INSERT INTO `wpst_postmeta` VALUES("165","50","_menu_item_menu_item_parent","74");
INSERT INTO `wpst_postmeta` VALUES("166","50","_menu_item_object_id","2");
INSERT INTO `wpst_postmeta` VALUES("167","50","_menu_item_object","category");
INSERT INTO `wpst_postmeta` VALUES("168","50","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("169","50","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("170","50","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("171","50","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("367","110","_wp_trash_meta_time","1562755156");
INSERT INTO `wpst_postmeta` VALUES("173","51","_menu_item_type","taxonomy");
INSERT INTO `wpst_postmeta` VALUES("174","51","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("175","51","_menu_item_object_id","3");
INSERT INTO `wpst_postmeta` VALUES("176","51","_menu_item_object","category");
INSERT INTO `wpst_postmeta` VALUES("177","51","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("178","51","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("179","51","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("180","51","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("366","110","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("286","77","_wp_trash_meta_time","1562560695");
INSERT INTO `wpst_postmeta` VALUES("191","53","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("192","53","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("193","53","_menu_item_object_id","15");
INSERT INTO `wpst_postmeta` VALUES("194","53","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("195","53","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("196","53","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("197","53","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("198","53","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("289","79","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("200","54","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("201","54","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("202","54","_menu_item_object_id","9");
INSERT INTO `wpst_postmeta` VALUES("203","54","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("204","54","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("205","54","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("206","54","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("207","54","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("287","78","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("209","55","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("210","55","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("211","55","_menu_item_object_id","10");
INSERT INTO `wpst_postmeta` VALUES("212","55","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("213","55","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("214","55","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("215","55","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("216","55","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("288","78","_wp_trash_meta_time","1562560701");
INSERT INTO `wpst_postmeta` VALUES("218","56","_menu_item_type","post_type");
INSERT INTO `wpst_postmeta` VALUES("219","56","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("220","56","_menu_item_object_id","11");
INSERT INTO `wpst_postmeta` VALUES("221","56","_menu_item_object","page");
INSERT INTO `wpst_postmeta` VALUES("222","56","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("223","56","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("224","56","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("225","56","_menu_item_url","");
INSERT INTO `wpst_postmeta` VALUES("283","76","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("284","76","_wp_trash_meta_time","1562560688");
INSERT INTO `wpst_postmeta` VALUES("281","75","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("235","62","_wp_attached_file","2018/10/Barcode-Scanner.jpg");
INSERT INTO `wpst_postmeta` VALUES("236","62","_wp_attachment_metadata","a:5:{s:5:\"width\";i:128;s:6:\"height\";i:128;s:4:\"file\";s:27:\"2018/10/Barcode-Scanner.jpg\";s:5:\"sizes\";a:1:{s:19:\"mega-magazine-thumb\";a:4:{s:4:\"file\";s:26:\"Barcode-Scanner-115x80.jpg\";s:5:\"width\";i:115;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("285","77","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("282","75","_wp_trash_meta_time","1562560669");
INSERT INTO `wpst_postmeta` VALUES("269","74","_menu_item_url","#");
INSERT INTO `wpst_postmeta` VALUES("256","67","_wp_attached_file","2018/11/AIMExpo.png");
INSERT INTO `wpst_postmeta` VALUES("266","74","_menu_item_target","");
INSERT INTO `wpst_postmeta` VALUES("267","74","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wpst_postmeta` VALUES("268","74","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("265","74","_menu_item_object","custom");
INSERT INTO `wpst_postmeta` VALUES("264","74","_menu_item_object_id","74");
INSERT INTO `wpst_postmeta` VALUES("263","74","_menu_item_menu_item_parent","0");
INSERT INTO `wpst_postmeta` VALUES("262","74","_menu_item_type","custom");
INSERT INTO `wpst_postmeta` VALUES("292","80","_wp_trash_meta_time","1562560729");
INSERT INTO `wpst_postmeta` VALUES("293","81","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("294","81","_wp_trash_meta_time","1562560736");
INSERT INTO `wpst_postmeta` VALUES("295","82","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("296","82","_wp_trash_meta_time","1562560797");
INSERT INTO `wpst_postmeta` VALUES("297","83","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("298","83","_wp_trash_meta_time","1562560809");
INSERT INTO `wpst_postmeta` VALUES("299","84","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("300","84","_wp_trash_meta_time","1562560826");
INSERT INTO `wpst_postmeta` VALUES("301","85","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("302","85","_wp_trash_meta_time","1562561483");
INSERT INTO `wpst_postmeta` VALUES("303","86","_wp_attached_file","2018/01/cropped-mobility-solutions.jpg");
INSERT INTO `wpst_postmeta` VALUES("304","86","_wp_attachment_context","custom-header");
INSERT INTO `wpst_postmeta` VALUES("305","86","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:379;s:4:\"file\";s:38:\"2018/01/cropped-mobility-solutions.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"cropped-mobility-solutions-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"cropped-mobility-solutions-300x59.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:59;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"cropped-mobility-solutions-768x152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:39:\"cropped-mobility-solutions-1024x202.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:202;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"blogberg-1200-710\";a:4:{s:4:\"file\";s:39:\"cropped-mobility-solutions-1200x379.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:379;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:38:\"cropped-mobility-solutions-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:17:\"attachment_parent\";i:36;}");
INSERT INTO `wpst_postmeta` VALUES("306","86","_wp_attachment_custom_header_last_used_blogberg","1562561613");
INSERT INTO `wpst_postmeta` VALUES("307","86","_wp_attachment_is_custom_header","blogberg");
INSERT INTO `wpst_postmeta` VALUES("308","87","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("309","87","_wp_trash_meta_time","1562561613");
INSERT INTO `wpst_postmeta` VALUES("310","88","_wp_attached_file","2019/07/BG-1000x675.jpg");
INSERT INTO `wpst_postmeta` VALUES("311","88","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:675;s:4:\"file\";s:23:\"2019/07/BG-1000x675.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"BG-1000x675-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"BG-1000x675-300x203.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:203;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"BG-1000x675-768x518.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:518;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:23:\"BG-1000x675-272x182.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("312","88","_wp_attachment_is_custom_background","blogberg");
INSERT INTO `wpst_postmeta` VALUES("313","89","_edit_lock","1562561857:1");
INSERT INTO `wpst_postmeta` VALUES("314","89","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("315","89","_wp_trash_meta_time","1562561857");
INSERT INTO `wpst_postmeta` VALUES("316","90","_wp_attached_file","2019/07/767.png");
INSERT INTO `wpst_postmeta` VALUES("317","90","_wp_attachment_metadata","a:5:{s:5:\"width\";i:640;s:6:\"height\";i:767;s:4:\"file\";s:15:\"2019/07/767.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"767-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"767-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"blogberg-1200-710\";a:4:{s:4:\"file\";s:15:\"767-640x710.png\";s:5:\"width\";i:640;s:6:\"height\";i:710;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sow-carousel-default\";a:4:{s:4:\"file\";s:15:\"767-272x182.png\";s:5:\"width\";i:272;s:6:\"height\";i:182;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("318","90","_wp_attachment_is_custom_background","blogberg");
INSERT INTO `wpst_postmeta` VALUES("319","91","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("320","91","_wp_trash_meta_time","1562561951");
INSERT INTO `wpst_postmeta` VALUES("321","92","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("322","92","_wp_trash_meta_time","1562562006");
INSERT INTO `wpst_postmeta` VALUES("323","93","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("324","93","_wp_trash_meta_time","1562562224");
INSERT INTO `wpst_postmeta` VALUES("325","96","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("326","96","_wp_trash_meta_time","1562562604");
INSERT INTO `wpst_postmeta` VALUES("327","97","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("328","97","_wp_trash_meta_time","1562562942");
INSERT INTO `wpst_postmeta` VALUES("342","99","_wp_trash_meta_time","1562563612");
INSERT INTO `wpst_postmeta` VALUES("341","99","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("343","101","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("344","101","_wp_trash_meta_time","1562563631");
INSERT INTO `wpst_postmeta` VALUES("345","103","_edit_lock","1562563721:1");
INSERT INTO `wpst_postmeta` VALUES("346","103","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("347","103","_wp_trash_meta_time","1562563729");
INSERT INTO `wpst_postmeta` VALUES("348","104","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("349","104","_wp_trash_meta_time","1562563825");
INSERT INTO `wpst_postmeta` VALUES("350","106","_wp_attached_file","2019/07/computer_blue.png");
INSERT INTO `wpst_postmeta` VALUES("351","106","_wp_attachment_metadata","a:5:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:25:\"2019/07/computer_blue.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wpst_postmeta` VALUES("352","107","_wp_trash_meta_status","publish");
INSERT INTO `wpst_postmeta` VALUES("353","107","_wp_trash_meta_time","1562563954");
INSERT INTO `wpst_postmeta` VALUES("363","109","_menu_item_xfn","");
INSERT INTO `wpst_postmeta` VALUES("364","109","_menu_item_url","https://www.aim-expo.com/");


DROP TABLE IF EXISTS `wpst_posts`;

CREATE TABLE `wpst_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_posts` VALUES("9","1","2018-08-17 10:36:15","2018-08-17 10:36:15","[contact-form-7 id=\"8\" title=\"Contact form 1\"]","Contact Us","","publish","closed","closed","","contact-us","","","2019-07-08 06:32:00","2019-07-08 06:32:00","","0","http://aim-expo.com/?page_id=9","0","page","","0");
INSERT INTO `wpst_posts` VALUES("10","1","2018-08-10 10:36:16","2018-08-10 10:36:16","<p style=\"text-align: justify;\">We know the value of your privacy and personal information. We are committedto respecting your privacy in all ways. While you use our website, we may collect certain basic details like browser details, geographical location, IP address and viewed website pages. We are collecting these details for the maintenance of our website. We do not share or sell your personal details to third parties. While you are submitting comments or filling the contact form, you may be asked to submit your name and email address. We do not share your email address with third parties. We do not use your email address for unnecessary marketing emails. We will be updating our Privacy Policy from time to time and we will be notifying the changes by email. If you have any doubts or suggestions, please get in touch with us.</p>","Privacy Policy","","publish","closed","closed","","privacy-policy","","","2019-07-08 06:32:08","2019-07-08 06:32:08","","0","http://aim-expo.com/?page_id=10","0","page","","0");
INSERT INTO `wpst_posts` VALUES("11","1","2018-04-28 10:36:18","2018-04-28 10:36:18","<p style=\"text-align: justify;\">Hi friends! Welcome to our website. It is a great pleasure to meet you through this website. Our website is all about automatic identification system and mobility technology solution. There are numerous devices that come under automatic identification systems. It is mostly used in commercial settings for logistics and inventory control and security authorization. Though there are several devices, all the devices work for a common purpose that is to collect and gather information about the user. Some of the popular systems include barcodes, magnetic stripes, smart cards, radio frequency identification, voice recognition,and biometrics.
Nowadays, authorization using the devices has become simple and time-consuming. It is hard to register a group of visitors by just with a pen and paper. You need to have some important devices to authorize the person in all ways. So, in our website, you will be learning about various authorization identification systems and its functions. If you have any suggestions or queries, you can connect with us directly. We will be happy to guide you as per your requirements.
Mobility technology solutions are much needed for the present business scenario. It is essential to update your business according to the latest trends. It helps in managing data privacy and boosts employee productivity. It also reduces long-term expenses and helps in a positive return on investment in business. If you have not switched to any of these latest trends, then it is time to update your business. Thank you for visiting our website. We will be updating our website with more detailed and precise information.</p>","About Us","","publish","closed","closed","","about-us","","","2019-07-08 06:31:54","2019-07-08 06:31:54","","0","http://aim-expo.com/?page_id=11","0","page","","0");
INSERT INTO `wpst_posts` VALUES("12","1","2018-10-31 10:44:44","2018-10-31 10:44:44","<p style=\"text-align: justify;\">Hi friends! Welcome to our website. It is a great pleasure to meet you through this website. Our website is all about automatic identification system and mobility technology solution. There are numerous devices that come under automatic identification systems. It is mostly used in commercial settings for logistics and inventory control and security authorization. Though there are several devices, all the devices work for a common purpose that is to collect and gather information about the user. Some of the popular systems include barcodes, magnetic stripes, smart cards, radio frequency identification, voice recognition,and biometrics.
Nowadays, authorization using the devices has become simple and time-consuming. It is hard to register a group of visitors by just with a pen and paper. You need to have some important devices to authorize the person in all ways. So, in our website, you will be learning about various authorization identification systems and its functions. If you have any suggestions or queries, you can connect with us directly. We will be happy to guide you as per your requirements.
Mobility technology solutions are much needed for the present business scenario. It is essential to update your business according to the latest trends. It helps in managing data privacy and boosts employee productivity. It also reduces long-term expenses and helps in a positive return on investment in business. If you have not switched to any of these latest trends, then it is time to update your business. Thank you for visiting our website. We will be updating our website with more detailed and precise information.</p>","About Us","","inherit","closed","closed","","11-revision-v1","","","2018-10-31 10:44:44","2018-10-31 10:44:44","","11","http://aim-expo.com/11-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("13","1","2018-10-31 10:45:19","2018-10-31 10:45:19","[contact-form-7 id=\"8\" title=\"Contact form 1\"]","Contact Us","","inherit","closed","closed","","9-revision-v1","","","2018-10-31 10:45:19","2018-10-31 10:45:19","","9","http://aim-expo.com/9-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("14","1","2018-10-31 10:46:11","2018-10-31 10:46:11","<p style=\"text-align: justify;\">We know the value of your privacy and personal information. We are committedto respecting your privacy in all ways. While you use our website, we may collect certain basic details like browser details, geographical location, IP address and viewed website pages. We are collecting these details for the maintenance of our website. We do not share or sell your personal details to third parties. While you are submitting comments or filling the contact form, you may be asked to submit your name and email address. We do not share your email address with third parties. We do not use your email address for unnecessary marketing emails. We will be updating our Privacy Policy from time to time and we will be notifying the changes by email. If you have any doubts or suggestions, please get in touch with us.</p>","Privacy Policy","","inherit","closed","closed","","10-revision-v1","","","2018-10-31 10:46:11","2018-10-31 10:46:11","","10","http://aim-expo.com/10-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("16","1","2018-10-31 10:47:08","2018-10-31 10:47:08","<p style=\"text-align: justify;\">The Terms of Use mentioned on the website are provided for your convenience. If you are not convinced, you can exit our website anytime. Our website may have external links that may connect to the third-party website. We are not responsible for the third party website’s practices, contents, privacy policy or price changes. We make use of third-partyadvertising companies to display their advertisements on our website. We do not have access to collect personal details.
Personal details will be gathered on our website only when you share comments or submit a contact form. We encourage you to use the website in a careful manner. We do not want you to share unnecessary or illegal comments on our website. We do not encourage you to share personal information online.</p>","Terms of Use","","inherit","closed","closed","","15-revision-v1","","","2018-10-31 10:47:08","2018-10-31 10:47:08","","15","http://aim-expo.com/15-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("17","1","2018-08-25 10:47:50","2018-08-25 10:47:50","<p style=\"text-align: justify;\">AIDC is the short term of <strong>Automatic Identification</strong> and <strong>Data Collection</strong>. It is an advanced technology which aids to find the objects, gather related information, saves and prints the information in computer systems. The other name of AIDC is Automatic Identification and Data Capturing technology. In this technology, it reduces human work and functions on own. Human involvement is required only while scanning. The system will automatically print information into computer systems.
Identification data is the information connected with the object. The data differ in forms like fingerprints, voice or images. The data you enter will be changed into a digital file and then it will be entered in the computer. To convert the original into a digital file, a transducer is employed to accomplish this task. The computer can analyze the stored information file. It can also be matched with other files after entering the information into the computer. Thus, it offers access to passing into a protected system.
There are three principal components of <strong>Automatic Identification</strong> and <strong>Data Collection</strong> technology.
Data encoding: In the data encoding process, the alphanumeric characters get translated into machine-readable form.
Machine scanning: It is the second level where the encoded data is read by the machine scanner, thereby converting the data to electric signals.
Data decoding: As the name implies, in this level, the electric signals will be converted into digital data and later it gets changed into alphanumeric characters.
Different Kinds of AIDS Technologies Used for Data Capturing:
· RTLS (Real Time Locating Systems)
· EAS (Electronic Article Surveillance)
· Voice Recognition
· Smart Cards
· OCR (Optical Character Recognition)
· Magnetic Stripes
· Biometrics
· RFIS (Radio Frequency Identification)
· Barcodes</p>
<p style=\"text-align: justify;\">Let us look about these technologies and their functions in detail.
Barcodes: Barcodes are scanned using special optical scanners referred to as barcode readers. It is a readable information and information is about the article fixed to the barcode. If you have visited supermarkets, you can find a lot of items with barcodes. The barcode reader has a laser beam and it translates the images into digital information and transfers to the computer.
<strong>Barcode technology standards describe:</strong>
· Rules and methods for marking or printing
· Rules for calculating the quality of marked and printed symbols
· Decoding and reading techniques
· Rules for representing information in an optically legible format
Biometrics: Biometrics involves recognition of a person. It compares stored data with the captured biological information of the individual. The biometric system contains a reader or scanning device with software. It helps in converting the scanned biological information like fingerprints to the digital layout. It is mandatory to add the biometric information to get the biometric data of an individual at the later date. The information will be noticed and compared with the stored information. It is important to enroll data for late detection and comparison. Iris recognition, palm print recognition, face recognition and fingerprint recognition are some of the popular kinds of biometric systems that comes within the AIDC world.</p>
<p style=\"text-align: justify;\">Smart Cards: When you notice your smart card, you can see a small chip with an integrated circuit. Smart cards stores information and when there is a need, the data can be transferred to a computer system. It is capable of storing data for application processing and identification.</p>","Know about Automatic Identification and Data Collection Technology","","publish","open","closed","","know-about-automatic-identification-and-data-collection-technology","","","2019-07-08 05:18:58","2019-07-08 05:18:58","","0","http://aim-expo.com/?p=17","0","post","","0");
INSERT INTO `wpst_posts` VALUES("15","1","2018-11-12 10:46:14","2018-11-12 10:46:14","<p style=\"text-align: justify;\">The Terms of Use mentioned on the website are provided for your convenience. If you are not convinced, you can exit our website anytime. Our website may have external links that may connect to the third-party website. We are not responsible for the third party website’s practices, contents, privacy policy or price changes. We make use of third-partyadvertising companies to display their advertisements on our website. We do not have access to collect personal details.
Personal details will be gathered on our website only when you share comments or submit a contact form. We encourage you to use the website in a careful manner. We do not want you to share unnecessary or illegal comments on our website. We do not encourage you to share personal information online.</p>","Terms of Use","","publish","closed","closed","","terms-of-use","","","2019-07-08 06:32:15","2019-07-08 06:32:15","","0","http://aim-expo.com/?page_id=15","0","page","","0");
INSERT INTO `wpst_posts` VALUES("8","1","2018-10-31 10:21:09","2018-10-31 10:21:09","<label> Your Name (required)
    [text* your-name] </label>

<label> Your Email (required)
    [email* your-email] </label>

<label> Subject
    [text your-subject] </label>

<label> Your Message
    [textarea your-message] </label>

[cf7sr-simple-recaptcha]

[submit \"Send\"]
1
Aim-Expo \"[your-subject]\"
[your-name] <admin@aim-expo.com>
arunprasath12ap@gmail.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on My Blog (http://aim-expo.com)
Reply-To: [your-email]




My Blog \"[your-subject]\"
My Blog <admin@aim-expo.com>
[your-email]
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on My Blog (http://aim-expo.com)
Reply-To: admin@aim-expo.com



Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.
The date format is incorrect.
The date is before the earliest one allowed.
The date is after the latest one allowed.
There was an unknown error uploading the file.
You are not allowed to upload files of this type.
The file is too big.
There was an error uploading the file.
The number format is invalid.
The number is smaller than the minimum allowed.
The number is larger than the maximum allowed.
The answer to the quiz is incorrect.
Your entered code is incorrect.
The e-mail address entered is invalid.
The URL is invalid.
The telephone number is invalid.","Contact form 1","","publish","closed","closed","","contact-form-1","","","2019-07-08 06:28:59","2019-07-08 06:28:59","","0","http://aim-expo.com/?post_type=wpcf7_contact_form&#038;p=8","0","wpcf7_contact_form","","0");
INSERT INTO `wpst_posts` VALUES("18","1","2018-10-31 10:51:04","2018-10-31 10:51:04","<p style=\"text-align: justify;\">AIDC is the short term of <strong>Automatic Identification</strong> and <strong>Data Collection</strong>. It is an advanced technology which aids to find the objects, gather related information, saves and prints the information in computer systems. The other name of AIDC is Automatic Identification and Data Capturing technology. In this technology, it reduces human work and functions on own. Human involvement is required only while scanning. The system will automatically print information into computer systems.
Identification data is the information connected with the object. The data differ in forms like fingerprints, voice or images. The data you enter will be changed into a digital file and then it will be entered in the computer. To convert the original into a digital file, a transducer is employed to accomplish this task. The computer can analyze the stored information file. It can also be matched with other files after entering the information into the computer. Thus, it offers access to passing into a protected system.
There are three principal components of <strong>Automatic Identification</strong> and <strong>Data Collection</strong> technology.
Data encoding: In the data encoding process, the alphanumeric characters get translated into machine-readable form.
Machine scanning: It is the second level where the encoded data is read by the machine scanner, thereby converting the data to electric signals.
Data decoding: As the name implies, in this level, the electric signals will be converted into digital data and later it gets changed into alphanumeric characters.
Different Kinds of AIDS Technologies Used for Data Capturing:
· RTLS (Real Time Locating Systems)
· EAS (Electronic Article Surveillance)
· Voice Recognition
· Smart Cards
· OCR (Optical Character Recognition)
· Magnetic Stripes
· Biometrics
· RFIS (Radio Frequency Identification)
· Barcodes</p>
<p style=\"text-align: justify;\">Let us look about these technologies and their functions in detail.
Barcodes: Barcodes are scanned using special optical scanners referred to as barcode readers. It is a readable information and information is about the article fixed to the barcode. If you have visited supermarkets, you can find a lot of items with barcodes. The barcode reader has a laser beam and it translates the images into digital information and transfers to the computer.
<strong>Barcode technology standards describe:</strong>
· Rules and methods for marking or printing
· Rules for calculating the quality of marked and printed symbols
· Decoding and reading techniques
· Rules for representing information in an optically legible format
Biometrics: Biometrics involves recognition of a person. It compares stored data with the captured biological information of the individual. The biometric system contains a reader or scanning device with software. It helps in converting the scanned biological information like fingerprints to the digital layout. It is mandatory to add the biometric information to get the biometric data of an individual at the later date. The information will be noticed and compared with the stored information. It is important to enroll data for late detection and comparison. Iris recognition, palm print recognition, face recognition and fingerprint recognition are some of the popular kinds of biometric systems that comes within the AIDC world.</p>
<p style=\"text-align: justify;\">Smart Cards: When you notice your smart card, you can see a small chip with an integrated circuit. Smart cards stores information and when there is a need, the data can be transferred to a computer system. It is capable of storing data for application processing and identification.</p>","Know about Automatic Identification and Data Collection Technology","","inherit","closed","closed","","17-revision-v1","","","2018-10-31 10:51:04","2018-10-31 10:51:04","","17","http://aim-expo.com/17-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("19","1","2018-03-31 10:51:19","2018-03-31 10:51:19","<p style=\"text-align: justify;\">In recent years, the workplace is transformed into completely wireless workstations and the DC and warehouse managers are doing a lot of tasks without much effort. The best part is they are able to satisfy the customer’s requirements. Automatic Identification and Data Capture solutions are grown extensively. The sales for such technology products are increased globally. It is used in logistics, warehouses and factories applications. In 2016, the sales have reached $6.13 billion and in 2017, the sales were significantly increased to $6.35 billion as per the VDC Research Group.
<strong>Leading suppliers</strong>
Zebra Technologies occupies the #1 rank since 2015. The total sale revenue was $2.130 million in 2016. It is followed by Datalogic with the sales revenue of $556 million and Honeywell with the sales revenue of $1.022. The top 10 suppliers of 2016 were Fujian Newland, Casio Computer Co., SICK AG, Cognex, Denso Wave, Toshiba TEC,and SATO.
The sales of the handheld scanner have been greatly improved and the overall profits are 9.66% more than the last year period. The market leaders Zebra Technologies and Honeywell has seen significantly improved revenue performance in 2016. The sales of camera-based imager have helped in overall market growth in the first three months of the year. The sales have been increased by 16% more than last year. The sales of laser scanner have been down by almost 9%.
This year, Zebra technologies, Honeywell and Datalogic are making exceptional investments in order to refresh and expand their products.,They are facing a stiffcompetition and looking to upgrade ahead of their competitors.
<strong>Barcoding and thermal printing</strong>
Desktop printers are expensive industrial printers and generate a greater percentage of complete revenues. Zebra Technologies, Toshiba TEC, SATO and Honeywell cannot depend on product quality and brand recognition alone to accomplish their profitability and sales targets. There is heavy competition especially in high growth countries like South Korea, Germany,and China. As there is a strong combination of emerging contenders and market leaders, there is healthy competition.
It is difficult for the hardware suppliers to meet pricing, compliance legislation and application particular labeling needs of top end-user verticals in all the region they compete. As per research, it is confirmed that revenues have increased in 2017 when compared to last year. It can be due to factors like new product launches by suppliers like Zebra technologies, TSC Printers and Honeywell and efforts to discourse traceability associated requirements in warehousing and manufacturing.
In the printer area, the research confirms that there has been a healthy sale increase of color label printers. If the traditional thermal barcode label printer manufacturers concentrate on monochrome products, establishments like Epson are thinking about adding colors in labels. It is not possible for traditional or typical barcode label print could accomplish.
<strong>Low labor expenses and fast shipment</strong>
The presence of e-commerce functions and vendor’s omnichannel ingenuity in DC/warehouse development and growth has helped in a great way for the success of the connected and enterprise mobility devices. Several initiatives have been taken for on-time delivery, shipping products quicker and reducing labor expenses.</p>","Leading Automatic Identification and Data Capture Suppliers","","publish","open","closed","","leading-automatic-identification-and-data-capture-suppliers","","","2019-07-08 05:19:09","2019-07-08 05:19:09","","0","http://aim-expo.com/?p=19","0","post","","0");
INSERT INTO `wpst_posts` VALUES("20","1","2018-10-31 10:53:13","2018-10-31 10:53:13","<p style=\"text-align: justify;\">In recent years, the workplace is transformed into completely wireless workstations and the DC and warehouse managers are doing a lot of tasks without much effort. The best part is they are able to satisfy the customer’s requirements. Automatic Identification and Data Capture solutions are grown extensively. The sales for such technology products are increased globally. It is used in logistics, warehouses and factories applications. In 2016, the sales have reached $6.13 billion and in 2017, the sales were significantly increased to $6.35 billion as per the VDC Research Group.
<strong>Leading suppliers</strong>
Zebra Technologies occupies the #1 rank since 2015. The total sale revenue was $2.130 million in 2016. It is followed by Datalogic with the sales revenue of $556 million and Honeywell with the sales revenue of $1.022. The top 10 suppliers of 2016 were Fujian Newland, Casio Computer Co., SICK AG, Cognex, Denso Wave, Toshiba TEC,and SATO.
The sales of the handheld scanner have been greatly improved and the overall profits are 9.66% more than the last year period. The market leaders Zebra Technologies and Honeywell has seen significantly improved revenue performance in 2016. The sales of camera-based imager have helped in overall market growth in the first three months of the year. The sales have been increased by 16% more than last year. The sales of laser scanner have been down by almost 9%.
This year, Zebra technologies, Honeywell and Datalogic are making exceptional investments in order to refresh and expand their products.,They are facing a stiffcompetition and looking to upgrade ahead of their competitors.
<strong>Barcoding and thermal printing</strong>
Desktop printers are expensive industrial printers and generate a greater percentage of complete revenues. Zebra Technologies, Toshiba TEC, SATO and Honeywell cannot depend on product quality and brand recognition alone to accomplish their profitability and sales targets. There is heavy competition especially in high growth countries like South Korea, Germany,and China. As there is a strong combination of emerging contenders and market leaders, there is healthy competition.
It is difficult for the hardware suppliers to meet pricing, compliance legislation and application particular labeling needs of top end-user verticals in all the region they compete. As per research, it is confirmed that revenues have increased in 2017 when compared to last year. It can be due to factors like new product launches by suppliers like Zebra technologies, TSC Printers and Honeywell and efforts to discourse traceability associated requirements in warehousing and manufacturing.
In the printer area, the research confirms that there has been a healthy sale increase of color label printers. If the traditional thermal barcode label printer manufacturers concentrate on monochrome products, establishments like Epson are thinking about adding colors in labels. It is not possible for traditional or typical barcode label print could accomplish.
<strong>Low labor expenses and fast shipment</strong>
The presence of e-commerce functions and vendor’s omnichannel ingenuity in DC/warehouse development and growth has helped in a great way for the success of the connected and enterprise mobility devices. Several initiatives have been taken for on-time delivery, shipping products quicker and reducing labor expenses.</p>","Leading Automatic Identification and Data Capture Suppliers","","inherit","closed","closed","","19-revision-v1","","","2018-10-31 10:53:13","2018-10-31 10:53:13","","19","http://aim-expo.com/19-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("21","1","2018-01-16 10:53:23","2018-01-16 10:53:23","<p style=\"text-align: justify;\">The much awaited Mobile World Congress 2018 has ended in a good note. Being the biggest trade show in the mobile industry, Mobile World Congress offered an excellent platform for discussing various hot and trending topics ranging from 5G to artificial intelligence. In this piece of article, we are going to discuss <strong>Mobility technology</strong> and the highlights of the Mobile World Congress.</p>
<p style=\"text-align: justify;\">The trade show in Barcelona saw various mobile manufacturers from across the world, displaying their top-notch future devices. Many expected that 5G would be the show stealer. Now let us see the new trends, which were trending the news this year.</p>
<p style=\"text-align: justify;\"><strong>5G Connectivity</strong></p>
<p style=\"text-align: justify;\">The talks about 5G mobile connectivity have been doing rounds in the technology world for a while. In this trade show, the experts stressed that they are taking a step forward to materialize the concept of 5G connectivity. Kester Mann of CCS Insight says that the initial standard for 5G has been established and soon the people will be announcing this more officially.</p>
<p style=\"text-align: justify;\">The Internet connectivity has been playing a huge role in improving the lives of the mobile users. With the materialization and implementation of 5G connectivity, the mobile users will see a significant improvement in their mobile experience. There were plenty of topics about 5G was discussed in the MWC 2018.</p>
<p style=\"text-align: justify;\">5G is no more a topic that is only in the level of discussion. It is on the verge of materialization and it is expected to come soon to the market and will make a great impact on enterprises and consumers. 5G will be more than 100 times speeder than currently existing 4G and more than 10 times speedier than the conventional broadband internet connection. With this fantastic level of speed, it has opened the door for technologies like AR, VR, IoT and Edge computing to become a high possibility.</p>
<p style=\"text-align: justify;\"><strong>AI</strong></p>
<p style=\"text-align: justify;\">There are plenty of benefits of AI. Apart from the rapid Internet speed, the other important benefits of 5G are the capability to deal with technologies to the likes of AI. There are two reasons why AI needs to be used in telecommunications. First, AI can be utilized to enhance the methodologies for planning and managing the networks. The network operators will be able to easily foresee their customer needs, while controlling the tariffs. The telecommunication industry can take lots of advantage with the AI and 5G.</p>
<p style=\"text-align: justify;\">Mobility has been influencing various industries across the world and the manufacturing industry is no exception. Many industries have adopted the mobility strategies to empower the business. The growth extraordinary growth of IoT has made lots of impact in the manufacturing sector. The total number of devices connected, spanning the industries across the globe, is expected to increase up to 8.4 billion, which is 31% higher than 2016.</p>
<p style=\"text-align: justify;\">The technology has eased the manufacturing floors in a significant way. Today, workers at manufacturing sites are able to work with less fatigue, due to the advancement and implementation of mobility technology. One of the finest examples is the robotic technology in the manufacturing sector.</p>
<p style=\"text-align: justify;\">With the rapid advancement of mobility technology, it is sure that all the industries are going to see a rapid development.</p>","Popular Trends of Mobility Technology","","publish","open","closed","","popular-trends-of-mobility-technology","","","2019-07-08 05:19:15","2019-07-08 05:19:15","","0","http://aim-expo.com/?p=21","0","post","","0");
INSERT INTO `wpst_posts` VALUES("22","1","2018-10-31 10:55:06","2018-10-31 10:55:06","<p style=\"text-align: justify;\">The much awaited Mobile World Congress 2018 has ended in a good note. Being the biggest trade show in the mobile industry, Mobile World Congress offered an excellent platform for discussing various hot and trending topics ranging from 5G to artificial intelligence. In this piece of article, we are going to discuss <strong>Mobility technology</strong> and the highlights of the Mobile World Congress.</p>
<p style=\"text-align: justify;\">The trade show in Barcelona saw various mobile manufacturers from across the world, displaying their top-notch future devices. Many expected that 5G would be the show stealer. Now let us see the new trends, which were trending the news this year.</p>
<p style=\"text-align: justify;\"><strong>5G Connectivity</strong></p>
<p style=\"text-align: justify;\">The talks about 5G mobile connectivity have been doing rounds in the technology world for a while. In this trade show, the experts stressed that they are taking a step forward to materialize the concept of 5G connectivity. Kester Mann of CCS Insight says that the initial standard for 5G has been established and soon the people will be announcing this more officially.</p>
<p style=\"text-align: justify;\">The Internet connectivity has been playing a huge role in improving the lives of the mobile users. With the materialization and implementation of 5G connectivity, the mobile users will see a significant improvement in their mobile experience. There were plenty of topics about 5G was discussed in the MWC 2018.</p>
<p style=\"text-align: justify;\">5G is no more a topic that is only in the level of discussion. It is on the verge of materialization and it is expected to come soon to the market and will make a great impact on enterprises and consumers. 5G will be more than 100 times speeder than currently existing 4G and more than 10 times speedier than the conventional broadband internet connection. With this fantastic level of speed, it has opened the door for technologies like AR, VR, IoT and Edge computing to become a high possibility.</p>
<p style=\"text-align: justify;\"><strong>AI</strong></p>
<p style=\"text-align: justify;\">There are plenty of benefits of AI. Apart from the rapid Internet speed, the other important benefits of 5G are the capability to deal with technologies to the likes of AI. There are two reasons why AI needs to be used in telecommunications. First, AI can be utilized to enhance the methodologies for planning and managing the networks. The network operators will be able to easily foresee their customer needs, while controlling the tariffs. The telecommunication industry can take lots of advantage with the AI and 5G.</p>
<p style=\"text-align: justify;\">Mobility has been influencing various industries across the world and the manufacturing industry is no exception. Many industries have adopted the mobility strategies to empower the business. The growth extraordinary growth of IoT has made lots of impact in the manufacturing sector. The total number of devices connected, spanning the industries across the globe, is expected to increase up to 8.4 billion, which is 31% higher than 2016.</p>
<p style=\"text-align: justify;\">The technology has eased the manufacturing floors in a significant way. Today, workers at manufacturing sites are able to work with less fatigue, due to the advancement and implementation of mobility technology. One of the finest examples is the robotic technology in the manufacturing sector.</p>
<p style=\"text-align: justify;\">With the rapid advancement of mobility technology, it is sure that all the industries are going to see a rapid development.</p>","Popular Trends of Mobility Technology","","inherit","closed","closed","","21-revision-v1","","","2018-10-31 10:55:06","2018-10-31 10:55:06","","21","http://aim-expo.com/21-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("23","1","2017-11-20 10:55:19","2017-11-20 10:55:19","<p style=\"text-align: justify;\">Technology has advanced in various aspects. Mobility technology is one of the hot technologies that has been impacting multiple industries in a positive note. The concept of enterprise mobility has already become increasingly popular due to the utilization of cloud services. The cloud services have significantly revolutionized the functioning of the enterprises in the recent decades. With cloud technology, the enterprises were able to improve to their workforce to a drastic. Gone are the days, when the enterprise staffs relying on the single computer for all their jobs.</p>
<p style=\"text-align: justify;\">Today, with the help of the cloud, the enterprise staffs are able to access the work files anywhere through their mobile phone, tablets and other mobile computing devices. Combined advancement in the cloud and mobile technologies made it possible for increased implementation and use of mobile apps.</p>
<p style=\"text-align: justify;\">Enterprise mobility is playing a crucial and deciding role in improving the productivity of the staffs and employees. The enterprise staffs can stay connected with each other, thereby avoiding the possible delay and lag in the communication. In another significant development, the boom of enterprise mobility paved the way for a new policy called BYOD (Bring Your Own Device). In this policy, the staffs and employees are permitted to bring their laptops, computer, smartphones and other devices for the job reasons.</p>
<p style=\"text-align: justify;\">With the utilization of Enterprise mobility, the organizations are able to enjoy a competitive advantage. Enterprise mobility has also revolutionized the landscape of B2E, B2C and B2B. Now let us look into the some of the top companies in the Enterprise mobility services.</p>
<p style=\"text-align: justify;\"><strong>Accenture</strong></p>
<p style=\"text-align: justify;\">This company handles services related to technology, management consulting and business processing outsourcing. Accenture offers managed mobility services that comprise deployment, procurement, and MDM. This service helps the enterprise to associate with one provider, while maintaining a global reduce, thereby minimizing the possible complexity.</p>
<p style=\"text-align: justify;\"><strong>AT &amp; T</strong></p>
<p style=\"text-align: justify;\">This company offers advanced mobile solution services, which help the employees, customers, and assets of the organization stay connected to each other for a smooth workflow. The enterprise mobility from AT &amp; T offers a highly comprehensive solution makes it easy for companies to stay connected.</p>
<p style=\"text-align: justify;\"><strong>Atos</strong></p>
<p style=\"text-align: justify;\">This company has a client base globally, and it offers Manage Services, system integration, cloud operation, security solutions, Big Data and BPO services. Additionally, the company also provides transactional services.</p>
<p style=\"text-align: justify;\"><strong>Cisco</strong></p>
<p style=\"text-align: justify;\">This company offers a unified security policy all over the globe. Their solution has been helping the users to optimize and manage the mobile devices and security.</p>
<p style=\"text-align: justify;\"><strong>Deloitte</strong></p>
<p style=\"text-align: justify;\">Deloitte offers technologies, products, solutions, software, and services to SMEs, individual customers and large enterprises. This company provides methods of innovative mobility plan that helps the consumers and partners to generate good revenue. It also aids employees to have access to personal and business applications anytime.</p>
<p style=\"text-align: justify;\"><strong>Deutsche Telekom</strong></p>
<p style=\"text-align: justify;\">Being one of the top integrated telecommunication companies in the world, Deutsche Telekom has millions of mobile customers and fixed-network lines. This company now has its presence in 50 and more countries with 228, 000 staffs across the globe.</p>
<p style=\"text-align: justify;\">To know more about other top companies in mobility technologies, you can refer to other technology magazines. In fact, Technology has become like an ocean that keeps on expanding.</p>","Top Companies In Mobility Technology","","publish","open","closed","","top-companies-in-mobility-technology","","","2019-07-08 05:19:21","2019-07-08 05:19:21","","0","http://aim-expo.com/?p=23","0","post","","0");
INSERT INTO `wpst_posts` VALUES("24","1","2018-10-31 10:57:05","2018-10-31 10:57:05","<p style=\"text-align: justify;\">Technology has advanced in various aspects. Mobility technology is one of the hot technologies that has been impacting multiple industries in a positive note. The concept of enterprise mobility has already become increasingly popular due to the utilization of cloud services. The cloud services have significantly revolutionized the functioning of the enterprises in the recent decades. With cloud technology, the enterprises were able to improve to their workforce to a drastic. Gone are the days, when the enterprise staffs relying on the single computer for all their jobs.</p>
<p style=\"text-align: justify;\">Today, with the help of the cloud, the enterprise staffs are able to access the work files anywhere through their mobile phone, tablets and other mobile computing devices. Combined advancement in the cloud and mobile technologies made it possible for increased implementation and use of mobile apps.</p>
<p style=\"text-align: justify;\">Enterprise mobility is playing a crucial and deciding role in improving the productivity of the staffs and employees. The enterprise staffs can stay connected with each other, thereby avoiding the possible delay and lag in the communication. In another significant development, the boom of enterprise mobility paved the way for a new policy called BYOD (Bring Your Own Device). In this policy, the staffs and employees are permitted to bring their laptops, computer, smartphones and other devices for the job reasons.</p>
<p style=\"text-align: justify;\">With the utilization of Enterprise mobility, the organizations are able to enjoy a competitive advantage. Enterprise mobility has also revolutionized the landscape of B2E, B2C and B2B. Now let us look into the some of the top companies in the Enterprise mobility services.</p>
<p style=\"text-align: justify;\"><strong>Accenture</strong></p>
<p style=\"text-align: justify;\">This company handles services related to technology, management consulting and business processing outsourcing. Accenture offers managed mobility services that comprise deployment, procurement, and MDM. This service helps the enterprise to associate with one provider, while maintaining a global reduce, thereby minimizing the possible complexity.</p>
<p style=\"text-align: justify;\"><strong>AT &amp; T</strong></p>
<p style=\"text-align: justify;\">This company offers advanced mobile solution services, which help the employees, customers, and assets of the organization stay connected to each other for a smooth workflow. The enterprise mobility from AT &amp; T offers a highly comprehensive solution makes it easy for companies to stay connected.</p>
<p style=\"text-align: justify;\"><strong>Atos</strong></p>
<p style=\"text-align: justify;\">This company has a client base globally, and it offers Manage Services, system integration, cloud operation, security solutions, Big Data and BPO services. Additionally, the company also provides transactional services.</p>
<p style=\"text-align: justify;\"><strong>Cisco</strong></p>
<p style=\"text-align: justify;\">This company offers a unified security policy all over the globe. Their solution has been helping the users to optimize and manage the mobile devices and security.</p>
<p style=\"text-align: justify;\"><strong>Deloitte</strong></p>
<p style=\"text-align: justify;\">Deloitte offers technologies, products, solutions, software, and services to SMEs, individual customers and large enterprises. This company provides methods of innovative mobility plan that helps the consumers and partners to generate good revenue. It also aids employees to have access to personal and business applications anytime.</p>
<p style=\"text-align: justify;\"><strong>Deutsche Telekom</strong></p>
<p style=\"text-align: justify;\">Being one of the top integrated telecommunication companies in the world, Deutsche Telekom has millions of mobile customers and fixed-network lines. This company now has its presence in 50 and more countries with 228, 000 staffs across the globe.</p>
<p style=\"text-align: justify;\">To know more about other top companies in mobility technologies, you can refer to other technology magazines. In fact, Technology has become like an ocean that keeps on expanding.</p>","Top Companies In Mobility Technology","","inherit","closed","closed","","23-revision-v1","","","2018-10-31 10:57:05","2018-10-31 10:57:05","","23","http://aim-expo.com/23-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("110","1","2019-07-10 10:39:16","2019-07-10 10:39:16","{
    \"blogberg::disable_search_icon\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-10 10:39:16\"
    },
    \"blogberg::disable_hamburger_menu_icon\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-10 10:39:16\"
    },
    \"blogberg::disable_fixed_header\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-10 10:39:16\"
    }
}","","","trash","closed","closed","","b9e402c0-924e-4b32-8678-7836d81f045b","","","2019-07-10 10:39:16","2019-07-10 10:39:16","","0","https://www.aim-expo.com/b9e402c0-924e-4b32-8678-7836d81f045b/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("85","1","2019-07-08 04:51:23","2019-07-08 04:51:23","{
    \"blogberg::slider_category\": {
        \"value\": \"2\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:51:23\"
    }
}","","","trash","closed","closed","","2777de75-6d0e-4260-ab7e-ddc1e793fe38","","","2019-07-08 04:51:23","2019-07-08 04:51:23","","0","https://www.aim-expo.com/2777de75-6d0e-4260-ab7e-ddc1e793fe38/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("28","1","2018-10-31 11:27:55","2018-10-31 11:27:55","","Automatic Identification","","inherit","open","closed","","automatic-identification","","","2018-10-31 11:27:55","2018-10-31 11:27:55","","17","http://aim-expo.com/wp-content/uploads/2018/08/Automatic-Identification.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("29","1","2018-10-31 11:37:21","2018-10-31 11:37:21","","Leading Automatic Identification","","inherit","open","closed","","leading-automatic-identification","","","2018-10-31 11:37:21","2018-10-31 11:37:21","","19","http://aim-expo.com/wp-content/uploads/2018/03/Leading-Automatic-Identification.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("30","1","2018-10-31 11:37:34","2018-10-31 11:37:34","<p style=\"text-align: justify;\">In recent years, the workplace is transformed into completely wireless workstations and the DC and warehouse managers are doing a lot of tasks without much effort. The best part is they are able to satisfy the customer’s requirements. Automatic Identification and Data Capture solutions are grown extensively. The sales for such technology products are increased globally. It is used in logistics, warehouses and factories applications. In 2016, the sales have reached $6.13 billion and in 2017, the sales were significantly increased to $6.35 billion as per the VDC Research Group.
<strong>Leading suppliers</strong>
Zebra Technologies occupies the #1 rank since 2015. The total sale revenue was $2.130 million in 2016. It is followed by Datalogic with the sales revenue of $556 million and Honeywell with the sales revenue of $1.022. The top 10 suppliers of 2016 were Fujian Newland, Casio Computer Co., SICK AG, Cognex, Denso Wave, Toshiba TEC,and SATO.
The sales of the handheld scanner have been greatly improved and the overall profits are 9.66% more than the last year period. The market leaders Zebra Technologies and Honeywell has seen significantly improved revenue performance in 2016. The sales of camera-based imager have helped in overall market growth in the first three months of the year. The sales have been increased by 16% more than last year. The sales of laser scanner have been down by almost 9%.
This year, Zebra technologies, Honeywell and Datalogic are making exceptional investments in order to refresh and expand their products.,They are facing a stiffcompetition and looking to upgrade ahead of their competitors.
<strong>Barcoding and thermal printing</strong>
Desktop printers are expensive industrial printers and generate a greater percentage of complete revenues. Zebra Technologies, Toshiba TEC, SATO and Honeywell cannot depend on product quality and brand recognition alone to accomplish their profitability and sales targets. There is heavy competition especially in high growth countries like South Korea, Germany,and China. As there is a strong combination of emerging contenders and market leaders, there is healthy competition.
It is difficult for the hardware suppliers to meet pricing, compliance legislation and application particular labeling needs of top end-user verticals in all the region they compete. As per research, it is confirmed that revenues have increased in 2017 when compared to last year. It can be due to factors like new product launches by suppliers like Zebra technologies, TSC Printers and Honeywell and efforts to discourse traceability associated requirements in warehousing and manufacturing.
In the printer area, the research confirms that there has been a healthy sale increase of color label printers. If the traditional thermal barcode label printer manufacturers concentrate on monochrome products, establishments like Epson are thinking about adding colors in labels. It is not possible for traditional or typical barcode label print could accomplish.
<strong>Low labor expenses and fast shipment</strong>
The presence of e-commerce functions and vendor’s omnichannel ingenuity in DC/warehouse development and growth has helped in a great way for the success of the connected and enterprise mobility devices. Several initiatives have been taken for on-time delivery, shipping products quicker and reducing labor expenses.</p>","Leading Automatic Identification and Data Capture Suppliers","","inherit","closed","closed","","19-autosave-v1","","","2018-10-31 11:37:34","2018-10-31 11:37:34","","19","http://aim-expo.com/19-autosave-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("31","1","2018-10-31 11:38:01","2018-10-31 11:38:01","<p style=\"text-align: justify;\">The much awaited Mobile World Congress 2018 has ended in a good note. Being the biggest trade show in the mobile industry, Mobile World Congress offered an excellent platform for discussing various hot and trending topics ranging from 5G to artificial intelligence. In this piece of article, we are going to discuss <strong>Mobility technology</strong> and the highlights of the Mobile World Congress.</p>
<p style=\"text-align: justify;\">The trade show in Barcelona saw various mobile manufacturers from across the world, displaying their top-notch future devices. Many expected that 5G would be the show stealer. Now let us see the new trends, which were trending the news this year.</p>
<p style=\"text-align: justify;\"><strong>5G Connectivity</strong></p>
<p style=\"text-align: justify;\">The talks about 5G mobile connectivity have been doing rounds in the technology world for a while. In this trade show, the experts stressed that they are taking a step forward to materialize the concept of 5G connectivity. Kester Mann of CCS Insight says that the initial standard for 5G has been established and soon the people will be announcing this more officially.</p>
<p style=\"text-align: justify;\">The Internet connectivity has been playing a huge role in improving the lives of the mobile users. With the materialization and implementation of 5G connectivity, the mobile users will see a significant improvement in their mobile experience. There were plenty of topics about 5G was discussed in the MWC 2018.</p>
<p style=\"text-align: justify;\">5G is no more a topic that is only in the level of discussion. It is on the verge of materialization and it is expected to come soon to the market and will make a great impact on enterprises and consumers. 5G will be more than 100 times speeder than currently existing 4G and more than 10 times speedier than the conventional broadband internet connection. With this fantastic level of speed, it has opened the door for technologies like AR, VR, IoT and Edge computing to become a high possibility.</p>
<p style=\"text-align: justify;\"><strong>AI</strong></p>
<p style=\"text-align: justify;\">There are plenty of benefits of AI. Apart from the rapid Internet speed, the other important benefits of 5G are the capability to deal with technologies to the likes of AI. There are two reasons why AI needs to be used in telecommunications. First, AI can be utilized to enhance the methodologies for planning and managing the networks. The network operators will be able to easily foresee their customer needs, while controlling the tariffs. The telecommunication industry can take lots of advantage with the AI and 5G.</p>
<p style=\"text-align: justify;\">Mobility has been influencing various industries across the world and the manufacturing industry is no exception. Many industries have adopted the mobility strategies to empower the business. The growth extraordinary growth of IoT has made lots of impact in the manufacturing sector. The total number of devices connected, spanning the industries across the globe, is expected to increase up to 8.4 billion, which is 31% higher than 2016.</p>
<p style=\"text-align: justify;\">The technology has eased the manufacturing floors in a significant way. Today, workers at manufacturing sites are able to work with less fatigue, due to the advancement and implementation of mobility technology. One of the finest examples is the robotic technology in the manufacturing sector.</p>
<p style=\"text-align: justify;\">With the rapid advancement of mobility technology, it is sure that all the industries are going to see a rapid development.</p>","Popular Trends of Mobility Technology","","inherit","closed","closed","","21-autosave-v1","","","2018-10-31 11:38:01","2018-10-31 11:38:01","","21","http://aim-expo.com/21-autosave-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("35","1","2018-10-31 11:50:34","2018-10-31 11:50:34","","Mobility as a Service concept illustration","","inherit","open","closed","","mobility-as-a-service-concept-illustration","","","2018-10-31 11:51:12","2018-10-31 11:51:12","","23","http://aim-expo.com/wp-content/uploads/2017/11/MaaS.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("36","1","2018-10-31 11:51:26","2018-10-31 11:51:26","","mobility-solutions","","inherit","open","closed","","mobility-solutions","","","2018-10-31 11:51:26","2018-10-31 11:51:26","","21","http://aim-expo.com/wp-content/uploads/2018/01/mobility-solutions.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("38","1","2018-10-31 11:55:24","2018-10-31 11:55:24","<iframe src=\"https://www.youtube.com/embed/JU9hPlxEvP4\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>","Automatic identification at the Shrink Wrapper","","inherit","closed","closed","","37-revision-v1","","","2018-10-31 11:55:24","2018-10-31 11:55:24","","37","http://aim-expo.com/37-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("37","1","2017-10-30 11:54:35","2017-10-30 11:54:35","<iframe src=\"https://www.youtube.com/embed/JU9hPlxEvP4\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>","Automatic identification at the Shrink Wrapper","","publish","open","closed","","automatic-identification-at-the-shrink-wrapper","","","2019-07-08 05:19:49","2019-07-08 05:19:49","","0","http://aim-expo.com/?p=37","0","post","","0");
INSERT INTO `wpst_posts` VALUES("39","1","2018-10-31 11:57:59","2018-10-31 11:57:59","","Automatic identification1","","inherit","open","closed","","automatic-identification1","","","2018-10-31 11:57:59","2018-10-31 11:57:59","","37","http://aim-expo.com/wp-content/uploads/2017/10/Automatic-identification1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("41","1","2018-10-31 12:31:47","2018-10-31 12:31:47","","vpsforextrader","","inherit","open","closed","","vpsforextrader","","","2018-10-31 12:31:47","2018-10-31 12:31:47","","0","http://aim-expo.com/wp-content/uploads/2018/10/vpsforextrader.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("42","1","2018-10-31 12:41:22","2018-10-31 12:41:22","","zebra","","inherit","open","closed","","zebra","","","2018-10-31 12:41:22","2018-10-31 12:41:22","","0","http://aim-expo.com/wp-content/uploads/2018/10/zebra.png","0","attachment","image/png","0");
INSERT INTO `wpst_posts` VALUES("43","1","2018-10-31 12:59:21","2018-10-31 12:59:21","","tsys","","inherit","open","closed","","tsys","","","2018-10-31 12:59:21","2018-10-31 12:59:21","","0","http://aim-expo.com/wp-content/uploads/2018/10/tsys.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("67","1","2018-11-03 12:27:20","2018-11-03 12:27:20","","AIMExpo","","inherit","open","closed","","aimexpo","","","2018-11-03 12:27:20","2018-11-03 12:27:20","","0","http://aim-expo.com/wp-content/uploads/2018/11/AIMExpo.png","0","attachment","image/png","0");
INSERT INTO `wpst_posts` VALUES("45","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","45","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=45","3","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("46","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","46","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=46","8","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("47","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","47","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=47","9","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("48","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","48","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=48","2","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("49","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","49","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=49","7","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("50","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","50","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=50","5","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("51","1","2018-10-31 13:01:43","2018-10-31 13:01:43"," ","","","publish","closed","closed","","51","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","http://aim-expo.com/?p=51","6","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("109","1","2019-07-08 06:33:20","2019-07-08 06:33:20","","Home","","publish","closed","closed","","home","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","https://www.aim-expo.com/?p=109","1","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("53","1","2018-10-31 13:02:15","2018-10-31 13:02:15"," ","","","publish","closed","closed","","53","","","2018-10-31 13:02:15","2018-10-31 13:02:15","","0","http://aim-expo.com/?p=53","4","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("54","1","2018-10-31 13:02:15","2018-10-31 13:02:15"," ","","","publish","closed","closed","","54","","","2018-10-31 13:02:15","2018-10-31 13:02:15","","0","http://aim-expo.com/?p=54","5","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("55","1","2018-10-31 13:02:15","2018-10-31 13:02:15"," ","","","publish","closed","closed","","55","","","2018-10-31 13:02:15","2018-10-31 13:02:15","","0","http://aim-expo.com/?p=55","3","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("56","1","2018-10-31 13:02:15","2018-10-31 13:02:15"," ","","","publish","closed","closed","","56","","","2018-10-31 13:02:15","2018-10-31 13:02:15","","0","http://aim-expo.com/?p=56","2","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("81","1","2019-07-08 04:38:56","2019-07-08 04:38:56","{
    \"ts-mobile-app::bb_mobile_application_blogcategory_right_setting\": {
        \"value\": \"mobility-trends\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:56\"
    }
}","","","trash","closed","closed","","5a34ac21-3082-4833-af0a-9a7fb4c62c90","","","2019-07-08 04:38:56","2019-07-08 04:38:56","","0","https://www.aim-expo.com/5a34ac21-3082-4833-af0a-9a7fb4c62c90/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("82","1","2019-07-08 04:39:57","2019-07-08 04:39:57","{
    \"web-app::web_app_weblayout\": {
        \"value\": \"box-layout\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:39:57\"
    }
}","","","trash","closed","closed","","b2b11e7e-98c7-4181-9b63-d36de3e372ef","","","2019-07-08 04:39:57","2019-07-08 04:39:57","","0","https://www.aim-expo.com/b2b11e7e-98c7-4181-9b63-d36de3e372ef/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("83","1","2019-07-08 04:40:09","2019-07-08 04:40:09","{
    \"web-app::web_app_slider_option\": {
        \"value\": \"yes\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:40:09\"
    },
    \"web-app::web_app_slider_section_cat\": {
        \"value\": \"mobility-trends\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:40:09\"
    }
}","","","trash","closed","closed","","4539444c-003a-41da-8303-4643b81c6d36","","","2019-07-08 04:40:09","2019-07-08 04:40:09","","0","https://www.aim-expo.com/4539444c-003a-41da-8303-4643b81c6d36/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("84","1","2019-07-08 04:40:26","2019-07-08 04:40:26","{
    \"web-app::web_app_page_bg_image\": {
        \"value\": \"https://www.aim-expo.com/wp-content/uploads/2018/01/mobility-solutions.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:40:26\"
    }
}","","","trash","closed","closed","","05a801c9-b8c4-4f4a-abb9-0143ec79beaf","","","2019-07-08 04:40:26","2019-07-08 04:40:26","","0","https://www.aim-expo.com/05a801c9-b8c4-4f4a-abb9-0143ec79beaf/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("80","1","2019-07-08 04:38:49","2019-07-08 04:38:49","{
    \"ts-mobile-app::bb_mobile_application_middle_image_setting\": {
        \"value\": \"Leading Automatic Identification and Data Capture Suppliers\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:49\"
    }
}","","","trash","closed","closed","","c08a1970-1fd6-4c58-9b2a-cc8128e13efd","","","2019-07-08 04:38:49","2019-07-08 04:38:49","","0","https://www.aim-expo.com/c08a1970-1fd6-4c58-9b2a-cc8128e13efd/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("60","1","2018-10-31 13:14:51","2018-10-31 13:14:51",".copyright span:last-child {
	display: none;}
.site-branding {
	text-align: center;}","mega-magazine","","publish","closed","closed","","mega-magazine","","","2018-11-03 12:29:02","2018-11-03 12:29:02","","0","http://aim-expo.com/mega-magazine/","0","custom_css","","0");
INSERT INTO `wpst_posts` VALUES("61","1","2018-10-31 13:14:51","2018-10-31 13:14:51",".copyright span:last-child {
	display: none;}","mega-magazine","","inherit","closed","closed","","60-revision-v1","","","2018-10-31 13:14:51","2018-10-31 13:14:51","","60","http://aim-expo.com/60-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("62","1","2018-10-31 13:16:58","2018-10-31 13:16:58","","Barcode-Scanner","","inherit","open","closed","","barcode-scanner","","","2018-10-31 13:16:58","2018-10-31 13:16:58","","0","http://aim-expo.com/wp-content/uploads/2018/10/Barcode-Scanner.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("79","1","2019-07-08 04:38:42","2019-07-08 04:38:42","{
    \"ts-mobile-app::bb_mobile_application_blogcategory_left_setting\": {
        \"value\": \"blog\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:42\"
    }
}","","","trash","closed","closed","","8746decc-5c27-4780-b991-e5e7d2c37a21","","","2019-07-08 04:38:42","2019-07-08 04:38:42","","0","https://www.aim-expo.com/8746decc-5c27-4780-b991-e5e7d2c37a21/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("78","1","2019-07-08 04:38:21","2019-07-08 04:38:21","{
    \"ts-mobile-app::bb_mobile_application_theme_options\": {
        \"value\": \"Right Sidebar\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:21\"
    }
}","","","trash","closed","closed","","5e268174-97d0-4037-8d6e-5afc7a5e2dd7","","","2019-07-08 04:38:21","2019-07-08 04:38:21","","0","https://www.aim-expo.com/5e268174-97d0-4037-8d6e-5afc7a5e2dd7/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("77","1","2019-07-08 04:38:15","2019-07-08 04:38:15","{
    \"ts-mobile-app::bb_mobile_application_theme_options\": {
        \"value\": \"Left Sidebar\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:15\"
    }
}","","","trash","closed","closed","","6b39d016-5019-4247-8f1d-6dbf741e1897","","","2019-07-08 04:38:15","2019-07-08 04:38:15","","0","https://www.aim-expo.com/6b39d016-5019-4247-8f1d-6dbf741e1897/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("76","1","2019-07-08 04:38:08","2019-07-08 04:38:08","{
    \"ts-mobile-app::bb_mobile_application_theme_options\": {
        \"value\": \"Grid Layout\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:38:08\"
    }
}","","","trash","closed","closed","","63d16832-79a1-4d30-9ad4-67451e747e0c","","","2019-07-08 04:38:08","2019-07-08 04:38:08","","0","https://www.aim-expo.com/63d16832-79a1-4d30-9ad4-67451e747e0c/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("113","1","2019-07-14 07:27:54","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","closed","","","","","2019-07-14 07:27:54","0000-00-00 00:00:00","","0","https://www.aim-expo.com/?p=113","0","post","","0");
INSERT INTO `wpst_posts` VALUES("74","1","2019-07-08 04:31:40","2019-07-08 04:31:40","","Mobility Technology","","publish","closed","closed","","mobility-technology","","","2019-07-10 10:40:14","2019-07-10 10:40:14","","0","https://www.aim-expo.com/?p=74","4","nav_menu_item","","0");
INSERT INTO `wpst_posts` VALUES("75","1","2019-07-08 04:37:49","2019-07-08 04:37:49","{
    \"show_on_front\": {
        \"value\": \"posts\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:37:49\"
    }
}","","","trash","closed","closed","","2b7de14d-3555-450a-89c8-dc715602d2d0","","","2019-07-08 04:37:49","2019-07-08 04:37:49","","0","https://www.aim-expo.com/2b7de14d-3555-450a-89c8-dc715602d2d0/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("70","1","2018-11-03 12:29:02","2018-11-03 12:29:02",".copyright span:last-child {
	display: none;}
.site-branding {
	text-align: center;}","mega-magazine","","inherit","closed","closed","","60-revision-v1","","","2018-11-03 12:29:02","2018-11-03 12:29:02","","60","http://aim-expo.com/60-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("86","1","2019-07-08 04:53:28","2019-07-08 04:53:28","","cropped-mobility-solutions.jpg","","inherit","open","closed","","cropped-mobility-solutions-jpg","","","2019-07-08 04:53:28","2019-07-08 04:53:28","","0","https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("87","1","2019-07-08 04:53:33","2019-07-08 04:53:33","{
    \"blogberg::header_image\": {
        \"value\": \"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:53:33\"
    },
    \"blogberg::header_image_data\": {
        \"value\": {
            \"url\": \"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\",
            \"thumbnail_url\": \"https://www.aim-expo.com/wp-content/uploads/2018/01/cropped-mobility-solutions.jpg\",
            \"timestamp\": 1562561607816,
            \"attachment_id\": 86,
            \"width\": 1920,
            \"height\": 379
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:53:33\"
    }
}","","","trash","closed","closed","","0cebaa71-c11b-4989-a162-482453ec6fd8","","","2019-07-08 04:53:33","2019-07-08 04:53:33","","0","https://www.aim-expo.com/0cebaa71-c11b-4989-a162-482453ec6fd8/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("88","1","2019-07-08 04:56:46","2019-07-08 04:56:46","","BG-1000x675","","inherit","open","closed","","bg-1000x675","","","2019-07-08 04:56:46","2019-07-08 04:56:46","","0","https://www.aim-expo.com/wp-content/uploads/2019/07/BG-1000x675.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wpst_posts` VALUES("89","1","2019-07-08 04:57:37","2019-07-08 04:57:37","{
    \"blogberg::background_image\": {
        \"value\": \"https://www.aim-expo.com/wp-content/uploads/2019/07/BG-1000x675.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:57:37\"
    },
    \"blogberg::background_preset\": {
        \"value\": \"fill\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:57:37\"
    },
    \"blogberg::background_size\": {
        \"value\": \"cover\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:57:37\"
    },
    \"blogberg::background_repeat\": {
        \"value\": \"no-repeat\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:57:37\"
    },
    \"blogberg::background_attachment\": {
        \"value\": \"fixed\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:57:37\"
    }
}","","","trash","closed","closed","","530251ed-86e9-44a4-84ed-fe53c5745b63","","","2019-07-08 04:57:37","2019-07-08 04:57:37","","0","https://www.aim-expo.com/?p=89","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("90","1","2019-07-08 04:58:57","2019-07-08 04:58:57","","767","","inherit","open","closed","","767","","","2019-07-08 04:58:57","2019-07-08 04:58:57","","0","https://www.aim-expo.com/wp-content/uploads/2019/07/767.png","0","attachment","image/png","0");
INSERT INTO `wpst_posts` VALUES("91","1","2019-07-08 04:59:11","2019-07-08 04:59:11","{
    \"blogberg::background_image\": {
        \"value\": \"https://www.aim-expo.com/wp-content/uploads/2019/07/767.png\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:59:11\"
    },
    \"blogberg::background_repeat\": {
        \"value\": \"repeat\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 04:59:11\"
    }
}","","","trash","closed","closed","","f381ee8b-c932-4cdc-8ad0-7ae170462308","","","2019-07-08 04:59:11","2019-07-08 04:59:11","","0","https://www.aim-expo.com/f381ee8b-c932-4cdc-8ad0-7ae170462308/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("92","1","2019-07-08 05:00:06","2019-07-08 05:00:06","{
    \"blogberg::custom_logo\": {
        \"value\": 67,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:00:06\"
    },
    \"blogberg::header_textcolor\": {
        \"value\": \"blank\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:00:06\"
    }
}","","","trash","closed","closed","","37845b9d-db7a-4d40-a721-8fe3e0ee15a9","","","2019-07-08 05:00:06","2019-07-08 05:00:06","","0","https://www.aim-expo.com/37845b9d-db7a-4d40-a721-8fe3e0ee15a9/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("93","1","2019-07-08 05:03:44","2019-07-08 05:03:44","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:03:44\"
    }
}","","","trash","closed","closed","","ed5984e3-45d2-4cd1-9d21-950747ca2bd5","","","2019-07-08 05:03:44","2019-07-08 05:03:44","","0","https://www.aim-expo.com/ed5984e3-45d2-4cd1-9d21-950747ca2bd5/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("94","1","2019-07-08 05:03:44","2019-07-08 05:03:44",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}
.top-footer .widget .tagcloud a
{
	color: #fff;
}
.site-footer
{
background: #55acee;
}
.top-footer .widget .widget-title
{
color: #fff;
font-size: 16px;
font-weight: 800;
}
.top-footer .widget ul li a
{

color: #fff;
font-size: 16px;
}
.site-footer .copyright
{
	display: none;
}
.wrap-detail-page article.post-content
{
	padding: 30px;
}","blogberg","","publish","closed","closed","","blogberg","","","2019-07-10 10:55:54","2019-07-10 10:55:54","","0","https://www.aim-expo.com/blogberg/","0","custom_css","","0");
INSERT INTO `wpst_posts` VALUES("95","1","2019-07-08 05:03:44","2019-07-08 05:03:44",".site-header .site-branding-outer img
{
	max-width: 307px;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-08 05:03:44","2019-07-08 05:03:44","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("96","1","2019-07-08 05:10:04","2019-07-08 05:10:04","{
    \"blogberg::background_preset\": {
        \"value\": \"fit\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:10:04\"
    },
    \"blogberg::background_size\": {
        \"value\": \"contain\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:10:04\"
    },
    \"blogberg::background_repeat\": {
        \"value\": \"no-repeat\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:10:04\"
    }
}","","","trash","closed","closed","","ceb3981b-4830-46a8-9667-fa49ae34fe3e","","","2019-07-08 05:10:04","2019-07-08 05:10:04","","0","https://www.aim-expo.com/ceb3981b-4830-46a8-9667-fa49ae34fe3e/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("97","1","2019-07-08 05:15:42","2019-07-08 05:15:42","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\\n.main-navigation nav > ul > li > a\\n{\\n\\tfont-size: 15px;\\n\\tfont-weight: 800;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:15:42\"
    }
}","","","trash","closed","closed","","f4758416-923d-417a-b9f1-412ecb25ecae","","","2019-07-08 05:15:42","2019-07-08 05:15:42","","0","https://www.aim-expo.com/f4758416-923d-417a-b9f1-412ecb25ecae/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("98","1","2019-07-08 05:15:42","2019-07-08 05:15:42",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-08 05:15:42","2019-07-08 05:15:42","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("99","1","2019-07-08 05:26:52","2019-07-08 05:26:52","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\\n.main-navigation nav > ul > li > a\\n{\\n\\tfont-size: 15px;\\n\\tfont-weight: 800;\\n}\\n.top-footer .widget .tagcloud a\\n{\\n\\tcolor: #fff;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:26:52\"
    }
}","","","trash","closed","closed","","1cb7c945-d020-4f0a-928a-3e0e97412251","","","2019-07-08 05:26:52","2019-07-08 05:26:52","","0","https://www.aim-expo.com/1cb7c945-d020-4f0a-928a-3e0e97412251/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("100","1","2019-07-08 05:26:52","2019-07-08 05:26:52",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}
.top-footer .widget .tagcloud a
{
	color: #fff;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-08 05:26:52","2019-07-08 05:26:52","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("101","1","2019-07-08 05:27:11","2019-07-08 05:27:11","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\\n.main-navigation nav > ul > li > a\\n{\\n\\tfont-size: 15px;\\n\\tfont-weight: 800;\\n}\\n.top-footer .widget .tagcloud a\\n{\\n\\tcolor: #fff;\\n}\\n.site-footer\\n{\\nbackground: #55acee;\\n}\\n.top-footer .widget .widget-title\\n{\\ncolor: #fff;\\nfont-size: 16px;\\nfont-weight: 800;\\n}\\n.top-footer .widget ul li a\\n{\\n\\ncolor: #fff;\\nfont-size: 16px;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:27:11\"
    }
}","","","trash","closed","closed","","f722da9f-12eb-400e-8c90-710e904a2d39","","","2019-07-08 05:27:11","2019-07-08 05:27:11","","0","https://www.aim-expo.com/f722da9f-12eb-400e-8c90-710e904a2d39/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("102","1","2019-07-08 05:27:11","2019-07-08 05:27:11",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}
.top-footer .widget .tagcloud a
{
	color: #fff;
}
.site-footer
{
background: #55acee;
}
.top-footer .widget .widget-title
{
color: #fff;
font-size: 16px;
font-weight: 800;
}
.top-footer .widget ul li a
{

color: #fff;
font-size: 16px;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-08 05:27:11","2019-07-08 05:27:11","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("103","1","2019-07-08 05:28:49","2019-07-08 05:28:49","{
    \"blogberg::footer_text\": {
        \"value\": \"Copyright \\u00a9 2019. All Rights Reserved by AIMExpo.\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:28:49\"
    }
}","","","trash","closed","closed","","d11a64fc-130b-4790-b5e9-5fbc8cab64d8","","","2019-07-08 05:28:49","2019-07-08 05:28:49","","0","https://www.aim-expo.com/?p=103","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("104","1","2019-07-08 05:30:25","2019-07-08 05:30:25","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\\n.main-navigation nav > ul > li > a\\n{\\n\\tfont-size: 15px;\\n\\tfont-weight: 800;\\n}\\n.top-footer .widget .tagcloud a\\n{\\n\\tcolor: #fff;\\n}\\n.site-footer\\n{\\nbackground: #55acee;\\n}\\n.top-footer .widget .widget-title\\n{\\ncolor: #fff;\\nfont-size: 16px;\\nfont-weight: 800;\\n}\\n.top-footer .widget ul li a\\n{\\n\\ncolor: #fff;\\nfont-size: 16px;\\n}\\n.site-footer .copyright\\n{\\n\\tdisplay: none;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:30:25\"
    }
}","","","trash","closed","closed","","6550b91d-fe4e-4610-9034-e60fa3477393","","","2019-07-08 05:30:25","2019-07-08 05:30:25","","0","https://www.aim-expo.com/6550b91d-fe4e-4610-9034-e60fa3477393/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("105","1","2019-07-08 05:30:25","2019-07-08 05:30:25",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}
.top-footer .widget .tagcloud a
{
	color: #fff;
}
.site-footer
{
background: #55acee;
}
.top-footer .widget .widget-title
{
color: #fff;
font-size: 16px;
font-weight: 800;
}
.top-footer .widget ul li a
{

color: #fff;
font-size: 16px;
}
.site-footer .copyright
{
	display: none;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-08 05:30:25","2019-07-08 05:30:25","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("106","1","2019-07-08 05:32:27","2019-07-08 05:32:27","","computer_blue","","inherit","open","closed","","computer_blue","","","2019-07-08 05:32:27","2019-07-08 05:32:27","","0","https://www.aim-expo.com/wp-content/uploads/2019/07/computer_blue.png","0","attachment","image/png","0");
INSERT INTO `wpst_posts` VALUES("107","1","2019-07-08 05:32:34","2019-07-08 05:32:34","{
    \"site_icon\": {
        \"value\": 106,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-08 05:32:34\"
    }
}","","","trash","closed","closed","","d667bbb3-ab7e-4d28-9a54-a2c36ba57710","","","2019-07-08 05:32:34","2019-07-08 05:32:34","","0","https://www.aim-expo.com/d667bbb3-ab7e-4d28-9a54-a2c36ba57710/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("111","1","2019-07-10 10:55:54","2019-07-10 10:55:54","{
    \"custom_css[blogberg]\": {
        \"value\": \".site-header .site-branding-outer img\\n{\\n\\tmax-width: 307px;\\n}\\n.main-navigation nav > ul > li > a\\n{\\n\\tfont-size: 15px;\\n\\tfont-weight: 800;\\n}\\n.top-footer .widget .tagcloud a\\n{\\n\\tcolor: #fff;\\n}\\n.site-footer\\n{\\nbackground: #55acee;\\n}\\n.top-footer .widget .widget-title\\n{\\ncolor: #fff;\\nfont-size: 16px;\\nfont-weight: 800;\\n}\\n.top-footer .widget ul li a\\n{\\n\\ncolor: #fff;\\nfont-size: 16px;\\n}\\n.site-footer .copyright\\n{\\n\\tdisplay: none;\\n}\\n.wrap-detail-page article.post-content\\n{\\n\\tpadding: 30px;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-07-10 10:55:54\"
    }
}","","","trash","closed","closed","","bc4032c7-6a6f-4cb3-8422-adabd79407c1","","","2019-07-10 10:55:54","2019-07-10 10:55:54","","0","https://www.aim-expo.com/bc4032c7-6a6f-4cb3-8422-adabd79407c1/","0","customize_changeset","","0");
INSERT INTO `wpst_posts` VALUES("112","1","2019-07-10 10:55:54","2019-07-10 10:55:54",".site-header .site-branding-outer img
{
	max-width: 307px;
}
.main-navigation nav > ul > li > a
{
	font-size: 15px;
	font-weight: 800;
}
.top-footer .widget .tagcloud a
{
	color: #fff;
}
.site-footer
{
background: #55acee;
}
.top-footer .widget .widget-title
{
color: #fff;
font-size: 16px;
font-weight: 800;
}
.top-footer .widget ul li a
{

color: #fff;
font-size: 16px;
}
.site-footer .copyright
{
	display: none;
}
.wrap-detail-page article.post-content
{
	padding: 30px;
}","blogberg","","inherit","closed","closed","","94-revision-v1","","","2019-07-10 10:55:54","2019-07-10 10:55:54","","94","https://www.aim-expo.com/94-revision-v1/","0","revision","","0");
INSERT INTO `wpst_posts` VALUES("114","2","2019-07-14 07:29:49","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","closed","","","","","2019-07-14 07:29:49","0000-00-00 00:00:00","","0","https://www.aim-expo.com/?p=114","0","post","","0");


DROP TABLE IF EXISTS `wpst_term_relationships`;

CREATE TABLE `wpst_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `wpst_term_relationships` VALUES("17","1","0");
INSERT INTO `wpst_term_relationships` VALUES("19","1","0");
INSERT INTO `wpst_term_relationships` VALUES("37","11","0");
INSERT INTO `wpst_term_relationships` VALUES("23","10","0");
INSERT INTO `wpst_term_relationships` VALUES("21","9","0");
INSERT INTO `wpst_term_relationships` VALUES("19","8","0");
INSERT INTO `wpst_term_relationships` VALUES("17","7","0");
INSERT INTO `wpst_term_relationships` VALUES("23","2","0");
INSERT INTO `wpst_term_relationships` VALUES("21","2","0");
INSERT INTO `wpst_term_relationships` VALUES("37","1","0");
INSERT INTO `wpst_term_relationships` VALUES("17","6","0");
INSERT INTO `wpst_term_relationships` VALUES("74","4","0");
INSERT INTO `wpst_term_relationships` VALUES("109","4","0");
INSERT INTO `wpst_term_relationships` VALUES("48","4","0");
INSERT INTO `wpst_term_relationships` VALUES("49","4","0");
INSERT INTO `wpst_term_relationships` VALUES("50","4","0");
INSERT INTO `wpst_term_relationships` VALUES("51","4","0");
INSERT INTO `wpst_term_relationships` VALUES("47","4","0");
INSERT INTO `wpst_term_relationships` VALUES("45","4","0");
INSERT INTO `wpst_term_relationships` VALUES("46","4","0");
INSERT INTO `wpst_term_relationships` VALUES("56","5","0");
INSERT INTO `wpst_term_relationships` VALUES("55","5","0");
INSERT INTO `wpst_term_relationships` VALUES("53","5","0");
INSERT INTO `wpst_term_relationships` VALUES("54","5","0");


DROP TABLE IF EXISTS `wpst_term_taxonomy`;

CREATE TABLE `wpst_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_term_taxonomy` VALUES("1","1","category","","0","3");
INSERT INTO `wpst_term_taxonomy` VALUES("2","2","category","","0","2");
INSERT INTO `wpst_term_taxonomy` VALUES("3","3","category","","0","0");
INSERT INTO `wpst_term_taxonomy` VALUES("6","6","post_tag","","0","1");
INSERT INTO `wpst_term_taxonomy` VALUES("4","4","nav_menu","","0","9");
INSERT INTO `wpst_term_taxonomy` VALUES("5","5","nav_menu","","0","4");
INSERT INTO `wpst_term_taxonomy` VALUES("7","7","post_tag","","0","1");
INSERT INTO `wpst_term_taxonomy` VALUES("8","8","post_tag","","0","1");
INSERT INTO `wpst_term_taxonomy` VALUES("9","9","post_tag","","0","1");
INSERT INTO `wpst_term_taxonomy` VALUES("10","10","post_tag","","0","1");
INSERT INTO `wpst_term_taxonomy` VALUES("11","11","post_tag","","0","1");


DROP TABLE IF EXISTS `wpst_termmeta`;

CREATE TABLE `wpst_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wpst_terms`;

CREATE TABLE `wpst_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_terms` VALUES("1","Blog","blog","0");
INSERT INTO `wpst_terms` VALUES("2","Mobility Trends","mobility-trends","0");
INSERT INTO `wpst_terms` VALUES("3","Events/Expo","events-expo","0");
INSERT INTO `wpst_terms` VALUES("4","menu","menu","0");
INSERT INTO `wpst_terms` VALUES("5","top menu","top-menu","0");
INSERT INTO `wpst_terms` VALUES("6","Automatic Identification","automatic-identification","0");
INSERT INTO `wpst_terms` VALUES("7","Data Collection Technology","data-collection-technology","0");
INSERT INTO `wpst_terms` VALUES("8","Data Capture Suppliers","data-capture-suppliers","0");
INSERT INTO `wpst_terms` VALUES("9","Mobility Technology","mobility-technology","0");
INSERT INTO `wpst_terms` VALUES("10","Companies In Mobility Technology","companies-in-mobility-technology","0");
INSERT INTO `wpst_terms` VALUES("11","Shrink Wrapper","shrink-wrapper","0");


DROP TABLE IF EXISTS `wpst_usermeta`;

CREATE TABLE `wpst_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_usermeta` VALUES("1","1","nickname","Aim-Expo Team");
INSERT INTO `wpst_usermeta` VALUES("2","1","first_name","Aim-Expo Team");
INSERT INTO `wpst_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wpst_usermeta` VALUES("4","1","description","");
INSERT INTO `wpst_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wpst_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wpst_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wpst_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wpst_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wpst_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wpst_usermeta` VALUES("11","1","locale","");
INSERT INTO `wpst_usermeta` VALUES("12","1","wpst_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wpst_usermeta` VALUES("13","1","wpst_user_level","10");
INSERT INTO `wpst_usermeta` VALUES("14","1","dismissed_wp_pointers","addtoany_settings_pointer,text_widget_custom_html,wp496_privacy,theme_editor_notice");
INSERT INTO `wpst_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wpst_usermeta` VALUES("56","2","session_tokens","a:1:{s:64:\"faba4681a67eb375096798d2b8afc94e73bccd3832caeba31c066093cbf4eb3b\";a:4:{s:10:\"expiration\";i:1563262189;s:2:\"ip\";s:12:\"157.50.0.234\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36\";s:5:\"login\";i:1563089389;}}");
INSERT INTO `wpst_usermeta` VALUES("17","1","wpst_dashboard_quick_press_last_post_id","113");
INSERT INTO `wpst_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:11:\"202.83.59.0\";}");
INSERT INTO `wpst_usermeta` VALUES("19","1","wpst_user-settings","urlbutton=none&editor=html&libraryContent=browse&align=center&imgsize=full");
INSERT INTO `wpst_usermeta` VALUES("20","1","wpst_user-settings-time","1540990839");
INSERT INTO `wpst_usermeta` VALUES("31","1","facebook","");
INSERT INTO `wpst_usermeta` VALUES("21","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wpst_usermeta` VALUES("22","1","metaboxhidden_nav-menus","a:3:{i:0;s:12:\"add-post_tag\";i:1;s:23:\"add-attachment_category\";i:2;s:18:\"add-attachment_tag\";}");
INSERT INTO `wpst_usermeta` VALUES("23","1","nav_menu_recently_edited","4");
INSERT INTO `wpst_usermeta` VALUES("25","1","_yoast_wpseo_profile_updated","1562567136");
INSERT INTO `wpst_usermeta` VALUES("26","1","wpseo_title","");
INSERT INTO `wpst_usermeta` VALUES("27","1","wpseo_metadesc","");
INSERT INTO `wpst_usermeta` VALUES("28","1","wpseo_noindex_author","");
INSERT INTO `wpst_usermeta` VALUES("29","1","wpseo_content_analysis_disable","");
INSERT INTO `wpst_usermeta` VALUES("30","1","wpseo_keyword_analysis_disable","");
INSERT INTO `wpst_usermeta` VALUES("32","1","instagram","");
INSERT INTO `wpst_usermeta` VALUES("33","1","linkedin","");
INSERT INTO `wpst_usermeta` VALUES("34","1","myspace","");
INSERT INTO `wpst_usermeta` VALUES("35","1","pinterest","");
INSERT INTO `wpst_usermeta` VALUES("36","1","soundcloud","");
INSERT INTO `wpst_usermeta` VALUES("37","1","tumblr","");
INSERT INTO `wpst_usermeta` VALUES("38","1","twitter","");
INSERT INTO `wpst_usermeta` VALUES("39","1","youtube","");
INSERT INTO `wpst_usermeta` VALUES("40","1","wikipedia","");
INSERT INTO `wpst_usermeta` VALUES("41","2","nickname","Xc1HM0");
INSERT INTO `wpst_usermeta` VALUES("42","2","first_name","");
INSERT INTO `wpst_usermeta` VALUES("43","2","last_name","");
INSERT INTO `wpst_usermeta` VALUES("44","2","description","");
INSERT INTO `wpst_usermeta` VALUES("45","2","rich_editing","true");
INSERT INTO `wpst_usermeta` VALUES("46","2","syntax_highlighting","true");
INSERT INTO `wpst_usermeta` VALUES("47","2","comment_shortcuts","false");
INSERT INTO `wpst_usermeta` VALUES("48","2","admin_color","fresh");
INSERT INTO `wpst_usermeta` VALUES("49","2","use_ssl","0");
INSERT INTO `wpst_usermeta` VALUES("50","2","show_admin_bar_front","true");
INSERT INTO `wpst_usermeta` VALUES("51","2","locale","");
INSERT INTO `wpst_usermeta` VALUES("52","2","wpst_capabilities","a:1:{s:6:\"editor\";b:1;}");
INSERT INTO `wpst_usermeta` VALUES("53","2","wpst_user_level","7");
INSERT INTO `wpst_usermeta` VALUES("54","2","_yoast_wpseo_profile_updated","1563089353");
INSERT INTO `wpst_usermeta` VALUES("55","2","dismissed_wp_pointers","");
INSERT INTO `wpst_usermeta` VALUES("57","2","wpst_dashboard_quick_press_last_post_id","114");
INSERT INTO `wpst_usermeta` VALUES("58","2","community-events-location","a:1:{s:2:\"ip\";s:10:\"157.50.0.0\";}");


DROP TABLE IF EXISTS `wpst_users`;

CREATE TABLE `wpst_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `wpst_users` VALUES("1","yGa64g","$P$BPtHS4sfTcxqPfUoldDvpuK3c6mmPi.","aim-expo-team","admin@aim-expo.com","","2018-09-19 05:33:35","","0","Aim-Expo Team");
INSERT INTO `wpst_users` VALUES("2","Xc1HM0","$P$BOfqDoWcN1.j5j6Hmbc44fy.dL4vi/.","xc1hm0","webdev@digitalseo.in","https://www.aim-expo.com/","2019-07-14 07:29:13","1563089353:$P$BZVd7fjRWuFFn6BvAOaCrGMropHgfq/","0","Xc1HM0");


DROP TABLE IF EXISTS `wpst_yoast_seo_links`;

CREATE TABLE `wpst_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wpst_yoast_seo_links` VALUES("1","https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=","11","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("2","https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=","11","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("3","https://www.addtoany.com/share","11","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("4","https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=","9","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("5","https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=","9","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("6","https://www.addtoany.com/share","9","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("7","https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=","10","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("8","https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=","10","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("9","https://www.addtoany.com/share","10","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("10","https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=","15","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("11","https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=","15","0","external");
INSERT INTO `wpst_yoast_seo_links` VALUES("12","https://www.addtoany.com/share","15","0","external");


DROP TABLE IF EXISTS `wpst_yoast_seo_meta`;

CREATE TABLE `wpst_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wpst_yoast_seo_meta` VALUES("11","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("9","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("10","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("15","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("44","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("26","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("108","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("52","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("25","0","0");
INSERT INTO `wpst_yoast_seo_meta` VALUES("73","0","0");


